package com.medleaf.journal.data

import java.text.Normalizer

/**
 * Verified offline product records.  This is deliberately factual: a blank field means the
 * referenced sources did not provide enough consistent information to bundle it confidently.
 * Source provenance stays with each record so the catalogue can be audited and refreshed.
 */
object OfflineCatalogue {
    private const val TCP = "https://thecannabispages.com/medicines/"
    private const val VERIFIED = "2026-09-21"

    private fun key(value: String) = Normalizer.normalize(value, Normalizer.Form.NFD)
        .replace("\\p{M}+".toRegex(), "").lowercase().filter(Char::isLetterOrDigit)

    private fun product(
        name: String,
        brand: String,
        type: String,
        terpenes: String = "",
        producer: String = brand,
        genetics: String = "",
        flavours: String = "",
        aliases: String = "",
        code: String = "",
        source: String = "The Cannabis Pages UK medicines directory",
        url: String = TCP
    ) = CatalogueProduct(
        id = "offline-${key(brand)}-${key(name)}", productName = name, cultivarName = name,
        brand = brand, producer = producer, genetics = genetics, cultivarType = type,
        commonTerpenes = terpenes, flavours = flavours, aliases = aliases,
        productCode = code, sourceName = source, sourceUrl = url, lastVerified = VERIFIED
    )

    fun products(): List<CatalogueProduct> = listOf(
        // Aurora/Pedanios — current and historic UK medicine listings.
        product("Black Jelly", "Aurora", "Sativa-dominant hybrid", "Limonene, Caryophyllene, Myrcene"),
        product("Pink Diesel", "Aurora", "Indica-dominant hybrid", "Limonene, Caryophyllene, Myrcene"),
        product("Cosmic Cream", "Aurora", "Indica-dominant hybrid", "Caryophyllene, Limonene, Linalool"),
        product("Moon Berry", "Aurora", "Hybrid", "Myrcene, Alpha-Pinene, Limonene"),
        product("Delahaze", "Aurora", "Sativa", "Terpinolene, Myrcene, Alpha-Pinene"),
        product("Pink Kush", "Aurora", "Indica", "Myrcene, Limonene, Caryophyllene"),
        product("Sourdough", "Aurora", "Indica", "Limonene, Caryophyllene, Myrcene"),
        product("Farm Gas", "Aurora", "Indica", "Limonene, Caryophyllene, Trans-Nerolidol"),
        product("Cannatonic 68", "Pedanios", "Hybrid", "Myrcene, Alpha-Pinene, Caryophyllene", producer = "Aurora", aliases = "Cannatonic"),
        product("Equiposa", "Pedanios", "Hybrid", "Myrcene, Alpha-Pinene, Limonene", producer = "Aurora"),
        product("Banana Split", "Pedanios", "Indica", "Myrcene, Caryophyllene, Trans-Nerolidol", producer = "Aurora"),
        product("Sour Tangie", "Pedanios", "Sativa", "Trans-Nerolidol, Caryophyllene, Linalool", producer = "Aurora"),
        product("LA Confidential", "Pedanios", "Indica", "Alpha-Pinene, Myrcene, Caryophyllene", producer = "Aurora"),
        product("Electric Honeydew", "Pedanios", "Sativa-dominant hybrid", "Myrcene, Limonene, Caryophyllene", producer = "Aurora"),
        product("Chemango Kush", "Pedanios", "Indica-dominant hybrid", "Caryophyllene, Trans-Nerolidol, Limonene", producer = "Aurora"),
        product("Frosted Lemon Angel", "Weeco", "Indica", "Caryophyllene, Myrcene, Limonene"),

        // Curaleaf and Noidecs records. Unknown terpene fields remain blank rather than guessed.
        product("GMO Zkittlez", "Curaleaf", "Hybrid", aliases = "Trufflebow, Cura-GZZ", code = "Cura-GZZ"),
        product("Grapefruit Gift", "Curaleaf", "Indica-dominant hybrid", aliases = "Cura-GGT", code = "Cura-GGT"),
        product("Lunar Circus", "Curaleaf", "Hybrid", "Myrcene, Terpinolene, Caryophyllene"),
        product("Murray Sherbet", "Noidecs", "Indica-dominant hybrid", "Myrcene, Alpha-Pinene, Beta-Pinene"),
        product("Green Crack", "Curaleaf", "Hybrid", "Myrcene, Ocimene, Limonene", aliases = "Green Cush"),
        product("Royal Moby", "Curaleaf", "Sativa", "Terpinolene, Myrcene, Caryophyllene"),
        product("Zookies", "Curaleaf", "Indica-dominant hybrid", "Limonene, Myrcene, Caryophyllene"),
        product("Lavender Cake", "Curaleaf", "Indica-dominant hybrid", "Caryophyllene, Farnesene, Myrcene"),
        product("Rozay", "Curaleaf", "Indica-dominant hybrid", "Caryophyllene, Limonene, Humulene", aliases = "Pink Rozay"),
        product("Gorilla Glue 4", "Curaleaf", "Hybrid", "Caryophyllene, Myrcene, Limonene", aliases = "Gorilla Glue, GG4, Original Glue"),
        product("Zour Apples", "Curaleaf", "Indica-dominant hybrid", "Terpinolene, Caryophyllene, Myrcene"),
        product("Wedding Pop Triangle", "Curaleaf", "Sativa-dominant hybrid", "Caryophyllene, Limonene, Myrcene"),
        product("Forbidden Fruit", "Curaleaf", "Indica-dominant hybrid"),

        // Green Karat — the producer is also the brand.
        product("Pavé S1", "Green Karat", "Hybrid", "Limonene, Linalool, Caryophyllene", genetics = "Paris OG × The Menthol", flavours = "Menthol, Gas, Earthy", aliases = "Pave S1", code = "PV"),
        product("Supreme Diesel", "Green Karat", "Hybrid", "Limonene, Caryophyllene, Farnesene"),
        product("Modified Gas", "Green Karat", "Hybrid", "Caryophyllene, Farnesene, Limonene"),
        product("Runtz OG", "Green Karat", "Hybrid", "Farnesene, Limonene, Caryophyllene"),
        product("Fiji Sunset", "Green Karat", "Indica-dominant hybrid", "Farnesene, Limonene, Myrcene", code = "FS"),
        product("Cool Grapes", "Green Karat", "Indica-dominant hybrid", "Limonene, Caryophyllene, Linalool"),
        product("King Sherb", "Green Karat", "Hybrid", "Myrcene, Limonene, Caryophyllene, Linalool", genetics = "OGKB V2.1 × Blue Sherbert", flavours = "Gas, Berry, Cream", aliases = "King Sherbet", code = "KS", source = "Green Karat product information; established cultivar references"),
        product("Loud Cake", "Green Karat", "Indica-dominant hybrid", "Limonene, Caryophyllene, Linalool, Humulene", genetics = "4561 S1 × Pancakes", code = "LC", source = "Green Karat product information; cultivar references"),

        // Big Narstie Medical: TCP identifies Herdade das Barrocas as cultivator.
        product("Purple Milk", "Big Narstie Medical", "Indica-dominant hybrid", "Myrcene, Caryophyllene, Linalool", producer = "Herdade das Barrocas"),
        product("Gastro Pop", "Big Narstie Medical", "Indica-dominant hybrid", "Myrcene, Linalool, Caryophyllene", producer = "Herdade das Barrocas", genetics = "Apples & Bananas × Grape Gas"),
        product("Glitter Bomb", "Big Narstie Medical", "Hybrid", "Beta-Pinene, Caryophyllene, Linalool", producer = "Herdade das Barrocas"),
        product("Moroccan Peaches", "Big Narstie Medical", "Sativa-dominant hybrid", "Caryophyllene, Trans-Nerolidol, Limonene", producer = "Herdade das Barrocas"),

        // Mamedica-labelled products listed in the UK directory.
        product("MAC1", "Mamedica", "Indica", "Limonene, Alpha-Pinene, Caryophyllene", genetics = "Alien Cookies × Colombian × Starfighter", aliases = "MAC 1, Miracle Alien Cookies", code = "MA1"),
        product("Black Garlic", "Mamedica", "Indica", "Limonene, Caryophyllene, Myrcene", code = "GEL"),

        // Spectrum UK listings.
        product("Highlands", "Spectrum", "Indica", "Myrcene, Caryophyllene, Alpha-Pinene"),
        product("Lemon Skunk", "Spectrum", "Sativa", "Terpinolene, Caryophyllene, Ocimene"),

        // Terpfolio product records verified against product labels and multiple references.
        product("Alien Mintz", "Upstate", "Hybrid", aliases = "Alien Mints, Upstate Alien Mintz"),
        product("Mac Doughnuts", "All Nations", "Hybrid", "Myrcene, Limonene, Caryophyllene, Linalool", genetics = "MAC-1 × Birthday Cake", aliases = "Mac Doughnut, MAC Doughnut", code = "GM T27"),
        product("Yoda Cap", "Papers Craft Co.", "Hybrid", "Caryophyllene, Limonene, Myrcene", genetics = "Baby Yoda × Cap Junky", flavours = "Berry, Menthol, Gas", aliases = "Yodacap", code = "PAP YC", source = "Terpfolio product label and cultivar references"),
        product("Cap Junky", "Mamedica", "Hybrid", "Caryophyllene, Limonene, Myrcene", producer = "Cheers Cannabis", genetics = "Alien Cookies × Kush Mints #11", flavours = "Diesel, Pepper, Fruit", aliases = "Capjunky", source = "Terpfolio product label; established cultivar references"),
        product("Lemon Cherry Gelato", "N!CE", "Hybrid", "Caryophyllene, Limonene, Linalool", genetics = "Sunset Sherbet × Girl Scout Cookies", flavours = "Cherry, Lemon, Sweet", aliases = "LCG", source = "Terpfolio product label; established cultivar references"),
        product("Punchsicle", "Ghost Drops", "Hybrid", "Limonene, Caryophyllene, Myrcene, Phellandrene", genetics = "Purple Punch × Gelato #45", flavours = "Sweet, Grape, Citrus", source = "Terpfolio product label; MedBud cultivar listing; cultivar references"),
        product("Rainbow Pave", "Aeriz", "Hybrid", genetics = "Apples & Bananas × Pavé", aliases = "Rainbow Pavé", source = "Aeriz cultivar reference", url = "https://strains.aeriz.com/strain/rainbow-pave/"),
        product("Masterpiece", "Carmel", "Hybrid", genetics = "Cap Junky × Platinum", aliases = "Carmel Masterpiece", source = "Carmel cultivar reference", url = "https://itsupinsmoke.com/product/carmel-masterpiece-lto/")
    )
}
