package com.medleaf.journal.data

import org.junit.Assert.*
import org.junit.Test

class CatalogueUpgradeTest {
    @Test fun mamedicaGeorgiaPieResolvesItsLabelledGrowerWithoutReplacingCraftBotanics() {
        val products = OfflineCatalogue.products()
        val mamedica = CatalogueSearch.exact(products, "Georgia Pie", "Mamedica")!!
        assertEquals("Thunderchild Cultivation LP", mamedica.producer)
        assertEquals("GGP T26", mamedica.productCode)
        assertEquals(mamedica, CatalogueSearch.exact(products, "MA GGP T26", "Mamedica"))
        assertTrue(CatalogueSearch.search(products, "Mamedica GGP T26").contains(mamedica))
        assertTrue(Cultivators.search("thunderchild").contains("Thunderchild Cultivation LP"))
        assertEquals("Craft Botanics", CatalogueSearch.exact(products, "Georgia Pie", "Craft Botanics")?.producer)
    }

    @Test fun existingCarmelMasterpieceReviewsResolveReportedProfile() {
        val review = Review(strainName = "Masterpiece", brand = "Carmel", cultivator = "", thoughts = "Existing notes")
        val products = OfflineCatalogue.products()
        val product = CatalogueSearch.exact(products, review.strainName, review.brand, review.cultivator)!!
        assertEquals(listOf("Myrcene", "Limonene", "Caryophyllene", "Linalool"), product.terpeneList())
        assertTrue(product.sourceName.contains("claimed terpene estimate"))
        assertEquals("Existing notes", review.thoughts)
        assertEquals("", review.cultivator)
        val stale = product.copy(id = "legacy-empty", commonTerpenes = "")
        assertEquals(product, CatalogueSearch.exact(listOf(stale, product), "Masterpiece", "Carmel", "Carmel"))
    }

    @Test fun hollyMoodAliasesResolveTheBundledLogo() {
        val identity = CultivatorBrands.resolve("HollyMood")!!
        assertEquals(com.medleaf.journal.R.drawable.cultivator_hollymood, identity.logoResource)
        listOf("Holly Mood", "Hollywood", "HollyMood Farms").forEach {
            assertEquals(identity, CultivatorBrands.resolve(it))
        }
        assertEquals(640, identity.artworkBounds.width)
        assertEquals(87, identity.artworkBounds.height)
    }

    @Test fun dojaPermanentMarkerHasSeparateGrowerAndProductTerpenes() {
        val product = CatalogueSearch.exact(OfflineCatalogue.products(), "Permanent Marker", "Doja")!!
        assertEquals("HollyMood", product.producer)
        assertEquals(listOf("Caryophyllene", "Limonene", "Linalool"), product.terpeneList())
        assertTrue(product.genetics.isNotBlank())
        assertTrue(product.sourceUrl.contains("doja-medical-permanent-marker"))
    }

    @Test fun richCoverageAndProvenanceAreRetained() {
        val products = ExpandedCatalogue.products()
        assertEquals(312, products.size)
        assertEquals(281, products.count { it.commonTerpenes.isNotBlank() })
        assertEquals(148, products.count { it.producer.isNotBlank() })
        assertEquals(133, products.count { it.genetics.isNotBlank() })
        assertTrue(products.all { it.sourceUrl.startsWith("https://") })
        assertEquals(products.size, products.distinctBy { it.id }.size)
    }

    @Test fun supplierLookupDoesNotBorrowAnotherSuppliersProfile() {
        val products = OfflineCatalogue.products()
        assertEquals("Doja", CatalogueSearch.exact(products, "Permanent Marker", "Doja Medical", "Hollywood")?.brand)
        assertNull(CatalogueSearch.exact(products, "Permanent Marker", "Unlisted Brand"))
        assertNull(CatalogueSearch.exact(products, "Permanent Marker", "Doja", "Unlisted Grower"))
    }

    @Test fun sameBrandDifferentGrowersRemainSeparateChoices() {
        val products = OfflineCatalogue.products()
        val suggestions = CatalogueSearch.search(products, "Mamedica Cap Junky", 30)
        assertTrue(suggestions.any { it.producer == "Cheers Cannabis" })
        assertTrue(suggestions.any { it.producer == "PurpleFarm" })
        assertEquals("PurpleFarm", CatalogueSearch.exact(products, "Cap Junky", "Mamedica", "PurpleFarm")?.producer)
        assertEquals(products.size, products.distinctBy { it.id }.size)
    }

    @Test fun richerDuplicateIsUsedBeforeAnEmptyLegacyRecord() {
        val rich = CatalogueSearch.exact(OfflineCatalogue.products(), "Permanent Marker", "Doja")!!
        val empty = rich.copy(id = "old", genetics = "", commonTerpenes = "", producer = "")
        assertEquals(rich, CatalogueSearch.exact(listOf(empty, rich), "Permanent Marker", "Doja"))
    }

    @Test fun companiesWithoutLogosAndPreviouslyEnteredNamesAreSearchable() {
        assertEquals("HollyMood", Cultivators.resolve("Hollywood"))
        assertEquals("Herdade das Barrocas", Cultivators.resolve("Herdade Das Barrocas"))
        assertTrue(Cultivators.search("purple").contains("PurpleFarm"))
        assertEquals(listOf("My Grower"), Cultivators.search("my grow", listOf("My Grower")))
        assertTrue(Cultivators.all().size > 120)
    }

    @Test fun legacyReviewPhotoOrderAndStoredCompanyValuesRemainIntact() {
        val review = Review(id = 42, strainName = "Permanent Marker", brand = "Doja", cultivator = "Hollywood",
            imageUri = "file:///original/cover.jpg", imageUris = "file:///original/one.jpg\nfile:///original/two.jpg",
            thoughts = "My existing review", createdAt = 123L)
        CatalogueSearch.exact(OfflineCatalogue.products(), review.strainName, review.brand, review.cultivator)
        assertEquals(listOf("file:///original/one.jpg", "file:///original/two.jpg"), review.photos())
        assertEquals("Hollywood", review.cultivator)
        assertEquals("My existing review", review.thoughts)
        assertEquals(42L, review.id)
        assertEquals(123L, review.createdAt)
    }
}
