package com.medleaf.journal.data

import java.text.Normalizer

/**
 * Offline name index for established cultivars. These entries intentionally contain names only:
 * reference genetics, terpenes and effects are never guessed. Richer verified product/reference
 * records with the same name rank ahead of these entries in [CatalogueSearch].
 */
object BundledStrainIndex {
    private val names = """
        9 Pound Hammer
        ACDC
        Acapulco Gold
        Afghan Kush
        Afghani
        Agent Orange
        AK-47
        Alaskan Thunder Fuck
        Alien Cookies
        Alien Dawg
        Alien OG
        Amnesia Haze
        Animal Cookies
        Animal Face
        Animal Mints
        Apple Fritter
        Apples and Bananas
        Banana Cream
        Banana Kush
        Banana Punch
        Bananaconda
        Biscotti
        Black Cherry Gelato
        Black Diamond
        Black Domina
        Black Russian
        Blackberry Kush
        Blue Cheese
        Blue Cookies
        Blue Dream
        Blue Lobster
        Blueberry
        Blueberry Cookies
        Blueberry Muffin
        Bruce Banner
        Bubba Kush
        Bubblegum
        Cake Crasher
        Candyland
        Cannatonic
        Cap Junky
        Casey Jones
        Cereal Milk
        Charlotte's Web
        Chem 91
        Chem Cookies
        Chem de la Chem
        Chemdawg
        Cherry AK-47
        Cherry Diesel
        Cherry Pie
        Chocolope
        Cinderella 99
        Clementine
        Cookies and Cream
        Critical Kush
        Critical Mass
        Death Bubba
        Dosidos
        Durban Poison
        Dutch Treat
        Forbidden Fruit
        French Cookies
        Frosted Lemon Angel
        G13
        Garlic Cookies
        Garlic Mushroom Onion
        Gas Cream Cake
        Gelato
        Gelato 33
        Gelato 41
        Gelato 45
        Georgia Pie
        Ghost OG
        GMO
        GMO Cookies
        God Bud
        God's Gift
        Golden Goat
        Gorilla Glue
        Gorilla Glue #4
        Granddaddy Purple
        Grape Ape
        Grape Cream Cake
        Grape Gas
        Grape Pie
        Grapefruit
        Green Crack
        Green Gelato
        Guava
        Guava Cake
        Harlequin
        Headband
        Hindu Kush
        Ice Cream Cake
        Jack Herer
        Jack the Ripper
        Jealousy
        Jet Fuel
        Jet Fuel Gelato
        Khalifa Kush
        King Sherb
        Kosher Kush
        LA Confidential
        Larry OG
        Lava Cake
        Lemon Cherry Gelato
        Lemon Haze
        Lemon Skunk
        Lemon Tree
        Liberty Haze
        London Pound Cake
        MAC
        MAC 1
        Mac Doughnut
        Mac Doughnuts
        Mandarin Cookies
        Master Kush
        Masterpiece
        Maui Wowie
        Meat Breath
        Mimosa
        Mint Chocolate Chip
        Miracle Alien Cookies
        Modified Gas
        Motorbreath
        Northern Lights
        OG Kush
        Orange Bud
        Orange Cake
        Orange Cookies
        Orange Kush Cake
        Oreoz
        Original Glue
        Permanent Marker
        Petroleum
        Pineapple Express
        Pink Cookies
        Pink Kush
        Platinum Cookies
        Platinum OG
        Platinum Punch
        Power Plant
        Purple Haze
        Purple Milk
        Purple Punch
        Purple Urkle
        Rainbow Belts
        Rainbow Cake
        Rainbow Chip
        Rainbow Driver
        Rainbow Kush
        Rainbow Pave
        Rainbow Sherbet
        Red Dragon
        Romulan
        Royal Moby
        Runtz
        Runtz OG
        Sherbert
        Sherb Cake
        Sherb Crasher
        Sherb Mints
        Silver Haze
        Skywalker
        Skywalker OG
        Sour Diesel
        Sour Kush
        Sour Tangie
        Stardawg
        Strawberry Banana
        Strawberry Cough
        Strawberry Grail
        Strawberry Haze
        Sunset Sherbet
        Super Lemon Haze
        Super Silver Haze
        Tahoe OG
        Tangie
        Thin Mint GSC
        Trainwreck
        Triangle Kush
        Trillianz
        Tropicana Cookies
        UK Cheese
        Wedding Cake
        Wedding Crasher
        Wedding Pie
        White Fire OG
        White Runtz
        White Widow
        Zkittlez
        Apples and Bananas Jealousy
        Atomic Sour Grapefruit
        Atomic Apple
        Bazookas
        Black Garlic
        Black Triangle
        Black Tuna
        Blackwater
        Blue Haze
        Blue Zushi
        Bubble Bath
        Chemango Kush
        Chem Cookies OG
        Cherry Mints
        Cherry Moon Pie
        Cool Grapes
        Cosmic Cream
        Cosmic Kush
        Creamy Kees
        Delahaze
        Electric Honeydew
        Farm Gas
        Fiji Sunset
        First Class Funk
        Frosted Animal Cake
        Gelato Dream
        Glitter Bomb
        Gorilla Zkittlez
        Grape Galena
        Grape Gasoline
        Green Knight
        Hawaiian Rain
        Herijuana
        High Silver
        Hindu Kush CBD
        Island Sweet Skunk
        Jack Frosted
        Jungle Cake
        LA Kush Cake
        Liberty Haze
        Loud Cake
        Mango Cross
        Master Kush Ultra
        Moroccan Peaches
        Murray Sherbet
        Oceanic Black Cookies
        Orange 22
        Orange Punch
        Pave S1
        Pink Diesel
        Pink Rozay
        Powdered Donuts
        Punchsicle
        Queen Sangria
        Royal Gorilla
        Sourdough
        Space Cake
        Supreme Diesel
        Tiger Cake
        Tigerz Eye
        Tripoli
        Wedding Pop Triangle
        Wappa
        Yoda Cap
        Zour Apples
    """.trimIndent().lineSequence().map(String::trim).filter(String::isNotBlank).distinct().toList()

    fun products(): List<CatalogueProduct> = names.map { name ->
        CatalogueProduct(
            id = "name-${normalise(name)}",
            productName = name,
            cultivarName = name,
            sourceName = "Terpfolio offline cultivar name index",
            lastVerified = "2026-09-20"
        )
    }

    fun size(): Int = names.size

    private fun normalise(value: String) = Normalizer.normalize(value, Normalizer.Form.NFD)
        .replace("\\p{M}+".toRegex(), "")
        .lowercase()
        .filter(Char::isLetterOrDigit)
}
