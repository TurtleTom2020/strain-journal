package com.medleaf.journal.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CatalogueSearchTest {
    private val macDoughnut = CatalogueProduct(
        id = "uk-all-nations-mac-doughnut",
        productName = "Mac Doughnuts",
        cultivarName = "Mac Doughnuts",
        brand = "All Nations",
        genetics = "MAC-1 × Birthday Cake",
        cultivarType = "Hybrid",
        commonTerpenes = "Myrcene, Limonene, Caryophyllene, Linalool",
        aliases = "Mac Doughnut, MAC Doughnut, All Nations GM T27"
    )

    @Test fun macDoughnutsAliasFindsAllNationsProduct() {
        assertEquals("All Nations", CatalogueSearch.exact(listOf(macDoughnut), "Mac Doughnuts")?.brand)
        assertEquals("Mac Doughnuts", CatalogueSearch.search(listOf(macDoughnut), "mac dou").single().productName)
    }

    @Test fun unknownProductDoesNotBlockManualFallback() {
        assertTrue(CatalogueSearch.search(listOf(macDoughnut), "Completely New Strain").isEmpty())
    }

    @Test fun marketedAlienMintzNameIsPreserved() {
        val alienMintz = CatalogueProduct(
            id = "uk-upstate-alien-mintz",
            productName = "Alien Mintz",
            cultivarName = "Alien Mintz",
            brand = "Upstate",
            aliases = "Alien Mints, Upstate Alien Mintz"
        )
        assertEquals("Alien Mintz", CatalogueSearch.exact(listOf(alienMintz), "Alien Mintz")?.productName)
        assertEquals("Alien Mintz", CatalogueSearch.exact(listOf(alienMintz), "Alien Mints")?.productName)
        assertEquals("Upstate", CatalogueSearch.search(listOf(alienMintz), "alien mint").single().brand)
        val generic = CatalogueProduct(id = "reference-alienmints", productName = "Alien Mints", cultivarName = "Alien Mints")
        assertEquals("Alien Mintz", CatalogueSearch.exact(listOf(generic, alienMintz), "Alien Mints")?.productName)
        assertEquals("Alien Mintz", CatalogueSearch.search(listOf(generic, alienMintz), "alien mint").first().productName)
    }

    @Test fun progressiveSearchKeepsNarrowingWithoutLengthCutoff() {
        val products = BundledStrainIndex.products()
        listOf("M", "Ma", "Mas", "Mast", "Master", "Masterpiece").forEach { query ->
            assertTrue("Expected a result for $query", CatalogueSearch.search(products, query, 30).isNotEmpty())
        }
        assertEquals("Masterpiece", CatalogueSearch.search(products, "Masterpiece").first().productName)
    }

    @Test fun knownFailureQueriesResolveOffline() {
        val products = BundledStrainIndex.products()
        assertTrue(CatalogueSearch.search(products, "Loud").any { it.productName == "Loud Cake" })
        val rain = CatalogueSearch.search(products, "Rain", 30)
        assertTrue(rain.any { it.productName == "Rainbow Pave" })
        assertTrue(rain.count { it.productName.startsWith("Rainbow") } >= 5)
        assertTrue(CatalogueSearch.search(products, "Mast", 30).any { it.productName == "Masterpiece" })
    }

    @Test fun matchingIsCaseWhitespaceAndPunctuationTolerant() {
        val products = BundledStrainIndex.products()
        assertEquals("Rainbow Pave", CatalogueSearch.search(products, "  RAINBOW---PAV ").first().productName)
        assertEquals("Loud Cake", CatalogueSearch.search(products, "lOuD   cAk").first().productName)
    }

    @Test fun terpeneListsAreNeverCappedAtThree() {
        val kingSherb = CatalogueProduct(
            id = "king-sherb",
            productName = "King Sherb",
            commonTerpenes = "Myrcene, Limonene, Caryophyllene, Linalool"
        )
        assertEquals(listOf("Myrcene", "Limonene", "Caryophyllene", "Linalool"), kingSherb.terpeneList())
        assertEquals(
            listOf("Myrcene", "Limonene", "Caryophyllene", "Linalool"),
            StrainReferences.exact("King Sherb")?.commonTerpenes
        )
    }

    @Test fun bundledIndexIsSubstantiallyLargerThanOriginalCatalogue() {
        assertTrue(BundledStrainIndex.size() >= 250)
    }

    @Test fun bundledCatalogueIsSearchableBeforeRoomSeedCompletes() {
        val effective = mergeCatalogueLayers(BundledStrainIndex.products(), emptyList())
        assertTrue(CatalogueSearch.search(effective, "rainbow").any { it.productName == "Rainbow Pave" })
        assertTrue(CatalogueSearch.search(effective, "loud").any { it.productName == "Loud Cake" })
        assertTrue(CatalogueSearch.search(effective, "master").any { it.productName == "Masterpiece" })
    }

    @Test fun persistedRecordsOverrideMatchingBundleWithoutHidingFallbackNames() {
        val bundled = BundledStrainIndex.products()
        val persistedRainbow = bundled.first { it.productName == "Rainbow Pave" }.copy(
            genetics = "Apples & Bananas × Pavé",
            sourceName = "Verified product source"
        )
        val effective = mergeCatalogueLayers(bundled, listOf(persistedRainbow))

        assertEquals("Verified product source", CatalogueSearch.exact(effective, "Rainbow Pave")?.sourceName)
        assertTrue(CatalogueSearch.search(effective, "Loud").any { it.productName == "Loud Cake" })
    }

    @Test fun partialQueryDoesNotHideSuggestionsWhenSelectionAndExactMatchAreNull() {
        assertEquals(false, CatalogueSearch.shouldHideSuggestions(null, null))
        val rainbow = BundledStrainIndex.products().first { it.productName == "Rainbow Pave" }
        assertEquals(false, CatalogueSearch.shouldHideSuggestions(null, rainbow))
        assertEquals(true, CatalogueSearch.shouldHideSuggestions(rainbow.id, rainbow))
    }
}
