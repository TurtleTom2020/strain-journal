# Terpfolio 0.42.0

## Integrated in this build

- All 27 approved offline cultivator logos from `terpfolio_brand_logos_MASTER_FINAL.zip`.
- One alias-aware cultivator brand resolver and searchable brand catalogue.
- Recognised-logo previews in the cultivator picker with unrestricted manual entry fallback.
- Responsive logo presentation on review details and styled text fallback for unknown brands.
- Multi-photo review gallery count, detail-screen favourite control and keyboard-safe review editors.
- Current About version sourced from build metadata.
- Existing Room schema and migrations retained; no destructive database change was required.
- Compact adaptive 1–5 photo gallery with full-screen swipe, pinch zoom, double-tap zoom and counter.
- Original photo bytes copied once into private app storage; cover selection and reordering change URI order without recompression.
- Review Detail reorganised around strain, rating, compact cultivator identity, metadata, reported strain data and personal observations.
- Removed the misleading duplicate "Your recorded terpenes" UI while retaining its stored database field for compatibility.
- Added Mac Doughnut / Mac Doughnuts by All Nations to the bundled searchable UK catalogue.
- Cultivator shortcuts are compact logo-only tiles and review fields use quieter filled surfaces.
- Final Review Detail polish: no-photo layouts collapse fully, the title-to-cultivator rhythm is explicit, and price metadata aligns with the secondary information hierarchy.
- Cultivator visual-weight overrides are centralised: N!CE reduced, Green Karat and Ghost Drops increased, while approved source PNGs remain unchanged.
- Permanent Terpfolio branding increased to 38sp and Review Detail strain titles reduced to 29sp with natural multi-line wrapping.
- Rating/favourite grouping tightened and the reported-terpene label made more restrained without reintroducing personal terpene duplication.

## Verification

- `assembleDebug`: passed.
- Kotlin compilation and Room/KSP generation: passed.
- APK v2 signature verification: passed.
- Manifest package/version inspection: passed (`com.medleaf.journal`, `0.42.0`, version code 42).
- Cultivator resolver assertions: passed, including punctuation, case, accents, suffixes and unknown fallback.
- Catalogue search assertions: passed for Mac Doughnuts / All Nations and unknown-strain manual fallback.
- All integrated logo files: 600 x 220, RGBA and byte-identical to the approved master pack.

No Android emulator or physical device was available in the build environment, so interactive UI journeys still require installation testing on a device.
