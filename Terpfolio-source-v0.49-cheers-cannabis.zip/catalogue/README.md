# Terpfolio catalogue updates

The app can import a JSON array from **More → Settings → Update product catalogue**. Imported records are stored offline and merged by `id`; reviews and custom products are not deleted.

Keep the concepts separate:

- `brand` / `producer`: the company supplying the prescribed product.
- `productName`: the name shown to patients and used for autocomplete.
- `cultivarName`: the underlying cultivar when it differs from the product name.
- `genetics`: breeder lineage, not a product or company.
- `aliases` and `productCode`: comma-separated alternative search terms.

Do not put batch THC/CBD values in catalogue records. Those stay on each user's review because prescribed batches can differ. Every maintained record should include `sourceName`, `sourceUrl` where available, and `lastVerified` in `YYYY-MM-DD` format.
