package com.medleaf.journal.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ReviewCompanyTest {
    @Test fun legacyReviewTreatsBrandAsCultivator() {
        val review = Review(strainName = "Pave S1", brand = "Green Karat")

        assertEquals("Green Karat", review.effectiveCultivator())
        assertFalse(review.hasSeparateBrandAndCultivator())
    }

    @Test fun explicitlyDifferentCultivatorIsPreserved() {
        val review = Review(strainName = "Cap Junky", brand = "Mamedica", cultivator = "Cheers Cannabis")

        assertEquals("Cheers Cannabis", review.effectiveCultivator())
        assertTrue(review.hasSeparateBrandAndCultivator())
    }

    @Test fun companyComparisonIgnoresCaseAndOuterWhitespace() {
        val review = Review(strainName = "Example", brand = "Carmel", cultivator = " carmel ")

        assertFalse(review.hasSeparateBrandAndCultivator())
    }

    @Test fun knownAliasesAreTreatedAsTheSameCompany() {
        val review = Review(strainName = "Example", brand = "N!CE", cultivator = "NICE")

        assertFalse(review.hasSeparateBrandAndCultivator())
    }
}
