package com.medleaf.journal.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface JournalDao {
    @Query("SELECT * FROM reviews ORDER BY createdAt DESC")
    fun reviews(): Flow<List<Review>>

    @Query("SELECT * FROM reviews WHERE id = :id")
    fun review(id: Long): Flow<Review?>

    @Query("SELECT * FROM reviews")
    suspend fun allReviews(): List<Review>

    @Query("SELECT * FROM sessions ORDER BY takenAt DESC")
    fun sessions(): Flow<List<MedicationSession>>

    @Query("SELECT * FROM sessions")
    suspend fun allSessions(): List<MedicationSession>

    @Insert suspend fun insertReview(review: Review): Long
    @Update suspend fun updateReview(review: Review)
    @Delete suspend fun deleteReview(review: Review)
    @Insert suspend fun insertSession(session: MedicationSession): Long

    @Query("SELECT * FROM catalogue_products ORDER BY productName COLLATE NOCASE")
    fun catalogue(): Flow<List<CatalogueProduct>>

    @Query("SELECT * FROM catalogue_products")
    suspend fun allCatalogue(): List<CatalogueProduct>

    @Query("SELECT COUNT(*) FROM catalogue_products WHERE isCustom = 0")
    suspend fun bundledCatalogueCount(): Int

    @Query("SELECT * FROM catalogue_products WHERE id = :id LIMIT 1")
    suspend fun catalogueProduct(id: String): CatalogueProduct?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCatalogue(products: List<CatalogueProduct>)
}
