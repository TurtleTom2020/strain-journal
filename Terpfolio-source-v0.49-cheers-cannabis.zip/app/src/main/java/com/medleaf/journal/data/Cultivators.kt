package com.medleaf.journal.data

object Cultivators {
    private val textOnlyNames = listOf("Lumir", "LOT420", "Qwest", "Noidecs", "Canopy", "Hexacan", "Therismos", "Montu", "Cantourage")
    private val names get() = CultivatorBrands.all.map { it.name } + textOnlyNames

    private fun normalise(value: String): String = value
        .lowercase()
        .replace('1', 'i')
        .replace("!", "i")
        .filter { it.isLetterOrDigit() }

    fun search(text: String): List<String> = if (text.isBlank()) names.take(8)
    else {
        val query = normalise(text.trim())
        names.filter { normalise(it).contains(query) }.take(8)
    }
}
