package com.medleaf.journal.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [Review::class, MedicationSession::class, CatalogueProduct::class], version = 5, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun journalDao(): JournalDao
    companion object {
        fun create(context: Context): AppDatabase = Room.databaseBuilder(
            context.applicationContext, AppDatabase::class.java, "medleaf-journal.db"
        ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5).build()

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE reviews ADD COLUMN imageUris TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE reviews ADD COLUMN reviewDate INTEGER NOT NULL DEFAULT 0")
                db.execSQL("UPDATE reviews SET reviewDate = createdAt WHERE reviewDate = 0")
                db.execSQL("ALTER TABLE reviews ADD COLUMN batchNumber TEXT NOT NULL DEFAULT ''")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS `catalogue_products` (`id` TEXT NOT NULL, `productName` TEXT NOT NULL, `cultivarName` TEXT NOT NULL, `brand` TEXT NOT NULL, `producer` TEXT NOT NULL, `genetics` TEXT NOT NULL, `cultivarType` TEXT NOT NULL, `commonTerpenes` TEXT NOT NULL, `flavours` TEXT NOT NULL, `aliases` TEXT NOT NULL, `productCode` TEXT NOT NULL, `sourceName` TEXT NOT NULL, `sourceUrl` TEXT NOT NULL, `lastVerified` TEXT NOT NULL, `isCustom` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`id`))""")
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE reviews ADD COLUMN pricePaid REAL DEFAULT NULL")
                db.execSQL("ALTER TABLE reviews ADD COLUMN packSizeGrams REAL DEFAULT NULL")
            }
        }

        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE reviews ADD COLUMN cultivator TEXT NOT NULL DEFAULT ''")
                db.execSQL("UPDATE reviews SET cultivator = brand WHERE cultivator = ''")
            }
        }
    }
}
