package com.medleaf.journal.data

import android.text.Html
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.time.LocalDate
import java.text.Normalizer

object OnlineCatalogue {
    private const val SEARCH = "https://thecannabispages.com/wp-json/wp/v2/search"

    suspend fun search(query: String): List<CatalogueProduct> = withContext(Dispatchers.IO) {
        if (query.trim().length < 3) return@withContext emptyList()
        val encoded = URLEncoder.encode(query.trim(), Charsets.UTF_8.name())
        // Restrict WordPress search to catalogue products. Without subtype=product the
        // endpoint also returns news/articles, which must never become strain suggestions.
        val connection = URL("$SEARCH?search=$encoded&per_page=12&type=post&subtype=product").openConnection() as HttpURLConnection
        connection.connectTimeout = 8_000
        connection.readTimeout = 10_000
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("User-Agent", "Terpfolio/0.30 Android catalogue search")
        try {
            require(connection.responseCode in 200..299) { "UK catalogue returned ${connection.responseCode}" }
            val array = connection.inputStream.bufferedReader().use { JSONArray(it.readText()) }
            (0 until array.length()).mapNotNull { index ->
                val item = array.optJSONObject(index) ?: return@mapNotNull null
                val rawTitle = item.optString("title")
                val title = Html.fromHtml(rawTitle, Html.FROM_HTML_MODE_LEGACY).toString().trim()
                val url = item.optString("url")
                val subtype = item.optString("subtype")
                val catalogueProduct = subtype.equals("product", true) || url.contains("/product/", true)
                if (!catalogueProduct || title.isBlank() || url.isBlank() || !matches(title, query)) return@mapNotNull null
                val product = cleanProductName(title)
                CatalogueProduct(
                    id = "online-${normalise(url).takeLast(70)}",
                    productName = product,
                    cultivarName = product,
                    brand = inferBrand(title, product),
                    aliases = title.takeUnless { it.equals(product, true) }.orEmpty(),
                    sourceName = "The Cannabis Pages UK catalogue",
                    sourceUrl = url,
                    lastVerified = LocalDate.now().toString()
                )
            }.distinctBy { normalise(it.productName) to normalise(it.brand) }.take(8)
        } finally {
            connection.disconnect()
        }
    }

    private fun matches(title: String, query: String): Boolean {
        val words = query.split(" ").map(::normalise).filter { it.length > 1 }
        val candidate = normalise(title)
        return words.all(candidate::contains)
    }

    private fun cleanProductName(title: String): String {
        val withoutType = title.replace(Regex("(?i)\\s*[-–|:]?\\s*(medical cannabis|cannabis)\\s+(flower|oil|capsules?|cartridge|pastilles?).*$"), "")
            .replace(Regex("(?i)\\s*[-–|:]?\\s*(flower|strain)\\s*$"), "").trim(' ', '-', '–', '|', ':')
        val segments = withoutType.split(Regex("\\s+[-–|]\\s+")).map(String::trim).filter(String::isNotBlank)
        return segments.lastOrNull()?.takeIf { it.length >= 3 } ?: withoutType
    }

    private fun inferBrand(title: String, product: String): String {
        val prefix = title.substringBefore(product, "").trim(' ', '-', '–', '|', ':')
        return prefix.takeIf { it.length in 2..50 }.orEmpty()
    }

    private fun normalise(value: String) = Normalizer.normalize(value.trim(), Normalizer.Form.NFD)
        .replace("\\p{M}+".toRegex(), "").lowercase().filter(Char::isLetterOrDigit)
}
