package com.medleaf.journal.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [Review::class, MedicationSession::class, CatalogueProduct::class], version = 3, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun journalDao(): JournalDao
    companion object {
        fun create(context: Context): AppDatabase = Room.databaseBuilder(
            context.applicationContext, AppDatabase::class.java, "medleaf-journal.db"
        ).addMigrations(MIGRATION_1_2, MIGRATION_2_3).build()

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE reviews ADD COLUMN imageUris TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE reviews ADD COLUMN reviewDate INTEGER NOT NULL DEFAULT 0")
                db.execSQL("UPDATE reviews SET reviewDate = createdAt WHERE reviewDate = 0")
                db.execSQL("ALTER TABLE reviews ADD COLUMN batchNumber TEXT NOT NULL DEFAULT ''")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS `catalogue_products` (`id` TEXT NOT NULL, `productName` TEXT NOT NULL, `cultivarName` TEXT NOT NULL, `brand` TEXT NOT NULL, `producer` TEXT NOT NULL, `genetics` TEXT NOT NULL, `cultivarType` TEXT NOT NULL, `commonTerpenes` TEXT NOT NULL, `flavours` TEXT NOT NULL, `aliases` TEXT NOT NULL, `productCode` TEXT NOT NULL, `sourceName` TEXT NOT NULL, `sourceUrl` TEXT NOT NULL, `lastVerified` TEXT NOT NULL, `isCustom` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`id`))""")
            }
        }
    }
}
