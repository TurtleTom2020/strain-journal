package com.medleaf.journal.data

import androidx.room.withTransaction

class JournalRepository(private val database: AppDatabase) {
    private val dao = database.journalDao()
    val reviews = dao.reviews()
    val sessions = dao.sessions()
    fun review(id: Long) = dao.review(id)
    suspend fun save(review: Review) = dao.insertReview(review)
    suspend fun update(review: Review) = dao.updateReview(review)
    suspend fun saveSession(session: MedicationSession) = dao.insertSession(session)
    suspend fun allReviews() = dao.allReviews()
    suspend fun allSessions() = dao.allSessions()
    suspend fun importReviews(reviews: List<Review>, sessions: List<MedicationSession>): Pair<Int, Int> = database.withTransaction {
        val existing = dao.allReviews()
        val ids = mutableMapOf<Long, Long>()
        val keys = existing.associateBy { it.createdAt to it.strainName.trim().lowercase() }.toMutableMap()
        var addedReviews = 0
        for (review in reviews) {
            val key = review.createdAt to review.strainName.trim().lowercase()
            val match = keys[key]
            if (match != null) ids[review.id] = match.id
            else {
                val newId = dao.insertReview(review.copy(id = 0))
                ids[review.id] = newId
                keys[key] = review.copy(id = newId)
                addedReviews++
            }
        }
        val sessionKeys = dao.allSessions().map { Triple(it.takenAt, it.strainName, it.notes) }.toMutableSet()
        var addedSessions = 0
        for (session in sessions) {
            val key = Triple(session.takenAt, session.strainName, session.notes)
            if (sessionKeys.add(key)) {
                dao.insertSession(session.copy(id = 0, reviewId = session.reviewId?.let(ids::get)))
                addedSessions++
            }
        }
        addedReviews to addedSessions
    }
}
