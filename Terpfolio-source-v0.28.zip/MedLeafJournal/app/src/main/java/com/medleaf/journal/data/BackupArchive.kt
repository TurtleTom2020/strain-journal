package com.medleaf.journal.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Versioned, portable archive. Neither the database nor its private files are replaced on import. */
object BackupArchive {
    private const val MAX_PHOTO = 40L * 1024 * 1024
    private const val MAX_TOTAL = 2L * 1024 * 1024 * 1024
    private const val MAX_JSON = 12L * 1024 * 1024

    suspend fun export(context: Context, destination: Uri, repository: JournalRepository): String = withContext(Dispatchers.IO) {
        val reviews = repository.allReviews()
        val sessions = repository.allSessions()
        val photos = linkedMapOf<String, String>()
        val manifest = JSONObject().put("format", "terpfolio-backup").put("version", 1)
        val reviewJson = JSONArray()
        for (review in reviews) {
            val imageNames = JSONArray()
            review.photos().forEachIndexed { index, uri ->
                val name = "photos/${review.id}-$index.jpg"
                photos[name] = uri
                imageNames.put(name)
            }
            reviewJson.put(review.toJson().put("photos", imageNames))
        }
        manifest.put("reviews", reviewJson).put("sessions", JSONArray().apply { sessions.forEach { put(it.toJson()) } })
        val json = manifest.toString().toByteArray(Charsets.UTF_8)
        require(json.size <= MAX_JSON) { "Too many reviews for one backup" }
        val resolver = context.contentResolver
        resolver.openOutputStream(destination, "w")?.use { raw ->
            ZipOutputStream(raw).use { zip ->
                var total = json.size.toLong()
                zip.putNextEntry(ZipEntry("manifest.json")); zip.write(json); zip.closeEntry()
                for ((name, uri) in photos) {
                    zip.putNextEntry(ZipEntry(name))
                    val count = resolver.openInputStream(Uri.parse(uri))?.use { it.copyLimited(zip, MAX_PHOTO) }
                        ?: error("Photo unavailable: $name. Export stopped rather than silently omitting it.")
                    total += count
                    require(total <= MAX_TOTAL) { "Backup exceeds 2 GB" }
                    zip.closeEntry()
                }
            }
        } ?: error("Cannot open backup destination")
        "${reviews.size} reviews, ${sessions.size} journal entries, ${photos.size} photos"
    }

    suspend fun restore(context: Context, source: Uri, repository: JournalRepository): Pair<Int, Int> = withContext(Dispatchers.IO) {
        val staging = File(context.cacheDir, "terpfolio-restore-${UUID.randomUUID()}").apply { mkdirs() }
        val entries = mutableMapOf<String, File>()
        val temporaryFiles = mutableListOf<File>()
        var total = 0L
        val staged = mutableListOf<File>()
        try {
            context.contentResolver.openInputStream(source)?.use { raw ->
                ZipInputStream(raw).use { zip ->
                    while (true) {
                        val entry = zip.nextEntry ?: break
                        val name = entry.name
                        require(name == "manifest.json" || Regex("photos/[0-9]+-[0-4]\\.jpg").matches(name)) { "Unexpected backup entry" }
                        require(name !in entries && entries.size < 10000) { "Duplicate or oversized backup" }
                        val file = File(staging, "entry-${entries.size}")
                        temporaryFiles += file
                        val count = file.outputStream().use { zip.copyLimited(it, if (name == "manifest.json") MAX_JSON else MAX_PHOTO) }
                        total += count
                        require(total <= MAX_TOTAL) { "Backup exceeds 2 GB" }
                        entries[name] = file
                        zip.closeEntry()
                    }
                }
            } ?: error("Cannot open backup file")
            val manifestFile = entries["manifest.json"] ?: error("Backup manifest missing")
            val manifest = JSONObject(manifestFile.readText(Charsets.UTF_8))
            require(manifest.getString("format") == "terpfolio-backup" && manifest.getInt("version") == 1) { "Unsupported backup format" }
            val imported = manifest.getJSONArray("reviews")
            val sessionJson = manifest.getJSONArray("sessions")
            require(imported.length() < 5000 && sessionJson.length() < 20000) { "Backup has too many entries" }
            val photoDir = File(context.filesDir, "backup-photos").apply { mkdirs() }
            val existingKeys = repository.allReviews().map { it.createdAt to it.strainName.trim().lowercase() }.toSet()
            val reviews = (0 until imported.length()).map { index ->
                val data = imported.getJSONObject(index)
                val names = data.getJSONArray("photos")
                require(names.length() <= 5) { "Too many photos on a review" }
                val duplicate = (data.getLong("createdAt") to data.getString("strainName").trim().lowercase()) in existingKeys
                val restoredUris = (0 until names.length()).map { image ->
                    val name = names.getString(image)
                    val saved = entries[name] ?: error("Photo missing: $name")
                    if (duplicate) "" else {
                        val file = File(photoDir, "${UUID.randomUUID()}.jpg")
                        staged += file
                        saved.copyTo(file)
                        Uri.fromFile(file).toString()
                    }
                }
                data.toReview().copy(imageUri = restoredUris.firstOrNull { it.isNotBlank() }, imageUris = restoredUris.filter { it.isNotBlank() }.joinToString("\n"))
            }
            require(reviews.map { it.id }.distinct().size == reviews.size) { "Duplicate review IDs in backup" }
            val sessions = (0 until sessionJson.length()).map { sessionJson.getJSONObject(it).toSession() }
            repository.importReviews(reviews, sessions)
        } catch (error: Exception) {
            staged.forEach { it.delete() }
            throw error
        } finally {
            temporaryFiles.forEach { it.delete() }
            staging.delete()
        }
    }

    private fun java.io.InputStream.copyLimited(out: java.io.OutputStream, limit: Long): Long {
        var total = 0L
        val buffer = ByteArray(8192)
        while (true) {
            val count = read(buffer)
            if (count < 0) break
            total += count
            require(total <= limit) { "Backup item exceeds size limit" }
            out.write(buffer, 0, count)
        }
        return total
    }

    private fun Review.toJson() = JSONObject().apply {
        put("id", id); put("strainName", strainName); put("brand", brand); put("cultivarType", cultivarType)
        put("thcPercent", thcPercent ?: JSONObject.NULL); put("cbdPercent", cbdPercent ?: JSONObject.NULL)
        put("terpenes", terpenes); put("aroma", aroma); put("flavour", flavour); put("thoughts", thoughts)
        put("effectiveness", effectiveness); put("flavourRating", flavourRating); put("appearanceRating", appearanceRating)
        put("valueRating", valueRating); put("overallRating", overallRating); put("helpedSymptoms", helpedSymptoms)
        put("effects", effects); put("sideEffects", sideEffects); put("reviewDate", reviewDate); put("batchNumber", batchNumber)
        put("isFavourite", isFavourite); put("visibility", visibility); put("createdAt", createdAt)
    }

    private fun JSONObject.toReview() = Review(
        id = getLong("id"), strainName = getString("strainName"), brand = getString("brand"), cultivarType = getString("cultivarType"),
        thcPercent = if (isNull("thcPercent")) null else getDouble("thcPercent"), cbdPercent = if (isNull("cbdPercent")) null else getDouble("cbdPercent"),
        terpenes = getString("terpenes"), aroma = getString("aroma"), flavour = getString("flavour"), thoughts = getString("thoughts"),
        effectiveness = getInt("effectiveness"), flavourRating = getInt("flavourRating"), appearanceRating = getInt("appearanceRating"),
        valueRating = getInt("valueRating"), overallRating = getInt("overallRating"), helpedSymptoms = getString("helpedSymptoms"),
        effects = getString("effects"), sideEffects = getString("sideEffects"), reviewDate = getLong("reviewDate"), batchNumber = getString("batchNumber"),
        isFavourite = getBoolean("isFavourite"), visibility = getString("visibility"), createdAt = getLong("createdAt")
    ).also { require(it.id > 0 && it.strainName.isNotBlank()) { "Invalid review in backup" } }

    private fun MedicationSession.toJson() = JSONObject().apply {
        put("id", id); put("reviewId", reviewId ?: JSONObject.NULL); put("strainName", strainName)
        put("amountGrams", amountGrams ?: JSONObject.NULL); put("method", method); put("temperatureC", temperatureC ?: JSONObject.NULL)
        put("symptomsBefore", symptomsBefore); put("reliefAfter", reliefAfter); put("notes", notes); put("takenAt", takenAt)
    }

    private fun JSONObject.toSession() = MedicationSession(
        id = getLong("id"), reviewId = if (isNull("reviewId")) null else getLong("reviewId"), strainName = getString("strainName"),
        amountGrams = if (isNull("amountGrams")) null else getDouble("amountGrams"), method = getString("method"),
        temperatureC = if (isNull("temperatureC")) null else getInt("temperatureC"), symptomsBefore = getInt("symptomsBefore"),
        reliefAfter = getInt("reliefAfter"), notes = getString("notes"), takenAt = getLong("takenAt")
    )
}
