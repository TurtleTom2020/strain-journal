package com.medleaf.journal.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CatalogueSearchTest {
    private val macDoughnut = CatalogueProduct(
        id = "uk-all-nations-mac-doughnut",
        productName = "Mac Doughnut",
        cultivarName = "Mac Doughnut",
        brand = "All Nations",
        genetics = "MAC-1 × Birthday Cake",
        cultivarType = "Hybrid",
        commonTerpenes = "Myrcene, Limonene, Caryophyllene, Linalool",
        aliases = "Mac Doughnuts, MAC Doughnuts, All Nations GM T27"
    )

    @Test fun macDoughnutsAliasFindsAllNationsProduct() {
        assertEquals("All Nations", CatalogueSearch.exact(listOf(macDoughnut), "Mac Doughnuts")?.brand)
        assertEquals("Mac Doughnut", CatalogueSearch.search(listOf(macDoughnut), "mac dou").single().productName)
    }

    @Test fun unknownProductDoesNotBlockManualFallback() {
        assertTrue(CatalogueSearch.search(listOf(macDoughnut), "Completely New Strain").isEmpty())
    }

    @Test fun marketedAlienMintzNameIsPreserved() {
        val alienMintz = CatalogueProduct(
            id = "uk-upstate-alien-mintz",
            productName = "Alien Mintz",
            cultivarName = "Alien Mintz",
            brand = "Upstate",
            aliases = "Alien Mints, Upstate Alien Mintz"
        )
        assertEquals("Alien Mintz", CatalogueSearch.exact(listOf(alienMintz), "Alien Mintz")?.productName)
        assertEquals("Alien Mintz", CatalogueSearch.exact(listOf(alienMintz), "Alien Mints")?.productName)
        assertEquals("Upstate", CatalogueSearch.search(listOf(alienMintz), "alien mint").single().brand)
    }
}
