package com.medleaf.journal.data

import org.junit.Assert.*
import org.junit.Test

class CatalogueUpgradeTest {
    @Test fun dojaPermanentMarkerHasSeparateGrowerAndProductTerpenes() {
        val product = CatalogueSearch.exact(OfflineCatalogue.products(), "Permanent Marker", "Doja")!!
        assertEquals("HollyMood", product.producer)
        assertEquals(listOf("Caryophyllene", "Limonene", "Linalool"), product.terpeneList())
        assertTrue(product.genetics.isNotBlank())
        assertTrue(product.sourceUrl.contains("doja-medical-permanent-marker"))
    }

    @Test fun richCoverageAndProvenanceAreRetained() {
        val products = ExpandedCatalogue.products()
        assertEquals(312, products.size)
        assertEquals(281, products.count { it.commonTerpenes.isNotBlank() })
        assertEquals(147, products.count { it.producer.isNotBlank() })
        assertEquals(133, products.count { it.genetics.isNotBlank() })
        assertTrue(products.all { it.sourceUrl.startsWith("https://") })
        assertEquals(products.size, products.distinctBy { it.id }.size)
    }

    @Test fun supplierLookupDoesNotBorrowAnotherSuppliersProfile() {
        val products = OfflineCatalogue.products()
        assertEquals("Doja", CatalogueSearch.exact(products, "Permanent Marker", "Doja Medical", "Hollywood")?.brand)
        assertNull(CatalogueSearch.exact(products, "Permanent Marker", "Unlisted Brand"))
        assertNull(CatalogueSearch.exact(products, "Permanent Marker", "Doja", "Unlisted Grower"))
    }

    @Test fun sameBrandDifferentGrowersRemainSeparateChoices() {
        val products = OfflineCatalogue.products()
        val suggestions = CatalogueSearch.search(products, "Mamedica Cap Junky", 30)
        assertTrue(suggestions.any { it.producer == "Cheers Cannabis" })
        assertTrue(suggestions.any { it.producer == "PurpleFarm" })
        assertEquals("PurpleFarm", CatalogueSearch.exact(products, "Cap Junky", "Mamedica", "PurpleFarm")?.producer)
        assertEquals(products.size, products.distinctBy { it.id }.size)
    }

    @Test fun richerDuplicateIsUsedBeforeAnEmptyLegacyRecord() {
        val rich = CatalogueSearch.exact(OfflineCatalogue.products(), "Permanent Marker", "Doja")!!
        val empty = rich.copy(id = "old", genetics = "", commonTerpenes = "", producer = "")
        assertEquals(rich, CatalogueSearch.exact(listOf(empty, rich), "Permanent Marker", "Doja"))
    }

    @Test fun companiesWithoutLogosAndPreviouslyEnteredNamesAreSearchable() {
        assertEquals("HollyMood", Cultivators.resolve("Hollywood"))
        assertEquals("Herdade das Barrocas", Cultivators.resolve("Herdade Das Barrocas"))
        assertTrue(Cultivators.search("purple").contains("PurpleFarm"))
        assertEquals(listOf("My Grower"), Cultivators.search("my grow", listOf("My Grower")))
        assertTrue(Cultivators.all().size > 120)
    }

    @Test fun legacyReviewPhotoOrderAndStoredCompanyValuesRemainIntact() {
        val review = Review(id = 42, strainName = "Permanent Marker", brand = "Doja", cultivator = "Hollywood",
            imageUri = "file:///original/cover.jpg", imageUris = "file:///original/one.jpg\nfile:///original/two.jpg",
            thoughts = "My existing review", createdAt = 123L)
        CatalogueSearch.exact(OfflineCatalogue.products(), review.strainName, review.brand, review.cultivator)
        assertEquals(listOf("file:///original/one.jpg", "file:///original/two.jpg"), review.photos())
        assertEquals("Hollywood", review.cultivator)
        assertEquals("My existing review", review.thoughts)
        assertEquals(42L, review.id)
        assertEquals(123L, review.createdAt)
    }
}
