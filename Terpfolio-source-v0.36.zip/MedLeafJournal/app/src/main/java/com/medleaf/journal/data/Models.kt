package com.medleaf.journal.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.Normalizer

@Entity(tableName = "reviews")
data class Review(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val strainName: String,
    val brand: String = "",
    val cultivarType: String = "Hybrid",
    val thcPercent: Double? = null,
    val cbdPercent: Double? = null,
    val terpenes: String = "",
    val aroma: String = "",
    val flavour: String = "",
    val thoughts: String = "",
    val effectiveness: Int = 0,
    val flavourRating: Int = 0,
    val appearanceRating: Int = 0,
    val valueRating: Int = 0,
    val overallRating: Int = 0,
    val helpedSymptoms: String = "",
    val effects: String = "",
    val sideEffects: String = "",
    val imageUri: String? = null,
    val imageUris: String = "",
    val reviewDate: Long = System.currentTimeMillis(),
    val batchNumber: String = "",
    val pricePaid: Double? = null,
    val packSizeGrams: Double? = null,
    val isFavourite: Boolean = false,
    val visibility: String = "PRIVATE",
    val createdAt: Long = System.currentTimeMillis()
)

fun Review.photos(): List<String> = imageUris.split("\n")
    .filter(String::isNotBlank)
    .ifEmpty { listOfNotNull(imageUri) }

@Entity(tableName = "sessions")
data class MedicationSession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reviewId: Long? = null,
    val strainName: String,
    val amountGrams: Double? = null,
    val method: String = "Dry herb vaporiser",
    val temperatureC: Int? = null,
    val symptomsBefore: Int = 0,
    val reliefAfter: Int = 0,
    val notes: String = "",
    val takenAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "catalogue_products")
data class CatalogueProduct(
    @PrimaryKey val id: String,
    val productName: String,
    val cultivarName: String = "",
    val brand: String = "",
    val producer: String = "",
    val genetics: String = "",
    val cultivarType: String = "Hybrid",
    val commonTerpenes: String = "",
    val flavours: String = "",
    val aliases: String = "",
    val productCode: String = "",
    val sourceName: String = "Terpfolio starter catalogue",
    val sourceUrl: String = "",
    val lastVerified: String = "",
    val isCustom: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

fun CatalogueProduct.terpeneList() = commonTerpenes.split(",").map(String::trim).filter(String::isNotBlank)
fun CatalogueProduct.flavourList() = flavours.split(",").map(String::trim).filter(String::isNotBlank)

object CatalogueSearch {
    private fun normalise(value: String) = Normalizer.normalize(value.trim(), Normalizer.Form.NFD)
        .replace("\\p{M}+".toRegex(), "").lowercase().filter(Char::isLetterOrDigit)

    fun exact(products: List<CatalogueProduct>, text: String): CatalogueProduct? {
        val key = normalise(text)
        if (key.length < 2) return null
        return products.firstOrNull { product ->
            normalise(product.productName) == key || normalise(product.cultivarName) == key ||
                product.aliases.split(",").map(::normalise).filter(String::isNotBlank).any { it == key }
        }
    }

    fun search(products: List<CatalogueProduct>, text: String, limit: Int = 8): List<CatalogueProduct> {
        val key = normalise(text)
        if (key.length < 2) return emptyList()
        return products.mapNotNull { product ->
            val fields = listOf(product.productName, product.cultivarName, product.brand, product.producer, product.aliases, product.productCode)
                .map(::normalise).filter(String::isNotBlank)
            val score = when {
                normalise(product.productName).startsWith(key) -> 0
                normalise(product.cultivarName).startsWith(key) -> 1
                fields.any { it.startsWith(key) } -> 2
                fields.any { it.contains(key) } -> 3
                else -> return@mapNotNull null
            }
            score to product
        }.sortedWith(compareBy<Pair<Int, CatalogueProduct>> { it.first }.thenBy { it.second.productName })
            .map { it.second }.distinctBy { listOf(it.productName.lowercase(), it.brand.lowercase()) }.take(limit)
    }
}
