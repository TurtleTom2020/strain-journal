package com.medleaf.journal.ui

import android.net.Uri
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import coil.compose.rememberAsyncImagePainter
import com.medleaf.journal.R
import com.medleaf.journal.MedLeafApplication
import com.medleaf.journal.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date
import java.util.Calendar

private enum class Destination(val route: String, val label: String) {
    JOURNAL("journal", "My Reviews"), GENETICS("genetics", "Genetics"), COMMUNITY("community", "Community"), DIARY("diary", "Journal")
}
private enum class ReviewView(val label: String) { DETAILS("Details"), TILES("Tiles"), LIST("List") }
private fun Review.terpNames(): List<String> = terpenes.split(",").map(String::trim).filter(String::isNotBlank).distinctBy(String::lowercase)
private fun terpReviews(reviews: List<Review>, terpene: String) = reviews.filter { review -> review.terpNames().any { it.equals(terpene, true) } }
private fun scoreTone(score: Int): Color = when {
    score >= 8 -> Color(0xFF4F674C)
    score >= 5 -> Color(0xFF53442C)
    else -> Color(0xFF484548)
}
private data class CultivatorLogo(val drawable: Int, val needsLightPlate: Boolean = false)

private fun bundledCultivatorLogo(brand: String): CultivatorLogo? {
    val key = brand.lowercase().filter(Char::isLetterOrDigit)
    return when {
        "4clabs" in key -> CultivatorLogo(R.drawable.cultivator_4c_labs)
        "allnations" in key -> CultivatorLogo(R.drawable.cultivator_all_nations, true)
        "craftbotanics" in key -> CultivatorLogo(R.drawable.cultivator_craft_botanics, true)
        key == "doja" || "doja" in key -> CultivatorLogo(R.drawable.cultivator_doja, true)
        "ghostdrops" in key -> CultivatorLogo(R.drawable.cultivator_ghost_drops)
        "glasspharms" in key || "glasspharmacy" in key -> CultivatorLogo(R.drawable.cultivator_glass_pharms)
        "greenkarat" in key -> CultivatorLogo(R.drawable.cultivator_green_karat, true)
        "greyscales" in key || "grayscales" in key -> CultivatorLogo(R.drawable.cultivator_greyscales)
        "highgreens" in key -> CultivatorLogo(R.drawable.cultivator_highgreens, true)
        "kasaverde" in key -> CultivatorLogo(R.drawable.cultivator_kasa_verde, true)
        "mamedica" in key -> CultivatorLogo(R.drawable.cultivator_mamedica)
        key == "nce" || key == "nice" || key.startsWith("nice") -> CultivatorLogo(R.drawable.cultivator_nice)
        key == "papers" || "paperscraft" in key -> CultivatorLogo(R.drawable.cultivator_papers)
        "plantationsceres" in key || key == "ceres" -> CultivatorLogo(R.drawable.cultivator_plantations_ceres)
        "upstate" in key -> CultivatorLogo(R.drawable.cultivator_upstate, true)
        "vasco" in key -> CultivatorLogo(R.drawable.cultivator_vasco)
        else -> null
    }
}

@Composable private fun CultivatorIdentity(brand: String) {
    if (brand.isBlank()) return
    bundledCultivatorLogo(brand)?.let { logo ->
        Surface(
            color = if (logo.needsLightPlate) Color(0xFFF1F0EC) else Color.Transparent,
            shape = RoundedCornerShape(10.dp)
        ) {
            Image(
                painter = painterResource(logo.drawable),
                contentDescription = "$brand logo",
                modifier = Modifier.widthIn(max = 170.dp).height(62.dp).padding(horizontal = 8.dp, vertical = 5.dp),
                contentScale = ContentScale.Fit
            )
        }
        return
    }
    Text(brand, color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.SemiBold)
}
private fun profileHeadline(reviews: List<Review>): String {
    val recorded = reviews.filter { it.terpNames().isNotEmpty() }
    if (recorded.isEmpty()) return "Add reviews with terpenes to see your patterns"
    val groups = recorded.flatMap { review -> review.terpNames().map { it.lowercase() to review } }
        .groupBy({ it.first }, { it.second })
    fun pretty(value: String) = value.replaceFirstChar(Char::uppercase)
    if (recorded.size >= 20) {
        val pairs = recorded.flatMap { review ->
            review.terpNames().map(String::lowercase).sorted().let { names ->
                names.flatMapIndexed { index, first -> names.drop(index + 1).map { second -> (first to second) to review } }
            }
        }.groupBy({ it.first }, { it.second })
        val best = pairs.filterValues { it.size >= 5 }.maxByOrNull { it.value.map(Review::overallRating).average() }
        if (best != null) return "Together, ${pretty(best.key.first)} + ${pretty(best.key.second)} average ${"%.1f".format(best.value.map(Review::overallRating).average())}/10 across ${best.value.size} reviews"
    }
    if (recorded.size >= 8) {
        val rated = groups.filterValues { it.size >= 3 }.entries.sortedByDescending { it.value.map(Review::overallRating).average() }.take(2)
        if (rated.isNotEmpty()) return "★ Highest-rated: ${rated.joinToString(" · ") { pretty(it.key) }} · avg ${"%.1f".format(rated.first().value.map(Review::overallRating).average())}/10 (${rated.first().value.size} reviews)"
    }
    val frequent = groups.entries.sortedByDescending { it.value.size }.take(2)
    return "Most reviewed: ${frequent.joinToString(" · ") { pretty(it.key) }}"
}

class JournalViewModel(private val repository: JournalRepository) : ViewModel() {
    val reviews = repository.reviews.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val sessions = repository.sessions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val catalogue = repository.catalogue.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    var onlineCatalogueResults by mutableStateOf<List<CatalogueProduct>>(emptyList()); private set
    var onlineCatalogueSearching by mutableStateOf(false); private set
    var onlineCatalogueError by mutableStateOf<String?>(null); private set
    private var onlineSearchJob: kotlinx.coroutines.Job? = null
    init { viewModelScope.launch { repository.initialiseCatalogue() } }
    fun review(id: Long) = repository.review(id)
    fun save(review: Review, done: () -> Unit) = viewModelScope.launch { repository.save(review); done() }
    fun saveUpdate(review: Review, done: () -> Unit) = viewModelScope.launch { repository.update(review); done() }
    fun save(session: MedicationSession, done: () -> Unit) = viewModelScope.launch { repository.saveSession(session); done() }
    fun toggleFavourite(review: Review) = viewModelScope.launch { repository.update(review.copy(isFavourite = !review.isFavourite)) }
    fun importCatalogue(uri: Uri, done: (Result<Int>) -> Unit) = viewModelScope.launch { done(runCatching { repository.importCatalogue(uri) }) }
    fun searchOnlineCatalogue(query: String) {
        onlineSearchJob?.cancel()
        onlineSearchJob = viewModelScope.launch {
            onlineCatalogueResults = emptyList(); onlineCatalogueError = null; onlineCatalogueSearching = false
            if (query.trim().length < 3) return@launch
            kotlinx.coroutines.delay(500)
            onlineCatalogueSearching = true
            runCatching { repository.searchOnlineCatalogue(query) }
                .onSuccess { onlineCatalogueResults = it }
                .onFailure { if (it !is kotlinx.coroutines.CancellationException) onlineCatalogueError = "Online catalogue unavailable" }
            onlineCatalogueSearching = false
        }
    }
    fun cacheCatalogueProduct(product: CatalogueProduct) = viewModelScope.launch { repository.cacheCatalogueProduct(product) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedLeafApp() {
    val context = LocalContext.current
    val preferences = remember { context.getSharedPreferences("appearance", android.content.Context.MODE_PRIVATE) }
    var appTheme by remember { mutableStateOf(runCatching { AppTheme.valueOf(preferences.getString("theme", AppTheme.MIDNIGHT.name)!!) }.getOrDefault(AppTheme.MIDNIGHT)) }
    MedLeafTheme(appTheme) {
        MedLeafAppContent(appTheme) {
            appTheme = it
            preferences.edit().putString("theme", it.name).apply()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MedLeafAppContent(appTheme: AppTheme, onThemeChange: (AppTheme) -> Unit) {
    val context = LocalContext.current
    val app = context.applicationContext as MedLeafApplication
    val vm: JournalViewModel = viewModel(factory = object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>) = JournalViewModel(app.repository) as T
    })
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val current = entry?.destination?.route.orEmpty()
    val roots = Destination.entries
    val reviewsGrid = rememberLazyGridState()
    val showReviewFab by remember { derivedStateOf { reviewsGrid.firstVisibleItemIndex > 1 } }
    val reviews by vm.reviews.collectAsStateWithLifecycle()
    val catalogue by vm.catalogue.collectAsStateWithLifecycle()
    var moreOpen by remember { mutableStateOf(false) }
    var backupOpen by remember { mutableStateOf(false) }
    var selectedTerp by remember { mutableStateOf<String?>(null) }
    var aboutOpen by remember { mutableStateOf(false) }
    var restoreConfirm by remember { mutableStateOf(false) }
    var backupBusy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val backup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) scope.launch {
            backupBusy = true
            runCatching { BackupArchive.export(context, uri, app.repository) }
                .onSuccess { Toast.makeText(context, "Backup saved: $it", Toast.LENGTH_LONG).show() }
                .onFailure { Toast.makeText(context, "Backup failed: ${it.message}", Toast.LENGTH_LONG).show() }
            backupBusy = false
        }
    }
    val restore = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            backupBusy = true
            runCatching { BackupArchive.restore(context, uri, app.repository) }
                .onSuccess { Toast.makeText(context, "Restored ${it.first} reviews and ${it.second} journal entries; duplicates skipped", Toast.LENGTH_LONG).show() }
                .onFailure { Toast.makeText(context, "Restore failed: ${it.message}", Toast.LENGTH_LONG).show() }
            backupBusy = false
        }
    }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) {
            runCatching {
                val output = context.contentResolver.openOutputStream(uri) ?: error("Cannot open destination")
                output.bufferedWriter(Charsets.UTF_8).use { it.write(reviewsCsv(reviews)) }
            }.onSuccess { Toast.makeText(context, "Reviews exported", Toast.LENGTH_LONG).show() }
                .onFailure { Toast.makeText(context, "Export failed: ${it.message}", Toast.LENGTH_LONG).show() }
        }
    }
    val catalogueImport = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importCatalogue(uri) { result -> result
            .onSuccess { Toast.makeText(context, "$it catalogue products added or updated", Toast.LENGTH_LONG).show() }
            .onFailure { Toast.makeText(context, "Catalogue update failed: ${it.message}", Toast.LENGTH_LONG).show() }
        }
    }

    val background = when (appTheme) {
        AppTheme.MIDNIGHT -> Brush.verticalGradient(listOf(Color(0xFF050607), Color(0xFF24282B), Color(0xFF090A0B)))
        AppTheme.FOREST -> Brush.verticalGradient(listOf(Color(0xFF06140E), Color(0xFF123C2A), Color(0xFF07140F)))
        AppTheme.REGGAE -> Brush.linearGradient(listOf(Color(0xFF15120E), Color(0xFF322A14), Color(0xFF102B18)))
        AppTheme.STRAIN_WALL -> Brush.verticalGradient(listOf(Color(0xFF08090A), Color(0xFF191C1E), Color(0xFF070809)))
        AppTheme.CLINICAL -> Brush.verticalGradient(listOf(Color(0xFFF7FAF6), Color(0xFFE8F2EC)))
    }
    Box(Modifier.fillMaxSize().background(background)) {
    if (appTheme == AppTheme.STRAIN_WALL) StrainNameBackdrop()
    Scaffold(
        containerColor = Color.Transparent,
        contentColor = MaterialTheme.colorScheme.onBackground,
        topBar = {
            TopAppBar(colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent), title = {
                Column {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text("Terp", fontFamily = FontFamily.Serif, fontSize = 34.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-1.2f).sp, lineHeight = 37.sp)
                        Text("folio", fontFamily = FontFamily.Serif, fontStyle = FontStyle.Italic, fontSize = 34.sp, fontWeight = FontWeight.Medium, letterSpacing = (-1.2f).sp, lineHeight = 37.sp, color = MaterialTheme.colorScheme.secondary)
                        Image(painterResource(R.drawable.terpfolio_leaf), contentDescription = null, modifier = Modifier.padding(start = 4.dp, bottom = 5.dp).size(24.dp))
                    }
                    Text("Know what works for you", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.sp)
                }
            }, actions = {
                Box {
                    IconButton(onClick = { moreOpen = true }) { Icon(Icons.Default.MoreVert, "More options") }
                    DropdownMenu(expanded = moreOpen, onDismissRequest = { moreOpen = false }) {
                        DropdownMenuItem(text = { Text("Settings") }, leadingIcon = { Icon(Icons.Default.Settings, null) }, onClick = { moreOpen = false; nav.navigate("settings") })
                        DropdownMenuItem(text = { Text("Theme") }, leadingIcon = { Icon(Icons.Default.Palette, null) }, onClick = { moreOpen = false; nav.navigate("appearance") })
                        DropdownMenuItem(text = { Text("Backup / Restore") }, leadingIcon = { Icon(Icons.Default.FileDownload, null) }, onClick = { moreOpen = false; backupOpen = true })
                        DropdownMenuItem(text = { Text("About") }, leadingIcon = { Icon(Icons.Default.Info, null) }, onClick = { moreOpen = false; aboutOpen = true })
                    }
                }
            })
        },
        bottomBar = {
            if (roots.any { current == it.route }) NavigationBar {
                roots.forEach { item ->
                    val iconColor = when (item) {
                        Destination.JOURNAL -> MaterialTheme.colorScheme.secondary
                        Destination.GENETICS -> if (appTheme == AppTheme.CLINICAL) Color(0xFF805F30) else Color(0xFFD0AE70) // warm amber: lineage
                        Destination.COMMUNITY -> if (appTheme == AppTheme.CLINICAL) Color(0xFF296D56) else Color(0xFF8FBFAF) // sea-glass green
                        Destination.DIARY -> if (appTheme == AppTheme.CLINICAL) Color(0xFF6D4C82) else Color(0xFFBBA7D2) // muted lavender: notes
                    }
                    NavigationBarItem(
                        selected = current == item.route,
                        onClick = { nav.navigate(item.route) { popUpTo(Destination.JOURNAL.route); launchSingleTop = true } },
                        icon = {
                            Image(
                                painter = painterResource(when (item) {
                                    Destination.JOURNAL -> R.drawable.terpfolio_reviews
                                    Destination.GENETICS -> R.drawable.terpfolio_genetics
                                    Destination.COMMUNITY -> R.drawable.terpfolio_community
                                    Destination.DIARY -> R.drawable.terpfolio_journal
                                }),
                                contentDescription = null,
                                modifier = Modifier.size(when (item) { Destination.JOURNAL -> 36.dp; Destination.DIARY -> 34.dp; else -> 31.dp }),
                                contentScale = ContentScale.Fit
                            )
                        },
                        label = { Text(item.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = iconColor,
                            unselectedIconColor = iconColor,
                            selectedTextColor = MaterialTheme.colorScheme.onSurface,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            indicatorColor = if (item == Destination.JOURNAL) MaterialTheme.colorScheme.secondaryContainer else iconColor.copy(alpha = .18f)
                        )
                    )
                }
            }
        },
        floatingActionButton = {
            if (current == Destination.JOURNAL.route) AnimatedVisibility(visible = showReviewFab, enter = fadeIn() + scaleIn(initialScale = .8f), exit = fadeOut() + scaleOut(targetScale = .8f)) {
                FloatingActionButton(onClick = { nav.navigate("add-review") }, containerColor = Color.Transparent, elevation = FloatingActionButtonDefaults.elevation(5.dp)) {
                    Box(Modifier.size(56.dp).background(Brush.verticalGradient(listOf(Color(0xFF78BE90), Color(0xFF176B48))), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Add, "Add review", tint = Color.White) }
                }
            }
            if (current == Destination.DIARY.route) FloatingActionButton(onClick = { nav.navigate("add-session") }) { Icon(Icons.Default.Add, "Add session") }
        }
    ) { padding ->
        NavHost(nav, startDestination = Destination.JOURNAL.route, Modifier.padding(padding)) {
            composable(Destination.JOURNAL.route) { JournalScreen(vm, reviewsGrid, onOpen = { nav.navigate("review/$it") }, onDiscover = { nav.navigate("discover") }, onAdd = { nav.navigate("add-review") }, onInsights = { nav.navigate("insights") }, onTerp = { selectedTerp = it }) }
            composable(Destination.GENETICS.route) { GeneticsScreen(vm, onOpenReview = { nav.navigate("review/$it") }) }
            composable(Destination.COMMUNITY.route) { CommunityScreen(vm, onOpen = { nav.navigate("review/$it") }) }
            composable(Destination.DIARY.route) { DiaryScreen(vm) }
            composable("add-review") { ReviewEditor(catalogue = catalogue, onlineResults = vm.onlineCatalogueResults, onlineSearching = vm.onlineCatalogueSearching, onlineError = vm.onlineCatalogueError, onOnlineSearch = vm::searchOnlineCatalogue, onCacheProduct = vm::cacheCatalogueProduct, onSave = { vm.save(it) { nav.popBackStack() } }, onCancel = { nav.popBackStack() }) }
            composable("edit-review/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { entry ->
                val existing by vm.review(entry.arguments?.getLong("id") ?: 0).collectAsStateWithLifecycle(initialValue = null)
                existing?.let { review -> ReviewEditor(initial = review, catalogue = catalogue, onlineResults = vm.onlineCatalogueResults, onlineSearching = vm.onlineCatalogueSearching, onlineError = vm.onlineCatalogueError, onOnlineSearch = vm::searchOnlineCatalogue, onCacheProduct = vm::cacheCatalogueProduct, onSave = { vm.saveUpdate(it) { nav.popBackStack() } }, onCancel = { nav.popBackStack() }) }
            }
            composable("add-session") { SessionEditor(vm, onSave = { vm.save(it) { nav.popBackStack() } }, onCancel = { nav.popBackStack() }) }
            composable("review/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) {
                val id = it.arguments?.getLong("id") ?: 0
                ReviewDetail(vm, id, onBack = { nav.popBackStack() }, onEdit = { nav.navigate("edit-review/$id") }, onTerp = { selectedTerp = it })
            }
            composable("appearance") { AppearanceScreen(appTheme, onThemeChange, onBack = { nav.popBackStack() }) }
            composable("settings") { SettingsScreen(onTheme = { nav.navigate("appearance") }, onBackup = { backupOpen = true }, onCatalogueUpdate = { catalogueImport.launch(arrayOf("application/json", "text/json", "text/plain")) }, catalogueCount = catalogue.size, onBack = { nav.popBackStack() }) }
            composable("discover") { DiscoverScreen(vm, onBack = { nav.popBackStack() }) }
            composable("insights") { InsightScreen(vm, onBack = { nav.popBackStack() }, onTerp = { selectedTerp = it }) }
        }
    }
    if (backupOpen) AlertDialog(
        onDismissRequest = { backupOpen = false },
        title = { Text("Backup and restore") },
        text = { Text("Save your reviews, journal entries and photos in one private .zip file. Restore merges missing entries without deleting what is already on this device. Keep the file somewhere safe and private.") },
        confirmButton = { TextButton(onClick = { backupOpen = false; backup.launch("Terpfolio-backup.zip") }, enabled = !backupBusy) { Text("Create backup") } },
        dismissButton = { Column {
            TextButton(onClick = { backupOpen = false; restoreConfirm = true }, enabled = !backupBusy) { Text("Restore backup") }
            TextButton(onClick = { backupOpen = false; export.launch("Terpfolio-reviews.csv") }, enabled = reviews.isNotEmpty()) { Text("CSV only") }
        } }
    )
    if (restoreConfirm) AlertDialog(
        onDismissRequest = { restoreConfirm = false }, title = { Text("Restore a Terpfolio backup?") },
        text = { Text("Existing reviews and photos will not be overwritten. Missing reviews and journal entries from your backup will be added. Only open a backup you created and trust.") },
        confirmButton = { TextButton(onClick = { restoreConfirm = false; restore.launch(arrayOf("application/zip", "application/octet-stream")) }) { Text("Choose backup") } },
        dismissButton = { TextButton(onClick = { restoreConfirm = false }) { Text("Cancel") } }
    )
    selectedTerp?.let { terpene -> ModalBottomSheet(onDismissRequest = { selectedTerp = null }) {
        TerpeneSheet(reviews, terpene, onReview = { selectedTerp = null; nav.navigate("review/$it") })
    } }
    if (aboutOpen) AlertDialog(
        onDismissRequest = { aboutOpen = false },
        title = { Text("About Terpfolio") },
        text = { Text("Personal Strain Reviews and Genetic Guide\nVersion 0.29.0\n\nKeep track of what works for you. Your reviews stay on this device unless you choose to export them.") },
        confirmButton = { TextButton(onClick = { aboutOpen = false }) { Text("Close") } }
    )
    }
}

@Composable private fun JournalScreen(vm: JournalViewModel, gridState: LazyGridState, onOpen: (Long) -> Unit, onDiscover: () -> Unit, onAdd: () -> Unit, onInsights: () -> Unit, onTerp: (String) -> Unit) {
    val reviews by vm.reviews.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }
    var favouritesOnly by remember { mutableStateOf(false) }
    var sort by remember { mutableStateOf("Newest") }
    var sortOpen by remember { mutableStateOf(false) }
    var view by remember { mutableStateOf(ReviewView.DETAILS) }
    var viewOpen by remember { mutableStateOf(false) }
    val filtered = reviews.filter { (!favouritesOnly || it.isFavourite) && (query.isBlank() || listOf(it.strainName, it.brand, it.terpenes, it.effects, it.helpedSymptoms).any { text -> text.contains(query, true) }) }
    val shown = when (sort) {
        "Highest rating" -> filtered.sortedByDescending { it.overallRating }
        "Lowest rating" -> filtered.sortedBy { it.overallRating }
        "Oldest" -> filtered.sortedBy { it.reviewDate }
        "Name A–Z" -> filtered.sortedBy { it.strainName.lowercase() }
        "Highest THC" -> filtered.sortedByDescending { it.thcPercent ?: -1.0 }
        "Highest CBD" -> filtered.sortedByDescending { it.cbdPercent ?: -1.0 }
        "Dominant terpene" -> filtered.sortedBy { (it.terpenes.split(",").firstOrNull() ?: StrainReferences.exact(it.strainName)?.commonTerpenes?.firstOrNull()).orEmpty() }
        "Cultivator" -> filtered.sortedBy { it.brand.lowercase() }
        else -> filtered.sortedByDescending { it.reviewDate }
    }
    LazyVerticalGrid(columns = GridCells.Fixed(if (view == ReviewView.TILES) 2 else 1), state = gridState, modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 96.dp)) {
      item(key = "intro", span = { GridItemSpan(maxLineSpan) }) { Column {
        Spacer(Modifier.height(14.dp))
        Text("My Reviews", style = MaterialTheme.typography.headlineLarge.copy(fontSize = 27.sp, lineHeight = 33.sp))
        Text(if (reviews.isEmpty()) "A record of what genuinely works for you" else "${reviews.size} reviews · ${reviews.map { it.strainName.lowercase() }.distinct().size} strains", color = MaterialTheme.colorScheme.onSurfaceVariant)
        ElevatedCard(onClick = onInsights, modifier = Modifier.fillMaxWidth().padding(top = 9.dp), colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = .86f))) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 11.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.terpfolio_leaf), null, Modifier.size(26.dp)); Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text("Your Terp Profile", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.tertiary)
                    Text(profileHeadline(reviews), fontSize = 11.sp, lineHeight = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                }
                Icon(Icons.Default.ChevronRight, null, Modifier.size(18.dp))
            }
        }
        Spacer(Modifier.height(13.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.secondary.copy(alpha = .55f))
      } }
      item(key = "actions", span = { GridItemSpan(maxLineSpan) }) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ReviewAction(Modifier.weight(1f), "Discover Similar", "Based on your reviews", Icons.Default.Explore, Color(0xFF68BC91), onDiscover)
            ReviewAction(Modifier.weight(1f), "Add Review", "Record your experience", Icons.Default.Add, Color(0xFFC3A46D), onAdd)
        }
      }
      item(key = "controls", span = { GridItemSpan(maxLineSpan) }) { Column {
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = { Text("Search strains, effects or terpenes") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { favouritesOnly = !favouritesOnly }, contentPadding = PaddingValues(horizontal = 8.dp), border = BorderStroke(1.dp, if (favouritesOnly) Color(0xFF76BD98) else MaterialTheme.colorScheme.outline), modifier = Modifier.widthIn(min = 100.dp)) { Icon(if (favouritesOnly) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, modifier = Modifier.size(18.dp), tint = Color(0xFF82C5A3)); Spacer(Modifier.width(4.dp)); Text("Favourites", fontSize = 12.sp, maxLines = 1) }
            Box(Modifier.weight(1f)) {
                OutlinedButton(onClick = { sortOpen = true }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 7.dp)) { Icon(Icons.Default.Sort, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(4.dp)); Text("Sort: $sort", modifier = Modifier.weight(1f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis); Icon(Icons.Default.ArrowDropDown, null, modifier = Modifier.size(18.dp)) }
                DropdownMenu(sortOpen, { sortOpen = false }) { listOf("Newest", "Oldest", "Highest rating", "Lowest rating", "Name A–Z", "Cultivator", "Highest THC", "Highest CBD", "Dominant terpene").forEach { option -> DropdownMenuItem({ Text(option) }, { sort = option; sortOpen = false }) } }
            }
            Box {
                OutlinedIconButton(onClick = { viewOpen = true }) { Icon(Icons.Default.ViewList, "View: ${view.label}") }
                DropdownMenu(viewOpen, { viewOpen = false }) { ReviewView.entries.forEach { option -> DropdownMenuItem(text = { Text(option.label) }, leadingIcon = { Icon(if (view == option) Icons.Default.Check else when(option) { ReviewView.TILES -> Icons.Default.GridView; ReviewView.LIST -> Icons.Default.ViewList; else -> Icons.Default.ViewAgenda }, null) }, onClick = { view = option; viewOpen = false }) } }
            }
        }
      } }
      if (shown.isEmpty()) item(key = "empty", span = { GridItemSpan(maxLineSpan) }) { EmptyState(if (reviews.isEmpty()) "Your strain journal is empty" else "No reviews match that search", "Tap Add Review to record what you tried and how well it worked.") }
      else gridItems(shown, key = { it.id }) { review ->
          when (view) {
              ReviewView.DETAILS -> ReviewCard(review, onOpen, { vm.toggleFavourite(review) }, onTerp = onTerp)
              ReviewView.TILES -> ReviewCard(review, onOpen, { vm.toggleFavourite(review) }, compact = true, onTerp = onTerp)
              ReviewView.LIST -> ReviewListRow(review, onOpen)
          }
      }
    }
}

@Composable private fun ReviewAction(modifier: Modifier, title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Color, onClick: () -> Unit) {
    ElevatedCard(onClick = onClick, modifier = modifier.height(78.dp), shape = RoundedCornerShape(14.dp), colors = CardDefaults.elevatedCardColors(containerColor = accent.copy(alpha = .13f))) {
        Row(Modifier.fillMaxSize().padding(horizontal = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = accent, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(5.dp))
            Column(Modifier.weight(1f)) { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, fontWeight = FontWeight.SemiBold); Text(subtitle, maxLines = 2, fontSize = 9.sp, lineHeight = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            Icon(Icons.Default.ChevronRight, null, tint = accent, modifier = Modifier.size(12.dp))
        }
    }
}

@Composable private fun CommunityScreen(vm: JournalViewModel, onOpen: (Long) -> Unit) {
    val reviews by vm.reviews.collectAsStateWithLifecycle()
    val public = reviews.filter { it.visibility == "PUBLIC" }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Community reviews", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Public reviews are shown without medication-diary entries.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        if (public.isEmpty()) EmptyState("Nothing public yet", "Choose Public when saving a review. Cloud publishing activates after backend setup.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) { items(public, key = { it.id }) { ReviewCard(it, onOpen, { vm.toggleFavourite(it) }) } }
    }
}

@Composable private fun DiaryScreen(vm: JournalViewModel) {
    val sessions by vm.sessions.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Private medication journal", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Session entries stay on this device.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        if (sessions.isEmpty()) EmptyState("No sessions recorded", "Track dose, device, temperature, symptoms and relief.") else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(sessions, key = { it.id }) { s -> Card { Column(Modifier.padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(s.strainName, fontWeight = FontWeight.Bold); Text(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(s.takenAt)), style = MaterialTheme.typography.labelSmall) }
                Text(listOfNotNull(s.amountGrams?.let { "$it g" }, s.method, s.temperatureC?.let { "$it°C" }).joinToString(" • "))
                if (s.reliefAfter > 0) Text("Relief: ${s.reliefAfter}/10")
                if (s.notes.isNotBlank()) Text(s.notes, maxLines = 3, overflow = TextOverflow.Ellipsis)
            } } }
        }
    }
}

@Composable private fun ReviewCard(review: Review, onOpen: (Long) -> Unit, onFavourite: () -> Unit, compact: Boolean = false, onTerp: (String) -> Unit = {}) {
    val favouriteScale by animateFloatAsState(if (review.isFavourite) 1.14f else 1f, label = "Favourite")
    ElevatedCard(Modifier.fillMaxWidth().clickable { onOpen(review.id) }.animateContentSize(), shape = RoundedCornerShape(16.dp)) { Column {
        Box(Modifier.fillMaxWidth()) {
            if (review.photos().isNotEmpty()) Image(rememberAsyncImagePainter(review.photos().first()), null, Modifier.fillMaxWidth().height(if (compact) 110.dp else 180.dp), contentScale = ContentScale.Crop)
            else Box(Modifier.fillMaxWidth().height(if (compact) 110.dp else 142.dp).background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.surfaceVariant))), contentAlignment = Alignment.Center) { Image(painterResource(R.drawable.terpfolio_leaf), contentDescription = "Cannabis leaf", modifier = Modifier.size(if (compact) 70.dp else 126.dp), contentScale = ContentScale.Fit) }
            Box(Modifier.fillMaxWidth().align(Alignment.BottomCenter).height(if (compact) 34.dp else 58.dp).background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .6f)))))
            Surface(Modifier.align(Alignment.TopEnd).padding(if (compact) 5.dp else 12.dp), shape = RoundedCornerShape(50), color = scoreTone(review.overallRating)) { Text("★ ${review.overallRating}/10", Modifier.padding(horizontal = 9.dp, vertical = 5.dp), color = Color.White, fontWeight = FontWeight.Bold, fontSize = if (compact) 11.sp else 14.sp) }
        }
        Column(Modifier.padding(horizontal = if (compact) 10.dp else 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(review.strainName, style = if (compact) MaterialTheme.typography.titleMedium else MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = if (compact) 2 else 3); if (review.brand.isNotBlank()) Text(review.brand, style = MaterialTheme.typography.titleMedium.copy(fontSize = if (compact) 12.sp else 16.sp, letterSpacing = .25.sp), color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.SemiBold, maxLines = 1) }; IconButton(onFavourite, modifier = Modifier.size(if (compact) 36.dp else 48.dp)) { Icon(if (review.isFavourite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favourite", tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.graphicsLayer { scaleX = favouriteScale; scaleY = favouriteScale }) } }
            if (!compact) Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { listOf(review.cultivarType, review.thcPercent?.let { "$it% THC" }.orEmpty(), review.cbdPercent?.let { "$it% CBD" }.orEmpty()).filter { it.isNotBlank() }.forEach { value -> Surface(shape = RoundedCornerShape(50), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), color = Color.Transparent) { Text(value, Modifier.padding(horizontal = 8.dp, vertical = 4.dp), fontSize = 11.sp, maxLines = 1) } } }
            if (review.terpNames().isNotEmpty()) Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.terpfolio_leaf), null, Modifier.size(if (compact) 17.dp else 22.dp)); Spacer(Modifier.width(7.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                    review.terpNames().take(3).forEachIndexed { index, name ->
                        if (index > 0) Text("  •  ", color = Color(0xFFD0AE70))
                        Text(name, Modifier.clickable { onTerp(name) }, style = MaterialTheme.typography.bodySmall, color = Color(0xFFD0AE70), maxLines = 1)
                    }
                }
            }
            if (!compact) { HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(review.reviewDate)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant); if (review.helpedSymptoms.isNotBlank()) Text("Helped: ${review.helpedSymptoms}", Modifier.widthIn(max = 190.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelSmall) } }
        }
    } }
}

@Composable private fun ReviewListRow(review: Review, onOpen: (Long) -> Unit) {
    ElevatedCard(onClick = { onOpen(review.id) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (review.photos().isNotEmpty()) Image(rememberAsyncImagePainter(review.photos().first()), null, Modifier.size(55.dp), contentScale = ContentScale.Crop)
            else Image(painterResource(R.drawable.terpfolio_leaf), null, Modifier.size(55.dp).padding(5.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) { Text(review.strainName, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(review.brand, color = MaterialTheme.colorScheme.tertiary, fontSize = 12.sp, maxLines = 1); Text(review.terpenes.split(",").map { it.trim() }.filter { it.isNotEmpty() }.take(2).joinToString(" • "), color = Color(0xFFD0AE70), fontSize = 11.sp, maxLines = 1) }
            Text("★ ${review.overallRating}/10", color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

@Composable private fun ReviewEditor(initial: Review? = null, catalogue: List<CatalogueProduct>, onlineResults: List<CatalogueProduct>, onlineSearching: Boolean, onlineError: String?, onOnlineSearch: (String) -> Unit, onCacheProduct: (CatalogueProduct) -> Unit, onSave: (Review) -> Unit, onCancel: () -> Unit) {
    var name by remember(initial?.id) { mutableStateOf(initial?.strainName.orEmpty()) }; var brand by remember(initial?.id) { mutableStateOf(initial?.brand.orEmpty()) }; var type by remember(initial?.id) { mutableStateOf(initial?.cultivarType ?: "Hybrid") }
    var thc by remember(initial?.id) { mutableStateOf(initial?.thcPercent?.toString().orEmpty()) }; var cbd by remember(initial?.id) { mutableStateOf(initial?.cbdPercent?.toString().orEmpty()) }; var terpenes by remember(initial?.id) { mutableStateOf(initial?.terpenes.orEmpty()) }
    var aroma by remember(initial?.id) { mutableStateOf(initial?.aroma.orEmpty()) }; var flavour by remember(initial?.id) { mutableStateOf(initial?.flavour.orEmpty()) }; var thoughts by remember(initial?.id) { mutableStateOf(initial?.thoughts.orEmpty()) }
    var symptoms by remember(initial?.id) { mutableStateOf(initial?.helpedSymptoms.orEmpty()) }; var effects by remember(initial?.id) { mutableStateOf(initial?.effects.orEmpty()) }; var sideEffects by remember(initial?.id) { mutableStateOf(initial?.sideEffects.orEmpty()) }
    var overall by remember(initial?.id) { mutableIntStateOf(initial?.overallRating ?: 7) }; var effectiveness by remember(initial?.id) { mutableIntStateOf(initial?.effectiveness ?: 7) }; var flavourRating by remember(initial?.id) { mutableIntStateOf(initial?.flavourRating ?: 7) }; var appearance by remember(initial?.id) { mutableIntStateOf(initial?.appearanceRating ?: 7) }; var value by remember(initial?.id) { mutableIntStateOf(initial?.valueRating ?: 7) }
    var images by remember(initial?.id) { mutableStateOf(initial?.photos()?.map(Uri::parse) ?: emptyList()) }; var visibility by remember(initial?.id) { mutableStateOf(initial?.visibility ?: "PRIVATE") }
    var reviewDate by remember(initial?.id) { mutableLongStateOf(initial?.reviewDate ?: System.currentTimeMillis()) }; var batchNumber by remember(initial?.id) { mutableStateOf(initial?.batchNumber.orEmpty()) }
    var pricePaid by remember(initial?.id) { mutableStateOf(initial?.pricePaid?.toString().orEmpty()) }; var packSize by remember(initial?.id) { mutableStateOf(initial?.packSizeGrams?.toString().orEmpty()) }
    var selectedCatalogueId by remember(initial?.id) { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { picked ->
        picked.take(5 - images.size).forEach { uri -> runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
        images = (images + picked).distinct().take(5)
    }
    fun useProduct(product: CatalogueProduct) {
        selectedCatalogueId = product.id
        name = product.productName
        if (brand.isBlank()) brand = product.brand.ifBlank { product.producer }
        if (type == "Hybrid" && product.cultivarType.isNotBlank()) type = product.cultivarType
        if (terpenes.isBlank()) terpenes = product.commonTerpenes
        if (aroma.isBlank()) aroma = product.flavours
        if (flavour.isBlank()) flavour = product.flavours
        if (product.sourceUrl.isNotBlank()) onCacheProduct(product)
    }
    val exactCatalogueMatch = CatalogueSearch.exact(catalogue, name)
    val localSuggestions = if (exactCatalogueMatch == null) CatalogueSearch.search(catalogue, name) else emptyList()
    LaunchedEffect(name, exactCatalogueMatch?.id, localSuggestions.size) {
        if (exactCatalogueMatch == null && localSuggestions.isEmpty()) onOnlineSearch(name) else onOnlineSearch("")
    }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 32.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onCancel) { Icon(Icons.Default.ArrowBack, "Back") }; Text(if (initial == null) "New strain review" else "Edit strain review", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) } }
        item {
            Text("Photos (${images.size}/5)", fontWeight = FontWeight.SemiBold)
            if (images.isNotEmpty()) LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(images, key = { it.toString() }) { uri -> Box {
                    Image(rememberAsyncImagePainter(uri), null, Modifier.size(145.dp), contentScale = ContentScale.Crop)
                    IconButton({ images = images - uri }, Modifier.align(Alignment.TopEnd)) { Icon(Icons.Default.Cancel, "Remove photo", tint = MaterialTheme.colorScheme.error) }
                } }
            }
            if (images.size < 5) OutlinedButton({ picker.launch(arrayOf("image/*")) }, Modifier.fillMaxWidth()) { Icon(Icons.Default.AddAPhoto, null); Spacer(Modifier.width(8.dp)); Text(if (images.isEmpty()) "Add up to 5 photos" else "Add more photos") }
        }
        item { Field(name, { name = it; selectedCatalogueId = null }, "Strain name *") }
        item {
            val exactMatch = exactCatalogueMatch
            val suggestions = localSuggestions
            if (suggestions.isNotEmpty()) Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Catalogue matches", fontWeight = FontWeight.SemiBold)
                suggestions.forEach { product ->
                    ElevatedCard(onClick = { useProduct(product) }, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(product.productName, fontWeight = FontWeight.Bold)
                                Text(listOf(product.brand, product.cultivarName.takeUnless { it.equals(product.productName, true) }.orEmpty()).filter(String::isNotBlank).joinToString(" · "), color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.bodySmall)
                                if (product.genetics.isNotBlank()) Text(product.genetics, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Text("Use", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                Text("Tap a result to add reference terpenes and flavour. Your own effects, strength and batch stay personal.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else if (exactMatch != null && selectedCatalogueId == exactMatch.id) {
                Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(if (exactMatch.isCustom) "YOUR CATALOGUE" else "CATALOGUE PRODUCT", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Text(listOf(exactMatch.brand, exactMatch.producer).filter(String::isNotBlank).distinct().joinToString(" · "), style = MaterialTheme.typography.titleMedium)
                        if (exactMatch.genetics.isNotBlank()) Text("Genetics: ${exactMatch.genetics}")
                        Text("Source: ${exactMatch.sourceName}${if (exactMatch.lastVerified.isNotBlank()) " · verified ${exactMatch.lastVerified}" else ""}", style = MaterialTheme.typography.bodySmall)
                        Text("Catalogue details are a reference. Your THC/CBD and batch values are never replaced.", style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = { useProduct(exactMatch) }) { Text("Fill available catalogue details") }
                    }
                }
            } else if (onlineSearching) {
                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp); Spacer(Modifier.width(10.dp)); Text("Searching the UK catalogue…") }
            } else if (onlineResults.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Online UK catalogue", fontWeight = FontWeight.SemiBold)
                    onlineResults.forEach { product -> ElevatedCard(onClick = { useProduct(product) }, modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.CloudDownload, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(product.productName, fontWeight = FontWeight.Bold); if (product.brand.isNotBlank()) Text(product.brand, color = MaterialTheme.colorScheme.tertiary); Text(product.sourceName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Text("Use", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold) } } }
                    Text("Selecting a result saves it to your phone for future offline searches. Check its dispensing label before recording batch strength.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else if (onlineError != null && name.length >= 3) {
                Text("$onlineError — you can still enter the product manually.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }
        }
        item { Field(brand, { brand = it }, "Cultivator / producer", "e.g. Papers or Green Karat") }
        item {
            if (brand.length < 2 || Cultivators.search(brand).none { it.equals(brand, true) }) {
                val growers = Cultivators.search(brand)
                if (growers.isNotEmpty()) { Text("Select cultivator", fontWeight = FontWeight.SemiBold); LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) { items(growers) { grower -> SuggestionChip(onClick = { brand = grower }, label = { Text(grower) }) } } }
            } else AssistChip({}, { Text("Cultivator: $brand") }, leadingIcon = { Icon(Icons.Default.CheckCircle, null) })
        }
        item { Text("Cultivar type", fontWeight = FontWeight.SemiBold); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Indica", "Hybrid", "Sativa").forEach { FilterChip(type == it, { type = it }, { Text(it) }) } } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Box(Modifier.weight(1f)) { Field(thc, { thc = it.filter { c -> c.isDigit() || c == '.' } }, "THC %") }; Box(Modifier.weight(1f)) { Field(cbd, { cbd = it.filter { c -> c.isDigit() || c == '.' } }, "CBD %") } } }
        item {
            val calendar = Calendar.getInstance().apply { timeInMillis = reviewDate }
            OutlinedButton(onClick = {
                android.app.DatePickerDialog(context, { _, year, month, day ->
                    reviewDate = Calendar.getInstance().apply { set(year, month, day, 12, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
            }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.CalendarMonth, null); Spacer(Modifier.width(8.dp)); Text("Date: ${DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(reviewDate))}") }
        }
        item { Field(batchNumber, { batchNumber = it }, "Batch number (optional)", "e.g. BN240715") }
        item {
            Text("Price and value", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) { Field(pricePaid, { pricePaid = it.filter { c -> c.isDigit() || c == '.' } }, "Price paid (£)", "e.g. 130") }
                Box(Modifier.weight(1f)) { Field(packSize, { packSize = it.filter { c -> c.isDigit() || c == '.' } }, "Pack size (g)", "e.g. 10") }
            }
            val price = pricePaid.toDoubleOrNull(); val grams = packSize.toDoubleOrNull()
            if (price != null && grams != null && grams > 0) Text("£${"%.2f".format(price / grams)} per gram", color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.SemiBold)
            Text("This stays with this review, so your value rating reflects what you actually paid.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item { Field(terpenes, { terpenes = it }, "Terpenes", "e.g. limonene, myrcene") }
        item { Field(aroma, { aroma = it }, "Aroma") }; item { Field(flavour, { flavour = it }, "Flavour") }
        item { Text("YOUR EXPERIENCE", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary); Text("Only record effects you actually noticed.", style = MaterialTheme.typography.bodySmall) }
        item { Field(symptoms, { symptoms = it }, "Symptoms helped", "e.g. pain, anxiety, sleep") }; item { Field(effects, { effects = it }, "Effects you felt", "e.g. calm, focused, sleepy") }; item { Field(sideEffects, { sideEffects = it }, "Unwanted effects") }
        item { RatingSlider("Overall", overall) { overall = it } }; item { RatingSlider("Effectiveness", effectiveness) { effectiveness = it } }; item { RatingSlider("Flavour", flavourRating) { flavourRating = it } }; item { RatingSlider("Appearance", appearance) { appearance = it } }; item { RatingSlider("Value", value) { value = it } }
        item { Field(thoughts, { thoughts = it }, "Your thoughts", "What stood out? Would you get it again?", 5) }
        item { Text("Who can see this?", fontWeight = FontWeight.SemiBold); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("PRIVATE" to "Only me", "PUBLIC" to "Public").forEach { (key, label) -> FilterChip(visibility == key, { visibility = key }, { Text(label) }, leadingIcon = { Icon(if (key == "PRIVATE") Icons.Default.Lock else Icons.Default.Public, null) }) } }; if (visibility == "PUBLIC") Text("Diary sessions are never included.", style = MaterialTheme.typography.bodySmall) }
        item { Button(onClick = { onSave(Review(id=initial?.id ?: 0, strainName=name.trim(), brand=brand.trim(), cultivarType=type, thcPercent=thc.toDoubleOrNull(), cbdPercent=cbd.toDoubleOrNull(), terpenes=terpenes, aroma=aroma, flavour=flavour, thoughts=thoughts, effectiveness=effectiveness, flavourRating=flavourRating, appearanceRating=appearance, valueRating=value, overallRating=overall, helpedSymptoms=symptoms, effects=effects, sideEffects=sideEffects, imageUri=images.firstOrNull()?.toString(), imageUris=images.joinToString("\n"), reviewDate=reviewDate, batchNumber=batchNumber.trim(), pricePaid=pricePaid.toDoubleOrNull(), packSizeGrams=packSize.toDoubleOrNull(), isFavourite=initial?.isFavourite ?: false, visibility=visibility, createdAt=initial?.createdAt ?: System.currentTimeMillis())) }, enabled = name.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text(if (initial == null) "Save review" else "Save changes") } }
    }
}

@Composable private fun SessionEditor(vm: JournalViewModel, onSave: (MedicationSession) -> Unit, onCancel: () -> Unit) {
    val reviews by vm.reviews.collectAsStateWithLifecycle(); var strain by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }; var method by remember { mutableStateOf("Dry herb vaporiser") }; var temp by remember { mutableStateOf("") }; var before by remember { mutableIntStateOf(5) }; var relief by remember { mutableIntStateOf(5) }; var notes by remember { mutableStateOf("") }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onCancel) { Icon(Icons.Default.ArrowBack, "Back") }; Text("Record medication", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) } }
        if (reviews.isNotEmpty()) item { Text("Choose a reviewed strain"); Column { reviews.take(8).forEach { r -> AssistChip({ strain = r.strainName }, { Text(r.strainName) }, leadingIcon = if (strain == r.strainName) { { Icon(Icons.Default.Check, null) } } else null) } } }
        item { Field(strain, { strain = it }, "Strain name *") }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Box(Modifier.weight(1f)) { Field(amount, { amount = it.filter { c -> c.isDigit() || c == '.' } }, "Amount (g)") }; Box(Modifier.weight(1f)) { Field(temp, { temp = it.filter(Char::isDigit) }, "Temperature °C") } } }
        item { Field(method, { method = it }, "Method") }; item { RatingSlider("Symptoms before", before) { before = it } }; item { RatingSlider("Relief after", relief) { relief = it } }; item { Field(notes, { notes = it }, "Private notes", minLines = 4) }
        item { Button({ onSave(MedicationSession(strainName=strain.trim(), amountGrams=amount.toDoubleOrNull(), method=method, temperatureC=temp.toIntOrNull(), symptomsBefore=before, reliefAfter=relief, notes=notes)) }, enabled=strain.isNotBlank(), modifier=Modifier.fillMaxWidth()) { Text("Save private session") } }
    }
}

@Composable private fun ReviewDetail(vm: JournalViewModel, id: Long, onBack: () -> Unit, onEdit: () -> Unit, onTerp: (String) -> Unit) {
    val review by vm.review(id).collectAsStateWithLifecycle(initialValue = null); val r = review ?: return EmptyState("Review not found", "It may have been removed.")
    var opened by remember(id) { mutableStateOf(false) }
    LaunchedEffect(id) { opened = true }
    val photoHeight by animateDpAsState(if (opened) 260.dp else 180.dp, label = "Review photo")
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 32.dp)) {
        item { Box { if (r.photos().isNotEmpty()) LazyRow(Modifier.fillMaxWidth().height(photoHeight), horizontalArrangement = Arrangement.spacedBy(4.dp)) { items(r.photos()) { photo -> Image(rememberAsyncImagePainter(photo), null, Modifier.fillParentMaxWidth().height(photoHeight), contentScale=ContentScale.Crop) } } else Surface(Modifier.fillMaxWidth().height(160.dp), color=MaterialTheme.colorScheme.primaryContainer) {}; Surface(Modifier.align(Alignment.TopStart).padding(10.dp), shape=RoundedCornerShape(50), color=Color.Black.copy(alpha=.72f)) { IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back", tint=Color.White) } } } }
        item { Column(Modifier.padding(20.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) { Column(verticalArrangement = Arrangement.spacedBy(4.dp)) { Text(r.strainName, style=MaterialTheme.typography.headlineMedium, fontWeight=FontWeight.Bold); CultivatorIdentity(r.brand); if (r.cultivarType.isNotBlank()) Text(r.cultivarType, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Text("★ ${r.overallRating}/10", style=MaterialTheme.typography.titleLarge, color=MaterialTheme.colorScheme.secondary) }
            Button(onClick=onEdit, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Edit, null); Spacer(Modifier.width(8.dp)); Text("Edit this review") }
            Text(listOfNotNull(r.thcPercent?.let { "$it% THC" }, r.cbdPercent?.let { "$it% CBD" }).joinToString("  •  "))
            Text("Reviewed ${DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(r.reviewDate))}", color=MaterialTheme.colorScheme.onSurfaceVariant)
            StrainReferences.exact(r.strainName)?.let { reference ->
                Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.primaryContainer) { Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("LINEAGE", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text(reference.genetics, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.terpfolio_leaf), null, Modifier.size(22.dp))
                        Spacer(Modifier.width(7.dp))
                        reference.commonTerpenes.forEachIndexed { index, terpene ->
                            if (index > 0) Text("  •  ", color = Color(0xFFD0AE70), style = MaterialTheme.typography.bodySmall)
                            Text(terpene, color = Color(0xFFD0AE70), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                } }
            }
            Detail("Batch number", r.batchNumber)
            if (r.pricePaid != null) Detail("Price paid", "£${"%.2f".format(r.pricePaid)}${r.packSizeGrams?.takeIf { it > 0 }?.let { " · ${it}g pack · £${"%.2f".format(r.pricePaid / it)}/g" }.orEmpty()}")
            if (listOf(r.aroma, r.flavour, r.effects, r.helpedSymptoms, r.sideEffects, r.thoughts).any(String::isNotBlank)) {
                Text("Your review", style=MaterialTheme.typography.titleMedium, fontWeight=FontWeight.Bold)
            }
            if (r.terpNames().isNotEmpty()) { Text("Your recorded terpenes", style = MaterialTheme.typography.labelLarge); LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) { items(r.terpNames()) { name -> AssistChip(onClick = { onTerp(name) }, label = { Text(name) }, leadingIcon = { Image(painterResource(R.drawable.terpfolio_leaf), null, Modifier.size(18.dp)) }) } } }
            Detail("Aroma", r.aroma); Detail("Flavour", r.flavour); Detail("Effects", r.effects); Detail("Helped", r.helpedSymptoms); Detail("Unwanted effects", r.sideEffects); Detail("Thoughts", r.thoughts)
            HorizontalDivider(); Text("Effectiveness ${r.effectiveness}/10  •  Flavour ${r.flavourRating}/10\nAppearance ${r.appearanceRating}/10  •  Value ${r.valueRating}/10")
            AssistChip({}, { Text(if (r.visibility == "PUBLIC") "Public review" else "Private review") }, leadingIcon={ Icon(if(r.visibility=="PUBLIC") Icons.Default.Public else Icons.Default.Lock, null) })
            OutlinedButton(onClick=onEdit, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Edit, null); Spacer(Modifier.width(8.dp)); Text("Edit review details") }
        } }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable private fun GeneticsScreen(vm: JournalViewModel, onOpenReview: (Long) -> Unit) {
    val reviews by vm.reviews.collectAsStateWithLifecycle()
    val catalogue by vm.catalogue.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<CatalogueProduct?>(null) }
    val matches = CatalogueSearch.search(catalogue, query, 30)
    LaunchedEffect(query, matches.size) { if (matches.isEmpty()) vm.searchOnlineCatalogue(query) else vm.searchOnlineCatalogue("") }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { Text("Product catalogue", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("Search products, cultivars, brands, genetics, aliases or product codes", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { OutlinedTextField(query, { query = it; selected = CatalogueSearch.exact(catalogue, it) }, Modifier.fillMaxWidth(), placeholder = { Text("Try King Sherb or Green Karat") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true) }
        if (selected == null) {
            if (query.isBlank()) item { EmptyState("Explore UK products", "${catalogue.size} products are available offline. Search by prescribed product, cultivar or company.") }
            else if (matches.isEmpty() && vm.onlineCatalogueSearching) item { Row(Modifier.fillMaxWidth().padding(20.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp); Spacer(Modifier.width(10.dp)); Text("Searching the UK catalogue…") } }
            else if (matches.isEmpty() && vm.onlineCatalogueResults.isNotEmpty()) items(vm.onlineCatalogueResults, key = { it.id }) { product -> ElevatedCard(onClick = { vm.cacheCatalogueProduct(product); selected = product; query = product.productName }, modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text(product.productName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); if (product.brand.isNotBlank()) Text(product.brand, color = MaterialTheme.colorScheme.tertiary); Text("Online · ${product.sourceName}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
            else if (matches.isEmpty()) item { EmptyState("Product not found", "You can still review it manually. Terpfolio will remember it locally after you save the review.") }
            else items(matches, key = { it.id }) { product -> ElevatedCard(onClick = { selected = product; query = product.productName }, modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text(product.productName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Text(listOf(product.brand, product.cultivarName.takeUnless { it.equals(product.productName, true) }.orEmpty()).filter(String::isNotBlank).joinToString(" · "), color = MaterialTheme.colorScheme.tertiary); if (product.genetics.isNotBlank()) Text(product.genetics); Text(product.terpeneList().joinToString(" • "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
        } else {
            val product = selected!!
            item { ElevatedCard(Modifier.fillMaxWidth(), colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Column { Text(product.productName, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text(product.brand.ifBlank { product.producer }, color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.SemiBold) }; Icon(Icons.Default.AccountTree, null, Modifier.size(34.dp)) }
                if (product.cultivarName.isNotBlank() && !product.cultivarName.equals(product.productName, true)) Detail("Cultivar", product.cultivarName)
                Detail("Genetics", product.genetics)
                Detail("Product code", product.productCode)
                HorizontalDivider()
                Text("Commonly reported terpenes", fontWeight = FontWeight.Bold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) { product.terpeneList().forEach { terpene -> SuggestionChip({}, { Text(terpene) }) } }
                if (product.flavourList().isNotEmpty()) { Text("Reference flavour profile", fontWeight = FontWeight.Bold); Text(product.flavourList().joinToString(" • ")) }
                Text("Source: ${product.sourceName}${if (product.lastVerified.isNotBlank()) " · verified ${product.lastVerified}" else ""}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                Text("Reference information can vary by producer, phenotype and batch. Always use your dispensing label for medicine strength.", style = MaterialTheme.typography.bodySmall)
            } } }
            val journalMatches = reviews.filter { it.strainName.equals(product.productName, true) }
            if (journalMatches.isNotEmpty()) item { Text("Your ${product.productName} reviews", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            items(journalMatches, key = { it.id }) { review -> ReviewCard(review, onOpenReview, { vm.toggleFavourite(review) }) }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable private fun DiscoverScreen(vm: JournalViewModel, onBack: () -> Unit) {
    val reviews by vm.reviews.collectAsStateWithLifecycle()
    var flavours by remember { mutableStateOf(setOf<String>()) }
    var terpenes by remember { mutableStateOf(setOf<String>()) }
    var learnFromReviews by remember { mutableStateOf(true) }
    val favourites = reviews.filter { it.isFavourite || it.overallRating >= 8 }
    val likedReferences = if (learnFromReviews) favourites.mapNotNull { StrainReferences.exact(it.strainName) } else emptyList()
    val likedTerpenes = if (learnFromReviews) favourites.flatMap(Review::terpNames).toSet() else emptySet()
    val likedFlavours = likedReferences.flatMap { it.flavours }.toSet()
    val wantedTerpenes = terpenes + likedTerpenes
    val wantedFlavours = flavours + likedFlavours
    val reviewedNames = reviews.map { it.strainName.lowercase() }.toSet()
    val suggestions = if (wantedTerpenes.isEmpty() && wantedFlavours.isEmpty()) emptyList() else
        StrainReferences.all().filterNot { it.name.lowercase() in reviewedNames }
            .map { reference ->
                val matchedTerpenes = reference.commonTerpenes.filter { candidate -> wantedTerpenes.any { it.equals(candidate, true) } }
                val matchedFlavours = reference.flavours.filter { candidate -> wantedFlavours.any { it.equals(candidate, true) } }
                reference to (matchedTerpenes + matchedFlavours)
            }.filter { it.second.isNotEmpty() }.sortedWith(compareByDescending<Pair<StrainReference, List<String>>> { it.second.size }.thenBy { it.first.name }).take(12)
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(bottom = 32.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back") }; Text("Find your next strain", style = MaterialTheme.typography.headlineSmall) } }
        item { Text("Explore shared terpenes and flavours from the app’s small reference catalogue. Your high-rated reviews help choose what to compare; this is not a medical prediction.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { Text("Flavours you like", style = MaterialTheme.typography.titleLarge); FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Gas", "Diesel", "Citrus", "Grape", "Berry", "Mint", "Earthy", "Sweet", "Cream", "Pine").forEach { choice -> FilterChip(choice in flavours, { flavours = if (choice in flavours) flavours - choice else flavours + choice }, { Text(choice) }) } } }
        item { Text("Terpenes you want to explore", style = MaterialTheme.typography.titleLarge); FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Limonene", "Caryophyllene", "Myrcene", "Linalool", "Pinene", "Humulene").forEach { choice -> FilterChip(choice in terpenes, { terpenes = if (choice in terpenes) terpenes - choice else terpenes + choice }, { Text(choice) }) } } }
        item { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(learnFromReviews, { learnFromReviews = it }); Column { Text("Use strains I rated 8+ or favourited"); Text("Your recorded terpenes and catalogue flavours; not a medical prediction", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
        item { HorizontalDivider(); Text("Potential matches", style = MaterialTheme.typography.headlineSmall) }
        if (suggestions.isEmpty()) item { Text("Choose a flavour or terpene to see matches. You can also rate or favourite a known strain first.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(suggestions, key = { it.first.name }) { (reference, matches) ->
            ElevatedCard(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(reference.name, style = MaterialTheme.typography.titleLarge)
                Text(reference.genetics, style = MaterialTheme.typography.bodyMedium)
                Text("Shared profile: ${matches.joinToString(" · ")}", color = MaterialTheme.colorScheme.secondary)
                val liked = favourites.filter { review -> review.terpNames().any { terp -> matches.any { it.equals(terp, true) } } }.take(2)
                if (liked.isNotEmpty() && learnFromReviews) Text("Also recorded in your highly rated ${liked.joinToString(" and ") { it.strainName }}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary)
            } }
        }
        item { Text("These are similarities, not a guarantee of effects, quality or suitability. Check the actual cultivar and batch details before ordering.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable private fun InsightScreen(vm: JournalViewModel, onBack: () -> Unit, onTerp: (String) -> Unit) {
    val reviews by vm.reviews.collectAsStateWithLifecycle()
    val names = reviews.flatMap(Review::terpNames).distinctBy(String::lowercase).sortedWith(compareByDescending<String> { terpReviews(reviews, it).size }.thenBy { it })
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 32.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back") }; Text("Your Terp Profile", style = MaterialTheme.typography.headlineSmall) } }
        item { Text("Based only on terpenes and effects you recorded. A shared terpene does not mean a strain will work the same way for you.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        if (names.isEmpty()) item { EmptyState("No terpene patterns yet", "Add terpenes to your reviews to begin exploring.") }
        items(names, key = { it.lowercase() }) { name ->
            val matched = terpReviews(reviews, name)
            ElevatedCard(onClick = { onTerp(name) }, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.terpfolio_leaf), null, Modifier.size(27.dp)); Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text(name, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.tertiary); Text("${matched.size} ${if (matched.size == 1) "review" else "reviews"} · personal average ${"%.1f".format(matched.map { it.overallRating }.average())}/10", style = MaterialTheme.typography.bodySmall) }
                    Icon(Icons.Default.ChevronRight, null)
                }
            }
        }
    }
}

@Composable private fun TerpeneSheet(reviews: List<Review>, name: String, onReview: (Long) -> Unit) {
    val matched = terpReviews(reviews, name)
    val effects = matched.flatMap { it.effects.split(",") }.map(String::trim).filter(String::isNotBlank).groupingBy(String::lowercase).eachCount().entries.sortedByDescending { it.value }.take(4)
    val catalogue = StrainReferences.all().filter { reference -> reference.commonTerpenes.any { it.equals(name, true) } }
    LazyColumn(Modifier.fillMaxWidth().heightIn(max = 560.dp).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(13.dp), contentPadding = PaddingValues(bottom = 32.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { Image(painterResource(R.drawable.terpfolio_leaf), null, Modifier.size(29.dp)); Spacer(Modifier.width(9.dp)); Text(name, style = MaterialTheme.typography.headlineSmall) } }
        item { Text("YOUR RECORDS", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.tertiary) }
        item { Text("${matched.size} ${if (matched.size == 1) "review" else "reviews"} ${if (matched.isEmpty()) "so far" else "· average personal rating ${"%.1f".format(matched.map { it.overallRating }.average())}/10"}", style = MaterialTheme.typography.titleMedium) }
        if (effects.isNotEmpty()) item { Text("Effects you wrote down in these reviews: ${effects.joinToString(" · ") { "${it.key} (${it.value})" }}", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        if (catalogue.isNotEmpty()) item { Text("IN THE CATALOGUE", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.tertiary); Text("Listed for ${catalogue.size} reference strains, including ${catalogue.take(3).joinToString(" · ") { it.name }}.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { Text("These are correlations in your notes, not effects caused by this terpene or predictions about a new strain.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(matched, key = { it.id }) { review -> ElevatedCard(onClick = { onReview(review.id) }, modifier = Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Text(review.strainName, Modifier.weight(1f), fontWeight = FontWeight.SemiBold); Text("★ ${review.overallRating}/10", color = MaterialTheme.colorScheme.secondary) } } }
    }
}

@Composable private fun SettingsScreen(onTheme: () -> Unit, onBackup: () -> Unit, onCatalogueUpdate: () -> Unit, catalogueCount: Int, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back") }; Text("Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        ElevatedCard(onClick = onTheme, modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Palette, null); Spacer(Modifier.width(16.dp)); Text("Choose theme") } }
        ElevatedCard(onClick = onBackup, modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(16.dp)); Text("Backup and restore") } }
        ElevatedCard(onClick = onCatalogueUpdate, modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.SystemUpdateAlt, null); Spacer(Modifier.width(16.dp)); Column { Text("Update product catalogue"); Text("$catalogueCount products available offline", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
        Text("Import a Terpfolio catalogue JSON file without reinstalling the app. Existing reviews, custom products and batch strengths stay untouched.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("Your reviews remain on this device unless you export them. A full backup includes photos and private journal entries; keep it private.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable private fun AppearanceScreen(current: AppTheme, onThemeChange: (AppTheme) -> Unit, onBack: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back") }; Column { Text("Choose your look", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("You can change this whenever you like", color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
        items(AppTheme.entries) { option -> ElevatedCard(onClick = { onThemeChange(option) }, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.elevatedCardColors(containerColor = if (current == option) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface)) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(if (current == option) Icons.Default.CheckCircle else Icons.Default.Palette, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(14.dp)); Column { Text(option.title, fontWeight = FontWeight.Bold); Text(option.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant) } } } }
        item { Text("Custom backgrounds and artwork are planned next. Background images will include a strength control so text stays readable.", style = MaterialTheme.typography.bodyMedium) }
    }
}

@Composable private fun Field(value:String, change:(String)->Unit, label:String, hint:String="", minLines:Int=1) = OutlinedTextField(value, change, Modifier.fillMaxWidth(), label={Text(label)}, placeholder={if(hint.isNotBlank()) Text(hint)}, minLines=minLines)
@Composable private fun RatingSlider(label:String, value:Int, change:(Int)->Unit) { Column { Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) { Text(label, fontWeight=FontWeight.SemiBold); Text("$value/10") }; Slider(value.toFloat(), { change(it.toInt()) }, valueRange=0f..10f, steps=9) } }
@Composable private fun Detail(label:String, value:String) { if(value.isNotBlank()) Column { Text(label, style=MaterialTheme.typography.labelLarge, color=MaterialTheme.colorScheme.primary); Text(value) } }
private fun reviewsCsv(reviews: List<Review>): String {
    fun cell(value: Any?): String {
        val raw = value?.toString().orEmpty()
        // Spreadsheet applications may execute cells beginning with a formula prefix.
        val first = raw.trimStart().firstOrNull()
        val safe = if (first == '=' || first == '+' || first == '-' || first == '@') "'$raw" else raw
        return "\"${safe.replace("\"", "\"\"")}\""
    }
    val header = listOf("Strain", "Cultivator", "Type", "THC %", "CBD %", "Terpenes", "Aroma", "Flavour", "Thoughts", "Effectiveness /10", "Flavour rating /10", "Appearance /10", "Value /10", "Overall /10", "Symptoms helped", "Effects felt", "Unwanted effects", "Review date (Unix ms)", "Batch number", "Price paid (£)", "Pack size (g)", "Price per gram (£)", "Favourite", "Visibility", "Created (Unix ms)")
    val lines = reviews.map { r -> listOf(r.strainName, r.brand, r.cultivarType, r.thcPercent, r.cbdPercent, r.terpenes, r.aroma, r.flavour, r.thoughts, r.effectiveness, r.flavourRating, r.appearanceRating, r.valueRating, r.overallRating, r.helpedSymptoms, r.effects, r.sideEffects, r.reviewDate, r.batchNumber, r.pricePaid, r.packSizeGrams, if (r.pricePaid != null && r.packSizeGrams != null && r.packSizeGrams > 0) r.pricePaid / r.packSizeGrams else null, r.isFavourite, r.visibility, r.createdAt).joinToString(",") { cell(it) } }
    return "\uFEFF" + (listOf(header.joinToString(",") { cell(it) }) + lines).joinToString("\r\n", postfix = "\r\n")
}
@Composable private fun StrainNameBackdrop() {
    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.strain_wall_mylar_v2),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(
                        Color.Black.copy(alpha = .10f),
                        Color.Black.copy(alpha = .42f),
                        Color.Black.copy(alpha = .50f)
                    )
                )
            )
        )
    }
}
@Composable private fun EmptyState(title:String, body:String) { Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment=Alignment.Center) { Column(horizontalAlignment=Alignment.CenterHorizontally) { Icon(Icons.Default.Spa, null, Modifier.size(54.dp), tint=MaterialTheme.colorScheme.primary); Spacer(Modifier.height(12.dp)); Text(title, style=MaterialTheme.typography.titleMedium, fontWeight=FontWeight.Bold); Text(body, color=MaterialTheme.colorScheme.onSurfaceVariant) } } }
