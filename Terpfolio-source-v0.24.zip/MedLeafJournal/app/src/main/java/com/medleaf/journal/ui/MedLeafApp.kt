package com.medleaf.journal.ui

import android.net.Uri
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import coil.compose.rememberAsyncImagePainter
import com.medleaf.journal.R
import com.medleaf.journal.MedLeafApplication
import com.medleaf.journal.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date
import java.util.Calendar

private enum class Destination(val route: String, val label: String) {
    JOURNAL("journal", "My Reviews"), GENETICS("genetics", "Genetics"), COMMUNITY("community", "Community"), DIARY("diary", "Journal")
}

class JournalViewModel(private val repository: JournalRepository) : ViewModel() {
    val reviews = repository.reviews.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val sessions = repository.sessions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun review(id: Long) = repository.review(id)
    fun save(review: Review, done: () -> Unit) = viewModelScope.launch { repository.save(review); done() }
    fun saveUpdate(review: Review, done: () -> Unit) = viewModelScope.launch { repository.update(review); done() }
    fun save(session: MedicationSession, done: () -> Unit) = viewModelScope.launch { repository.saveSession(session); done() }
    fun toggleFavourite(review: Review) = viewModelScope.launch { repository.update(review.copy(isFavourite = !review.isFavourite)) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedLeafApp() {
    val context = LocalContext.current
    val preferences = remember { context.getSharedPreferences("appearance", android.content.Context.MODE_PRIVATE) }
    var appTheme by remember { mutableStateOf(runCatching { AppTheme.valueOf(preferences.getString("theme", AppTheme.MIDNIGHT.name)!!) }.getOrDefault(AppTheme.MIDNIGHT)) }
    MedLeafTheme(appTheme) {
        MedLeafAppContent(appTheme) {
            appTheme = it
            preferences.edit().putString("theme", it.name).apply()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MedLeafAppContent(appTheme: AppTheme, onThemeChange: (AppTheme) -> Unit) {
    val app = LocalContext.current.applicationContext as MedLeafApplication
    val vm: JournalViewModel = viewModel(factory = object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>) = JournalViewModel(app.repository) as T
    })
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val current = entry?.destination?.route.orEmpty()
    val roots = Destination.entries

    val background = when (appTheme) {
        AppTheme.MIDNIGHT -> Brush.verticalGradient(listOf(Color(0xFF050607), Color(0xFF24282B), Color(0xFF090A0B)))
        AppTheme.FOREST -> Brush.verticalGradient(listOf(Color(0xFF06140E), Color(0xFF123C2A), Color(0xFF07140F)))
        AppTheme.REGGAE -> Brush.linearGradient(listOf(Color(0xFF15120E), Color(0xFF322A14), Color(0xFF102B18)))
        AppTheme.STRAIN_WALL -> Brush.verticalGradient(listOf(Color(0xFF08090A), Color(0xFF191C1E), Color(0xFF070809)))
        AppTheme.CLINICAL -> Brush.verticalGradient(listOf(Color(0xFFF7FAF6), Color(0xFFE8F2EC)))
    }
    Box(Modifier.fillMaxSize().background(background)) {
    if (appTheme == AppTheme.STRAIN_WALL) StrainNameBackdrop()
    Scaffold(
        containerColor = Color.Transparent,
        contentColor = MaterialTheme.colorScheme.onBackground,
        topBar = {
            TopAppBar(colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent), title = {
                Column {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text("Terp", fontFamily = FontFamily.Serif, fontSize = 34.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-1.2f).sp, lineHeight = 37.sp)
                        Text("folio", fontFamily = FontFamily.Serif, fontStyle = FontStyle.Italic, fontSize = 34.sp, fontWeight = FontWeight.Medium, letterSpacing = (-1.2f).sp, lineHeight = 37.sp, color = MaterialTheme.colorScheme.secondary)
                    }
                    Text("Know what works for you", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.sp)
                }
            }, actions = { IconButton({ nav.navigate("appearance") }) { Icon(Icons.Default.Palette, "Appearance") } })
        },
        bottomBar = {
            if (roots.any { current == it.route }) NavigationBar {
                roots.forEach { item ->
                    val iconColor = when (item) {
                        Destination.JOURNAL -> MaterialTheme.colorScheme.secondary
                        Destination.GENETICS -> if (appTheme == AppTheme.CLINICAL) Color(0xFF805F30) else Color(0xFFD0AE70) // warm amber: lineage
                        Destination.COMMUNITY -> if (appTheme == AppTheme.CLINICAL) Color(0xFF296D56) else Color(0xFF8FBFAF) // sea-glass green
                        Destination.DIARY -> if (appTheme == AppTheme.CLINICAL) Color(0xFF6D4C82) else Color(0xFFBBA7D2) // muted lavender: notes
                    }
                    NavigationBarItem(
                        selected = current == item.route,
                        onClick = { nav.navigate(item.route) { popUpTo(Destination.JOURNAL.route); launchSingleTop = true } },
                        icon = {
                            Image(
                                painter = painterResource(when (item) {
                                    Destination.JOURNAL -> R.drawable.terpfolio_reviews
                                    Destination.GENETICS -> R.drawable.terpfolio_genetics
                                    Destination.COMMUNITY -> R.drawable.terpfolio_community
                                    Destination.DIARY -> R.drawable.terpfolio_journal
                                }),
                                contentDescription = null,
                                modifier = Modifier.size(when (item) { Destination.JOURNAL -> 36.dp; Destination.DIARY -> 34.dp; else -> 31.dp }),
                                contentScale = ContentScale.Fit
                            )
                        },
                        label = { Text(item.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = iconColor,
                            unselectedIconColor = iconColor,
                            selectedTextColor = MaterialTheme.colorScheme.onSurface,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            indicatorColor = if (item == Destination.JOURNAL) MaterialTheme.colorScheme.secondaryContainer else iconColor.copy(alpha = .18f)
                        )
                    )
                }
            }
        },
        floatingActionButton = {
            if (current == Destination.JOURNAL.route) FloatingActionButton(onClick = { nav.navigate("add-review") }) { Icon(Icons.Default.Add, "Add review") }
            if (current == Destination.DIARY.route) FloatingActionButton(onClick = { nav.navigate("add-session") }) { Icon(Icons.Default.Add, "Add session") }
        }
    ) { padding ->
        NavHost(nav, startDestination = Destination.JOURNAL.route, Modifier.padding(padding)) {
            composable(Destination.JOURNAL.route) { JournalScreen(vm, onOpen = { nav.navigate("review/$it") }, onDiscover = { nav.navigate("discover") }) }
            composable(Destination.GENETICS.route) { GeneticsScreen(vm, onOpenReview = { nav.navigate("review/$it") }) }
            composable(Destination.COMMUNITY.route) { CommunityScreen(vm, onOpen = { nav.navigate("review/$it") }) }
            composable(Destination.DIARY.route) { DiaryScreen(vm) }
            composable("add-review") { ReviewEditor(onSave = { vm.save(it) { nav.popBackStack() } }, onCancel = { nav.popBackStack() }) }
            composable("edit-review/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { entry ->
                val existing by vm.review(entry.arguments?.getLong("id") ?: 0).collectAsStateWithLifecycle(initialValue = null)
                existing?.let { review -> ReviewEditor(initial = review, onSave = { vm.saveUpdate(it) { nav.popBackStack() } }, onCancel = { nav.popBackStack() }) }
            }
            composable("add-session") { SessionEditor(vm, onSave = { vm.save(it) { nav.popBackStack() } }, onCancel = { nav.popBackStack() }) }
            composable("review/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) {
                val id = it.arguments?.getLong("id") ?: 0
                ReviewDetail(vm, id, onBack = { nav.popBackStack() }, onEdit = { nav.navigate("edit-review/$id") })
            }
            composable("appearance") { AppearanceScreen(appTheme, onThemeChange, onBack = { nav.popBackStack() }) }
            composable("discover") { DiscoverScreen(vm, onBack = { nav.popBackStack() }) }
        }
    }
    }
}

@Composable private fun JournalScreen(vm: JournalViewModel, onOpen: (Long) -> Unit, onDiscover: () -> Unit) {
    val reviews by vm.reviews.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) {
            runCatching {
                val output = context.contentResolver.openOutputStream(uri) ?: error("Cannot open destination")
                output.bufferedWriter(Charsets.UTF_8).use { it.write(reviewsCsv(reviews)) }
            }.onSuccess { Toast.makeText(context, "Reviews exported", Toast.LENGTH_LONG).show() }
                .onFailure { Toast.makeText(context, "Export failed: ${it.message}", Toast.LENGTH_LONG).show() }
        }
    }
    var query by remember { mutableStateOf("") }
    var favouritesOnly by remember { mutableStateOf(false) }
    var sort by remember { mutableStateOf("Newest") }
    var sortOpen by remember { mutableStateOf(false) }
    val filtered = reviews.filter { (!favouritesOnly || it.isFavourite) && (query.isBlank() || listOf(it.strainName, it.brand, it.terpenes, it.effects, it.helpedSymptoms).any { text -> text.contains(query, true) }) }
    val shown = when (sort) {
        "Highest rating" -> filtered.sortedByDescending { it.overallRating }
        "Lowest rating" -> filtered.sortedBy { it.overallRating }
        "Oldest" -> filtered.sortedBy { it.reviewDate }
        "Name A–Z" -> filtered.sortedBy { it.strainName.lowercase() }
        "Highest THC" -> filtered.sortedByDescending { it.thcPercent ?: -1.0 }
        "Highest CBD" -> filtered.sortedByDescending { it.cbdPercent ?: -1.0 }
        "Dominant terpene" -> filtered.sortedBy { (it.terpenes.split(",").firstOrNull() ?: StrainReferences.exact(it.strainName)?.commonTerpenes?.firstOrNull()).orEmpty() }
        "Cultivator" -> filtered.sortedBy { it.brand.lowercase() }
        else -> filtered.sortedByDescending { it.reviewDate }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(14.dp))
        Text("Your Reviews", style = MaterialTheme.typography.headlineLarge.copy(fontSize = 32.sp, lineHeight = 38.sp))
        Text(if (reviews.isEmpty()) "A record of what genuinely works for you" else "${reviews.size} reviews · ${reviews.map { it.strainName.lowercase() }.distinct().size} strains", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(18.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.secondary.copy(alpha = .55f))
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onDiscover) { Icon(Icons.Default.Explore, null); Spacer(Modifier.width(6.dp)); Text("Find similar") }
            TextButton(onClick = { export.launch("Terpfolio-reviews.csv") }, enabled = reviews.isNotEmpty()) { Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(6.dp)); Text("Export CSV") }
        }
        Text("CSV backup includes private notes, but not photos. Keep it private; import is not available yet.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = { Text("Search strains, effects or terpenes") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(favouritesOnly, { favouritesOnly = !favouritesOnly }, label = { Text("Favourites") }, leadingIcon = { Icon(Icons.Default.Favorite, null) })
            Box { FilterChip(true, { sortOpen = true }, label = { Text(sort) }, leadingIcon = { Icon(Icons.Default.Sort, null) }); DropdownMenu(sortOpen, { sortOpen = false }) { listOf("Newest", "Oldest", "Highest rating", "Lowest rating", "Name A–Z", "Cultivator", "Highest THC", "Highest CBD", "Dominant terpene").forEach { option -> DropdownMenuItem({ Text(option) }, { sort = option; sortOpen = false }) } } }
        }
        if (shown.isEmpty()) EmptyState(if (reviews.isEmpty()) "Your strain journal is empty" else "No reviews match that search", "Tap + to record what you tried and how well it worked.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 96.dp)) {
            items(shown, key = { it.id }) { ReviewCard(it, onOpen, { vm.toggleFavourite(it) }) }
        }
    }
}

@Composable private fun CommunityScreen(vm: JournalViewModel, onOpen: (Long) -> Unit) {
    val reviews by vm.reviews.collectAsStateWithLifecycle()
    val public = reviews.filter { it.visibility == "PUBLIC" }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Community reviews", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Public reviews are shown without medication-diary entries.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        if (public.isEmpty()) EmptyState("Nothing public yet", "Choose Public when saving a review. Cloud publishing activates after backend setup.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) { items(public, key = { it.id }) { ReviewCard(it, onOpen, { vm.toggleFavourite(it) }) } }
    }
}

@Composable private fun DiaryScreen(vm: JournalViewModel) {
    val sessions by vm.sessions.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Private medication journal", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Session entries stay on this device.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        if (sessions.isEmpty()) EmptyState("No sessions recorded", "Track dose, device, temperature, symptoms and relief.") else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(sessions, key = { it.id }) { s -> Card { Column(Modifier.padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(s.strainName, fontWeight = FontWeight.Bold); Text(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(s.takenAt)), style = MaterialTheme.typography.labelSmall) }
                Text(listOfNotNull(s.amountGrams?.let { "$it g" }, s.method, s.temperatureC?.let { "$it°C" }).joinToString(" • "))
                if (s.reliefAfter > 0) Text("Relief: ${s.reliefAfter}/10")
                if (s.notes.isNotBlank()) Text(s.notes, maxLines = 3, overflow = TextOverflow.Ellipsis)
            } } }
        }
    }
}

@Composable private fun ReviewCard(review: Review, onOpen: (Long) -> Unit, onFavourite: () -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth().clickable { onOpen(review.id) }, shape = RoundedCornerShape(12.dp)) { Column {
        Box(Modifier.fillMaxWidth()) {
            if (review.photos().isNotEmpty()) Image(rememberAsyncImagePainter(review.photos().first()), null, Modifier.fillMaxWidth().height(180.dp), contentScale = ContentScale.Crop)
            else Box(Modifier.fillMaxWidth().height(142.dp).background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.surfaceVariant))), contentAlignment = Alignment.Center) { Image(painterResource(R.drawable.terpfolio_leaf), contentDescription = "Cannabis leaf", modifier = Modifier.size(126.dp), contentScale = ContentScale.Fit) }
            Surface(Modifier.align(Alignment.TopEnd).padding(12.dp), shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.secondaryContainer) { Text("★ ${review.overallRating}/10", Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = MaterialTheme.colorScheme.onSecondaryContainer, fontWeight = FontWeight.Bold) }
        }
        Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(review.strainName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); if (review.brand.isNotBlank()) Text(review.brand, style = MaterialTheme.typography.titleMedium.copy(fontSize = 16.sp, letterSpacing = .25.sp), color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.SemiBold) }; IconButton(onFavourite) { Icon(if (review.isFavourite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favourite", tint = MaterialTheme.colorScheme.tertiary) } }
            Text(listOf(review.cultivarType, review.thcPercent?.let { "$it% THC" }.orEmpty(), review.cbdPercent?.let { "$it% CBD" }.orEmpty()).filter { it.isNotBlank() }.joinToString("  •  "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (review.terpenes.isNotBlank()) Text(review.terpenes.split(",").take(3).joinToString("  •  "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(review.reviewDate)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant); if (review.helpedSymptoms.isNotBlank()) Text("Helped: ${review.helpedSymptoms}", Modifier.widthIn(max = 190.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelSmall) }
        }
    } }
}

@Composable private fun ReviewEditor(initial: Review? = null, onSave: (Review) -> Unit, onCancel: () -> Unit) {
    var name by remember(initial?.id) { mutableStateOf(initial?.strainName.orEmpty()) }; var brand by remember(initial?.id) { mutableStateOf(initial?.brand.orEmpty()) }; var type by remember(initial?.id) { mutableStateOf(initial?.cultivarType ?: "Hybrid") }
    var thc by remember(initial?.id) { mutableStateOf(initial?.thcPercent?.toString().orEmpty()) }; var cbd by remember(initial?.id) { mutableStateOf(initial?.cbdPercent?.toString().orEmpty()) }; var terpenes by remember(initial?.id) { mutableStateOf(initial?.terpenes.orEmpty()) }
    var aroma by remember(initial?.id) { mutableStateOf(initial?.aroma.orEmpty()) }; var flavour by remember(initial?.id) { mutableStateOf(initial?.flavour.orEmpty()) }; var thoughts by remember(initial?.id) { mutableStateOf(initial?.thoughts.orEmpty()) }
    var symptoms by remember(initial?.id) { mutableStateOf(initial?.helpedSymptoms.orEmpty()) }; var effects by remember(initial?.id) { mutableStateOf(initial?.effects.orEmpty()) }; var sideEffects by remember(initial?.id) { mutableStateOf(initial?.sideEffects.orEmpty()) }
    var overall by remember(initial?.id) { mutableIntStateOf(initial?.overallRating ?: 7) }; var effectiveness by remember(initial?.id) { mutableIntStateOf(initial?.effectiveness ?: 7) }; var flavourRating by remember(initial?.id) { mutableIntStateOf(initial?.flavourRating ?: 7) }; var appearance by remember(initial?.id) { mutableIntStateOf(initial?.appearanceRating ?: 7) }; var value by remember(initial?.id) { mutableIntStateOf(initial?.valueRating ?: 7) }
    var images by remember(initial?.id) { mutableStateOf(initial?.photos()?.map(Uri::parse) ?: emptyList()) }; var visibility by remember(initial?.id) { mutableStateOf(initial?.visibility ?: "PRIVATE") }
    var reviewDate by remember(initial?.id) { mutableLongStateOf(initial?.reviewDate ?: System.currentTimeMillis()) }; var batchNumber by remember(initial?.id) { mutableStateOf(initial?.batchNumber.orEmpty()) }
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { picked ->
        picked.take(5 - images.size).forEach { uri -> runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
        images = (images + picked).distinct().take(5)
    }
    fun useReference(reference: StrainReference) {
        name = reference.name
        if (terpenes.isBlank()) terpenes = reference.commonTerpenes.joinToString(", ")
        if (aroma.isBlank()) aroma = reference.flavours.joinToString(", ")
        if (flavour.isBlank()) flavour = reference.flavours.joinToString(", ")
    }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 32.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onCancel) { Icon(Icons.Default.ArrowBack, "Back") }; Text(if (initial == null) "New strain review" else "Edit strain review", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) } }
        item {
            Text("Photos (${images.size}/5)", fontWeight = FontWeight.SemiBold)
            if (images.isNotEmpty()) LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(images, key = { it.toString() }) { uri -> Box {
                    Image(rememberAsyncImagePainter(uri), null, Modifier.size(145.dp), contentScale = ContentScale.Crop)
                    IconButton({ images = images - uri }, Modifier.align(Alignment.TopEnd)) { Icon(Icons.Default.Cancel, "Remove photo", tint = MaterialTheme.colorScheme.error) }
                } }
            }
            if (images.size < 5) OutlinedButton({ picker.launch(arrayOf("image/*")) }, Modifier.fillMaxWidth()) { Icon(Icons.Default.AddAPhoto, null); Spacer(Modifier.width(8.dp)); Text(if (images.isEmpty()) "Add up to 5 photos" else "Add more photos") }
        }
        item { Field(name, { name = it }, "Strain name *") }
        item {
            val exactMatch = StrainReferences.exact(name)
            val suggestions = if (exactMatch == null) StrainReferences.search(name) else emptyList()
            if (suggestions.isNotEmpty()) Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Known strains", fontWeight = FontWeight.SemiBold)
                suggestions.forEach { reference ->
                    ElevatedCard(onClick = { useReference(reference) }, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) { Text(reference.name, fontWeight = FontWeight.Bold); Text(reference.genetics, style = MaterialTheme.typography.bodySmall) }
                            Text("Use", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                Text("Tap a result to add reference terpenes and flavour. Your own effects, strength and batch stay personal.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else if (exactMatch != null) {
                Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("STRAIN REFERENCE", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Text("Parents: ${exactMatch.genetics}", style = MaterialTheme.typography.titleMedium)
                        if (exactMatch.reportedEffects.isNotEmpty()) Text("User-reported effects: ${exactMatch.reportedEffects.joinToString(" · ")}", style = MaterialTheme.typography.bodyMedium)
                        Text("Reference reports are not your experience. THC/CBD, cultivar and batch can differ even for the same strain.", style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = { useReference(exactMatch) }) { Text("Fill available reference details") }
                    }
                }
            }
        }
        item { Field(brand, { brand = it }, "Cultivator / producer", "e.g. Papers or Green Karat") }
        item {
            if (brand.length < 2 || Cultivators.search(brand).none { it.equals(brand, true) }) {
                val growers = Cultivators.search(brand)
                if (growers.isNotEmpty()) { Text("Select cultivator", fontWeight = FontWeight.SemiBold); LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) { items(growers) { grower -> SuggestionChip(onClick = { brand = grower }, label = { Text(grower) }) } } }
            } else AssistChip({}, { Text("Cultivator: $brand") }, leadingIcon = { Icon(Icons.Default.CheckCircle, null) })
        }
        item { Text("Cultivar type", fontWeight = FontWeight.SemiBold); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Indica", "Hybrid", "Sativa").forEach { FilterChip(type == it, { type = it }, { Text(it) }) } } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Box(Modifier.weight(1f)) { Field(thc, { thc = it.filter { c -> c.isDigit() || c == '.' } }, "THC %") }; Box(Modifier.weight(1f)) { Field(cbd, { cbd = it.filter { c -> c.isDigit() || c == '.' } }, "CBD %") } } }
        item {
            val calendar = Calendar.getInstance().apply { timeInMillis = reviewDate }
            OutlinedButton(onClick = {
                android.app.DatePickerDialog(context, { _, year, month, day ->
                    reviewDate = Calendar.getInstance().apply { set(year, month, day, 12, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
            }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.CalendarMonth, null); Spacer(Modifier.width(8.dp)); Text("Date: ${DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(reviewDate))}") }
        }
        item { Field(batchNumber, { batchNumber = it }, "Batch number (optional)", "e.g. BN240715") }
        item { Field(terpenes, { terpenes = it }, "Terpenes", "e.g. limonene, myrcene") }
        item { Field(aroma, { aroma = it }, "Aroma") }; item { Field(flavour, { flavour = it }, "Flavour") }
        item { Text("YOUR EXPERIENCE", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary); Text("Only record effects you actually noticed.", style = MaterialTheme.typography.bodySmall) }
        item { Field(symptoms, { symptoms = it }, "Symptoms helped", "e.g. pain, anxiety, sleep") }; item { Field(effects, { effects = it }, "Effects you felt", "e.g. calm, focused, sleepy") }; item { Field(sideEffects, { sideEffects = it }, "Unwanted effects") }
        item { RatingSlider("Overall", overall) { overall = it } }; item { RatingSlider("Effectiveness", effectiveness) { effectiveness = it } }; item { RatingSlider("Flavour", flavourRating) { flavourRating = it } }; item { RatingSlider("Appearance", appearance) { appearance = it } }; item { RatingSlider("Value", value) { value = it } }
        item { Field(thoughts, { thoughts = it }, "Your thoughts", "What stood out? Would you get it again?", 5) }
        item { Text("Who can see this?", fontWeight = FontWeight.SemiBold); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("PRIVATE" to "Only me", "PUBLIC" to "Public").forEach { (key, label) -> FilterChip(visibility == key, { visibility = key }, { Text(label) }, leadingIcon = { Icon(if (key == "PRIVATE") Icons.Default.Lock else Icons.Default.Public, null) }) } }; if (visibility == "PUBLIC") Text("Diary sessions are never included.", style = MaterialTheme.typography.bodySmall) }
        item { Button(onClick = { onSave(Review(id=initial?.id ?: 0, strainName=name.trim(), brand=brand.trim(), cultivarType=type, thcPercent=thc.toDoubleOrNull(), cbdPercent=cbd.toDoubleOrNull(), terpenes=terpenes, aroma=aroma, flavour=flavour, thoughts=thoughts, effectiveness=effectiveness, flavourRating=flavourRating, appearanceRating=appearance, valueRating=value, overallRating=overall, helpedSymptoms=symptoms, effects=effects, sideEffects=sideEffects, imageUri=images.firstOrNull()?.toString(), imageUris=images.joinToString("\n"), reviewDate=reviewDate, batchNumber=batchNumber.trim(), isFavourite=initial?.isFavourite ?: false, visibility=visibility, createdAt=initial?.createdAt ?: System.currentTimeMillis())) }, enabled = name.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text(if (initial == null) "Save review" else "Save changes") } }
    }
}

@Composable private fun SessionEditor(vm: JournalViewModel, onSave: (MedicationSession) -> Unit, onCancel: () -> Unit) {
    val reviews by vm.reviews.collectAsStateWithLifecycle(); var strain by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }; var method by remember { mutableStateOf("Dry herb vaporiser") }; var temp by remember { mutableStateOf("") }; var before by remember { mutableIntStateOf(5) }; var relief by remember { mutableIntStateOf(5) }; var notes by remember { mutableStateOf("") }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onCancel) { Icon(Icons.Default.ArrowBack, "Back") }; Text("Record medication", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) } }
        if (reviews.isNotEmpty()) item { Text("Choose a reviewed strain"); Column { reviews.take(8).forEach { r -> AssistChip({ strain = r.strainName }, { Text(r.strainName) }, leadingIcon = if (strain == r.strainName) { { Icon(Icons.Default.Check, null) } } else null) } } }
        item { Field(strain, { strain = it }, "Strain name *") }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Box(Modifier.weight(1f)) { Field(amount, { amount = it.filter { c -> c.isDigit() || c == '.' } }, "Amount (g)") }; Box(Modifier.weight(1f)) { Field(temp, { temp = it.filter(Char::isDigit) }, "Temperature °C") } } }
        item { Field(method, { method = it }, "Method") }; item { RatingSlider("Symptoms before", before) { before = it } }; item { RatingSlider("Relief after", relief) { relief = it } }; item { Field(notes, { notes = it }, "Private notes", minLines = 4) }
        item { Button({ onSave(MedicationSession(strainName=strain.trim(), amountGrams=amount.toDoubleOrNull(), method=method, temperatureC=temp.toIntOrNull(), symptomsBefore=before, reliefAfter=relief, notes=notes)) }, enabled=strain.isNotBlank(), modifier=Modifier.fillMaxWidth()) { Text("Save private session") } }
    }
}

@Composable private fun ReviewDetail(vm: JournalViewModel, id: Long, onBack: () -> Unit, onEdit: () -> Unit) {
    val review by vm.review(id).collectAsStateWithLifecycle(initialValue = null); val r = review ?: return EmptyState("Review not found", "It may have been removed.")
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 32.dp)) {
        item { Box { if (r.photos().isNotEmpty()) LazyRow(Modifier.fillMaxWidth().height(260.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) { items(r.photos()) { photo -> Image(rememberAsyncImagePainter(photo), null, Modifier.fillParentMaxWidth().height(260.dp), contentScale=ContentScale.Crop) } } else Surface(Modifier.fillMaxWidth().height(160.dp), color=MaterialTheme.colorScheme.primaryContainer) {}; Surface(Modifier.align(Alignment.TopStart).padding(10.dp), shape=RoundedCornerShape(50), color=Color.Black.copy(alpha=.72f)) { IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back", tint=Color.White) } } } }
        item { Column(Modifier.padding(20.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) { Column { Text(r.strainName, style=MaterialTheme.typography.headlineMedium, fontWeight=FontWeight.Bold); Text(listOf(r.brand, r.cultivarType).filter(String::isNotBlank).joinToString(" • ")) }; Text("★ ${r.overallRating}/10", style=MaterialTheme.typography.titleLarge, color=MaterialTheme.colorScheme.secondary) }
            Button(onClick=onEdit, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Edit, null); Spacer(Modifier.width(8.dp)); Text("Edit this review") }
            Text(listOfNotNull(r.thcPercent?.let { "$it% THC" }, r.cbdPercent?.let { "$it% CBD" }).joinToString("  •  "))
            Text("Reviewed ${DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(r.reviewDate))}", color=MaterialTheme.colorScheme.onSurfaceVariant)
            StrainReferences.exact(r.strainName)?.let { reference ->
                Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.primaryContainer) { Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("LINEAGE", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text(reference.genetics, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text("Common terpenes: ${reference.commonTerpenes.joinToString(", ")}", style = MaterialTheme.typography.bodySmall)
                } }
            }
            Detail("Batch number", r.batchNumber)
            if (listOf(r.aroma, r.flavour, r.effects, r.helpedSymptoms, r.sideEffects, r.thoughts).any(String::isNotBlank)) {
                Text("Your review", style=MaterialTheme.typography.titleMedium, fontWeight=FontWeight.Bold)
            }
            Detail("Terpenes", r.terpenes); Detail("Aroma", r.aroma); Detail("Flavour", r.flavour); Detail("Effects", r.effects); Detail("Helped", r.helpedSymptoms); Detail("Unwanted effects", r.sideEffects); Detail("Thoughts", r.thoughts)
            HorizontalDivider(); Text("Effectiveness ${r.effectiveness}/10  •  Flavour ${r.flavourRating}/10\nAppearance ${r.appearanceRating}/10  •  Value ${r.valueRating}/10")
            AssistChip({}, { Text(if (r.visibility == "PUBLIC") "Public review" else "Private review") }, leadingIcon={ Icon(if(r.visibility=="PUBLIC") Icons.Default.Public else Icons.Default.Lock, null) })
            OutlinedButton(onClick=onEdit, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Edit, null); Spacer(Modifier.width(8.dp)); Text("Edit review details") }
        } }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable private fun GeneticsScreen(vm: JournalViewModel, onOpenReview: (Long) -> Unit) {
    val reviews by vm.reviews.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<StrainReference?>(null) }
    val matches = StrainReferences.search(query)
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { Text("Strain genetics", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("Explore parent strains and family connections", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { OutlinedTextField(query, { query = it; selected = StrainReferences.exact(it) }, Modifier.fillMaxWidth(), placeholder = { Text("Search a strain") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true) }
        if (selected == null) {
            if (query.isBlank()) item { EmptyState("Explore the family tree", "Search for a strain such as Wedding Pie, GMO or Gelato 41.") }
            else if (matches.isEmpty()) item { EmptyState("Strain not in the catalogue yet", "The online catalogue connection is being prepared. You will still be able to add unknown names to your journal.") }
            else items(matches) { reference -> ElevatedCard(onClick = { selected = reference; query = reference.name }, modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text(reference.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Text(reference.genetics); Text(reference.commonTerpenes.joinToString(" • "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
        } else {
            val reference = selected!!
            item { ElevatedCard(Modifier.fillMaxWidth(), colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Column { Text(reference.name, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text("Parent lineage", color = MaterialTheme.colorScheme.onPrimaryContainer) }; Icon(Icons.Default.AccountTree, null, Modifier.size(34.dp)) }
                Text(reference.genetics, style = MaterialTheme.typography.titleLarge)
                val parents = reference.parents
                if (parents.isNotEmpty()) { Text("Tap a parent to keep exploring", style = MaterialTheme.typography.labelLarge); LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(parents) { parent -> AssistChip(onClick = { query = parent; selected = StrainReferences.exact(parent) }, label = { Text(parent) }, leadingIcon = { Icon(Icons.Default.CallSplit, null) }) } } }
                HorizontalDivider()
                Text("Commonly reported terpenes", fontWeight = FontWeight.Bold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) { reference.commonTerpenes.forEach { terpene -> SuggestionChip({}, { Text(terpene) }) } }
                if (reference.reportedEffects.isNotEmpty()) { Text("User-reported effects", fontWeight = FontWeight.Bold); Text(reference.reportedEffects.joinToString(" • ")); Text("Other people's reports, not a prediction of your experience.", style = MaterialTheme.typography.bodySmall) }
                if (reference.flavours.isNotEmpty()) { Text("Flavour profile", fontWeight = FontWeight.Bold); Text(reference.flavours.joinToString(" • ")) }
                Text(reference.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
            } } }
            val journalMatches = reviews.filter { it.strainName.equals(reference.name, true) }
            if (journalMatches.isNotEmpty()) item { Text("Your ${reference.name} reviews", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            items(journalMatches, key = { it.id }) { review -> ReviewCard(review, onOpenReview, { vm.toggleFavourite(review) }) }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable private fun DiscoverScreen(vm: JournalViewModel, onBack: () -> Unit) {
    val reviews by vm.reviews.collectAsStateWithLifecycle()
    var flavours by remember { mutableStateOf(setOf<String>()) }
    var terpenes by remember { mutableStateOf(setOf<String>()) }
    var learnFromReviews by remember { mutableStateOf(true) }
    val favourites = reviews.filter { it.isFavourite || it.overallRating >= 8 }
    val likedReferences = if (learnFromReviews) favourites.mapNotNull { StrainReferences.exact(it.strainName) } else emptyList()
    val likedTerpenes = likedReferences.flatMap { it.commonTerpenes }.toSet()
    val likedFlavours = likedReferences.flatMap { it.flavours }.toSet()
    val wantedTerpenes = terpenes + likedTerpenes
    val wantedFlavours = flavours + likedFlavours
    val reviewedNames = reviews.map { it.strainName.lowercase() }.toSet()
    val suggestions = if (wantedTerpenes.isEmpty() && wantedFlavours.isEmpty()) emptyList() else
        StrainReferences.all().filterNot { it.name.lowercase() in reviewedNames }
            .map { reference ->
                val matchedTerpenes = reference.commonTerpenes.filter { it in wantedTerpenes }
                val matchedFlavours = reference.flavours.filter { it in wantedFlavours }
                reference to (matchedTerpenes + matchedFlavours)
            }.filter { it.second.isNotEmpty() }.sortedWith(compareByDescending<Pair<StrainReference, List<String>>> { it.second.size }.thenBy { it.first.name }).take(12)
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(bottom = 32.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back") }; Text("Find your next strain", style = MaterialTheme.typography.headlineSmall) } }
        item { Text("Choose what you tend to enjoy. Matches use the app’s small reference catalogue, not your private diary or other people's medical results.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { Text("Flavours you like", style = MaterialTheme.typography.titleLarge); FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Gas", "Diesel", "Citrus", "Grape", "Berry", "Mint", "Earthy", "Sweet", "Cream", "Pine").forEach { choice -> FilterChip(choice in flavours, { flavours = if (choice in flavours) flavours - choice else flavours + choice }, { Text(choice) }) } } }
        item { Text("Terpenes you want to explore", style = MaterialTheme.typography.titleLarge); FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Limonene", "Caryophyllene", "Myrcene", "Linalool", "Pinene", "Humulene").forEach { choice -> FilterChip(choice in terpenes, { terpenes = if (choice in terpenes) terpenes - choice else terpenes + choice }, { Text(choice) }) } } }
        item { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(learnFromReviews, { learnFromReviews = it }); Column { Text("Use strains I rated 8+ or favourited"); Text("Only their reference flavours and terpenes; not a medical prediction", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
        item { HorizontalDivider(); Text("Potential matches", style = MaterialTheme.typography.headlineSmall) }
        if (suggestions.isEmpty()) item { Text("Choose a flavour or terpene to see matches. You can also rate or favourite a known strain first.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(suggestions, key = { it.first.name }) { (reference, matches) ->
            ElevatedCard(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(reference.name, style = MaterialTheme.typography.titleLarge)
                Text(reference.genetics, style = MaterialTheme.typography.bodyMedium)
                Text("Why it matches: ${matches.joinToString(" · ")}", color = MaterialTheme.colorScheme.secondary)
            } }
        }
        item { Text("These are similarities, not a guarantee of effects, quality or suitability. Check the actual cultivar and batch details before ordering.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable private fun AppearanceScreen(current: AppTheme, onThemeChange: (AppTheme) -> Unit, onBack: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back") }; Column { Text("Choose your look", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("You can change this whenever you like", color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
        items(AppTheme.entries) { option -> ElevatedCard(onClick = { onThemeChange(option) }, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.elevatedCardColors(containerColor = if (current == option) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface)) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(if (current == option) Icons.Default.CheckCircle else Icons.Default.Palette, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(14.dp)); Column { Text(option.title, fontWeight = FontWeight.Bold); Text(option.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant) } } } }
        item { Text("Custom backgrounds and artwork are planned next. Background images will include a strength control so text stays readable.", style = MaterialTheme.typography.bodyMedium) }
    }
}

@Composable private fun Field(value:String, change:(String)->Unit, label:String, hint:String="", minLines:Int=1) = OutlinedTextField(value, change, Modifier.fillMaxWidth(), label={Text(label)}, placeholder={if(hint.isNotBlank()) Text(hint)}, minLines=minLines)
@Composable private fun RatingSlider(label:String, value:Int, change:(Int)->Unit) { Column { Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) { Text(label, fontWeight=FontWeight.SemiBold); Text("$value/10") }; Slider(value.toFloat(), { change(it.toInt()) }, valueRange=0f..10f, steps=9) } }
@Composable private fun Detail(label:String, value:String) { if(value.isNotBlank()) Column { Text(label, style=MaterialTheme.typography.labelLarge, color=MaterialTheme.colorScheme.primary); Text(value) } }
private fun reviewsCsv(reviews: List<Review>): String {
    fun cell(value: Any?): String {
        val raw = value?.toString().orEmpty()
        // Spreadsheet applications may execute cells beginning with a formula prefix.
        val first = raw.trimStart().firstOrNull()
        val safe = if (first == '=' || first == '+' || first == '-' || first == '@') "'$raw" else raw
        return "\"${safe.replace("\"", "\"\"")}\""
    }
    val header = listOf("Strain", "Cultivator", "Type", "THC %", "CBD %", "Terpenes", "Aroma", "Flavour", "Thoughts", "Effectiveness /10", "Flavour rating /10", "Appearance /10", "Value /10", "Overall /10", "Symptoms helped", "Effects felt", "Unwanted effects", "Review date (Unix ms)", "Batch number", "Favourite", "Visibility", "Created (Unix ms)")
    val lines = reviews.map { r -> listOf(r.strainName, r.brand, r.cultivarType, r.thcPercent, r.cbdPercent, r.terpenes, r.aroma, r.flavour, r.thoughts, r.effectiveness, r.flavourRating, r.appearanceRating, r.valueRating, r.overallRating, r.helpedSymptoms, r.effects, r.sideEffects, r.reviewDate, r.batchNumber, r.isFavourite, r.visibility, r.createdAt).joinToString(",") { cell(it) } }
    return "\uFEFF" + (listOf(header.joinToString(",") { cell(it) }) + lines).joinToString("\r\n", postfix = "\r\n")
}
@Composable private fun StrainNameBackdrop() {
    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.strain_wall_mylar_v2),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(
                        Color.Black.copy(alpha = .10f),
                        Color.Black.copy(alpha = .42f),
                        Color.Black.copy(alpha = .50f)
                    )
                )
            )
        )
    }
}
@Composable private fun EmptyState(title:String, body:String) { Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment=Alignment.Center) { Column(horizontalAlignment=Alignment.CenterHorizontally) { Icon(Icons.Default.Spa, null, Modifier.size(54.dp), tint=MaterialTheme.colorScheme.primary); Spacer(Modifier.height(12.dp)); Text(title, style=MaterialTheme.typography.titleMedium, fontWeight=FontWeight.Bold); Text(body, color=MaterialTheme.colorScheme.onSurfaceVariant) } } }
