-- Run in a new Supabase project's SQL editor.
create extension if not exists pgcrypto;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 2 and 40),
  created_at timestamptz not null default now()
);

create table public.public_reviews (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  local_review_id bigint,
  strain_name text not null check (char_length(strain_name) between 1 and 100),
  brand text not null default '',
  cultivar_type text not null default 'Hybrid',
  thc_percent numeric check (thc_percent between 0 and 100),
  cbd_percent numeric check (cbd_percent between 0 and 100),
  terpenes text not null default '',
  aroma text not null default '',
  flavour text not null default '',
  thoughts text not null default '',
  effectiveness smallint not null check (effectiveness between 0 and 10),
  flavour_rating smallint not null check (flavour_rating between 0 and 10),
  appearance_rating smallint not null check (appearance_rating between 0 and 10),
  value_rating smallint not null check (value_rating between 0 and 10),
  overall_rating smallint not null check (overall_rating between 0 and 10),
  helped_symptoms text not null default '',
  effects text not null default '',
  side_effects text not null default '',
  image_paths text[] not null default '{}',
  review_date date not null default current_date,
  batch_number text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(owner_id, local_review_id)
);

alter table public.profiles enable row level security;
alter table public.public_reviews enable row level security;

create policy "Profiles are readable" on public.profiles for select using (true);
create policy "Users create their profile" on public.profiles for insert with check (auth.uid() = id);
create policy "Users update their profile" on public.profiles for update using (auth.uid() = id);
create policy "Reviews are readable" on public.public_reviews for select using (true);
create policy "Users publish reviews" on public.public_reviews for insert with check (auth.uid() = owner_id);
create policy "Users update own reviews" on public.public_reviews for update using (auth.uid() = owner_id);
create policy "Users delete own reviews" on public.public_reviews for delete using (auth.uid() = owner_id);

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('review-images', 'review-images', true, 10485760, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

create policy "Anyone reads review images" on storage.objects for select using (bucket_id = 'review-images');
create policy "Users upload into own folder" on storage.objects for insert to authenticated
with check (bucket_id = 'review-images' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "Users update own images" on storage.objects for update to authenticated
using (bucket_id = 'review-images' and owner_id = auth.uid()::text);
create policy "Users delete own images" on storage.objects for delete to authenticated
using (bucket_id = 'review-images' and owner_id = auth.uid()::text);

-- There is deliberately no medication_sessions table: diary data never leaves the device.
