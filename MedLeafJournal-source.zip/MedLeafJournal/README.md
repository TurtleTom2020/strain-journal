# MedLeaf Journal

Native Android medical-cannabis review and medication journal, built with Kotlin, Jetpack Compose, Room and Material 3.

## What works in this first version

- Create strain reviews with a gallery photo, brand, cultivar type, THC/CBD and terpenes.
- Record aroma, flavour, thoughts, effects, symptoms helped and unwanted effects.
- Rate overall experience, effectiveness, flavour, appearance and value from 0–10.
- Search across names, brands, terpenes, effects and symptoms; filter favourites.
- Mark reviews private or public.
- Maintain a separate device-only medication diary with amount, method, vaporiser temperature, symptoms and relief.
- View public-marked reviews in the Community tab without exposing diary entries.

All records currently work offline. The included `backend/supabase_schema.sql` creates the guarded public-review backend. Cloud publishing and accounts need a Supabase project URL and anonymous key before they can be activated in the Android client.

## Open and run

1. Install current Android Studio and open the `MedLeafJournal` folder.
2. Allow Android Studio to download/sync the Gradle dependencies.
3. Select an Android 8.0+ emulator or connected phone and press **Run**.

The app targets Android 15 and supports Android 8.0 (API 26) onward.

## Build entirely from a phone

Push this folder to a GitHub repository. The included `Build Android APK` workflow installs the correct Java and Gradle versions, compiles the app and stores `MedLeaf-Journal-debug` as a downloadable workflow artifact. No local Android SDK is needed for this route.

## Public launch setup

1. Create a Supabase project and run `backend/supabase_schema.sql` in its SQL editor.
2. Add email or Google sign-in in Supabase Auth.
3. Add the project URL and publishable/anonymous key through an untracked `local.properties` entry.
4. Connect the `JournalRepository` public-review methods to Supabase and add a background sync worker.
5. Add reporting/blocking, moderation, terms, privacy policy and an age/medical-use acknowledgement before opening community posting broadly.

Never place a Supabase service-role key in the Android app. The public anonymous key is safe only when row-level-security policies remain enabled.

## Product safety decisions

- Publishing is opt-in per review.
- Medication diary entries are structurally local-only.
- Public reviews contain no dose/session history.
- The app must not facilitate buying, selling or sourcing controlled drugs.
- Reviews are personal experiences, not clinical advice.
