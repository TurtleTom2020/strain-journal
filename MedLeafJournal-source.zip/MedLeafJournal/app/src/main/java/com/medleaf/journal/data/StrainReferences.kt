package com.medleaf.journal.data

import java.text.Normalizer

data class StrainReference(
    val name: String,
    val genetics: String,
    val commonTerpenes: List<String>,
    val flavours: List<String> = emptyList(),
    val note: String = "Reference information can vary by breeder and phenotype."
) {
    val parents: List<String> get() = genetics.split("×").map(String::trim).filter { it.isNotBlank() && !it.contains("unknown", true) && !it.contains("undisclosed", true) }
}

object StrainReferences {
    private val records = listOf(
        StrainReference("Wedding Pie", "Wedding Cake × Grape Pie", listOf("Limonene", "Caryophyllene", "Myrcene"), listOf("Grape", "Vanilla", "Pepper")),
        StrainReference("Pavé S1", "Paris OG × The Menthol", listOf("Limonene", "Caryophyllene", "Linalool", "Pinene", "Farnesene"), listOf("Menthol", "Gas", "Earthy")),
        StrainReference("Wedding Cake", "Triangle Kush × Animal Mints", listOf("Limonene", "Caryophyllene", "Myrcene"), listOf("Vanilla", "Pepper", "Sweet")),
        StrainReference("Grape Pie", "Grape Stomper × Cherry Pie", listOf("Caryophyllene", "Limonene", "Myrcene"), listOf("Grape", "Berry", "Sweet")),
        StrainReference("Blue Dream", "Blueberry × Haze", listOf("Myrcene", "Pinene", "Caryophyllene"), listOf("Blueberry", "Berry", "Herbal")),
        StrainReference("Northern Lights", "Afghani × Thai", listOf("Myrcene", "Caryophyllene", "Limonene"), listOf("Earthy", "Pine", "Spice")),
        StrainReference("Gelato 41", "Sunset Sherbet × Thin Mint GSC", listOf("Caryophyllene", "Limonene", "Myrcene"), listOf("Sweet", "Cream", "Citrus")),
        StrainReference("Gelato", "Sunset Sherbet × Thin Mint GSC", listOf("Caryophyllene", "Limonene", "Myrcene"), listOf("Sweet", "Cream", "Citrus")),
        StrainReference("White Runtz", "Gelato × Zkittlez", listOf("Caryophyllene", "Limonene", "Linalool"), listOf("Sweet", "Fruit", "Vanilla")),
        StrainReference("Georgia Pie", "Gellati × Kush Mints", listOf("Caryophyllene", "Limonene", "Myrcene"), listOf("Peach", "Cream", "Nutty")),
        StrainReference("GMO", "Chemdawg × Girl Scout Cookies", listOf("Caryophyllene", "Myrcene", "Limonene"), listOf("Diesel", "Garlic", "Earthy")),
        StrainReference("Alien Mints", "Alien Kush × Animal Mints", listOf("Caryophyllene", "Limonene", "Myrcene"), listOf("Mint", "Diesel", "Earthy")),
        StrainReference("Lemon Cherry Gelato", "Sunset Sherbet × Girl Scout Cookies", listOf("Caryophyllene", "Limonene", "Linalool"), listOf("Cherry", "Lemon", "Sweet")),
        StrainReference("Gastro Pop", "Apples & Bananas × Grape Gas", listOf("Caryophyllene", "Limonene", "Myrcene"), listOf("Grape", "Apple", "Diesel")),
        StrainReference("Cap Junky", "Alien Cookies × Kush Mints #11", listOf("Caryophyllene", "Limonene", "Myrcene"), listOf("Diesel", "Pepper", "Fruit")),
        StrainReference("Zkittlez", "Grape Ape × Grapefruit", listOf("Caryophyllene", "Limonene", "Humulene"), listOf("Tropical", "Grape", "Citrus")),
        StrainReference("Slurricane", "Do-Si-Dos × Purple Punch", listOf("Caryophyllene", "Limonene", "Myrcene"), listOf("Berry", "Spice", "Sweet")),
        StrainReference("Girl Scout Cookies", "OG Kush × F1 Durban", listOf("Caryophyllene", "Limonene", "Humulene"), listOf("Sweet", "Earthy", "Mint")),
        StrainReference("Sunset Sherbet", "Girl Scout Cookies × Pink Panties", listOf("Caryophyllene", "Limonene", "Myrcene"), listOf("Berry", "Citrus", "Sweet")),
        StrainReference("Purple Punch", "Larry OG × Granddaddy Purple", listOf("Caryophyllene", "Limonene", "Pinene"), listOf("Grape", "Berry", "Vanilla")),
        StrainReference("Do-Si-Dos", "Girl Scout Cookies × Face Off OG", listOf("Limonene", "Caryophyllene", "Linalool"), listOf("Earthy", "Lime", "Floral")),
        StrainReference("Kush Mints", "Bubba Kush × Animal Mints", listOf("Limonene", "Caryophyllene", "Myrcene"), listOf("Mint", "Earthy", "Coffee")),
        StrainReference("Animal Mints", "Animal Cookies × SinMint Cookies", listOf("Caryophyllene", "Limonene", "Myrcene"), listOf("Mint", "Sweet", "Diesel")),
        StrainReference("Cherry Pie", "Granddaddy Purple × Durban Poison", listOf("Myrcene", "Caryophyllene", "Pinene"), listOf("Cherry", "Berry", "Earthy")),
        StrainReference("Bananaconda", "Snake Cake × Dual OG #4", listOf("Limonene", "Caryophyllene", "Myrcene"), listOf("Banana", "Cream", "Gas")),
        StrainReference("Master Kush", "Hindu Kush × Skunk #1", listOf("Caryophyllene", "Limonene", "Myrcene"), listOf("Earthy", "Citrus", "Incense")),
        StrainReference("OG Kush", "Chemdawg × Lemon Thai × Hindu Kush", listOf("Myrcene", "Limonene", "Caryophyllene"), listOf("Earthy", "Pine", "Diesel"))
    )

    private fun normalise(value: String) = Normalizer.normalize(value.trim(), Normalizer.Form.NFD).replace("\\p{M}+".toRegex(), "").lowercase()
    fun exact(name: String): StrainReference? = records.firstOrNull { normalise(it.name) == normalise(name) }
    fun search(text: String): List<StrainReference> = if (text.length < 2) emptyList() else records.filter { normalise(it.name).contains(normalise(text)) }.take(5)
}
