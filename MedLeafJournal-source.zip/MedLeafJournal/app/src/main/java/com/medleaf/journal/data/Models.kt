package com.medleaf.journal.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reviews")
data class Review(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val strainName: String,
    val brand: String = "",
    val cultivarType: String = "Hybrid",
    val thcPercent: Double? = null,
    val cbdPercent: Double? = null,
    val terpenes: String = "",
    val aroma: String = "",
    val flavour: String = "",
    val thoughts: String = "",
    val effectiveness: Int = 0,
    val flavourRating: Int = 0,
    val appearanceRating: Int = 0,
    val valueRating: Int = 0,
    val overallRating: Int = 0,
    val helpedSymptoms: String = "",
    val effects: String = "",
    val sideEffects: String = "",
    val imageUri: String? = null,
    val imageUris: String = "",
    val reviewDate: Long = System.currentTimeMillis(),
    val batchNumber: String = "",
    val isFavourite: Boolean = false,
    val visibility: String = "PRIVATE",
    val createdAt: Long = System.currentTimeMillis()
)

fun Review.photos(): List<String> = imageUris.split("\n")
    .filter(String::isNotBlank)
    .ifEmpty { listOfNotNull(imageUri) }

@Entity(tableName = "sessions")
data class MedicationSession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reviewId: Long? = null,
    val strainName: String,
    val amountGrams: Double? = null,
    val method: String = "Dry herb vaporiser",
    val temperatureC: Int? = null,
    val symptomsBefore: Int = 0,
    val reliefAfter: Int = 0,
    val notes: String = "",
    val takenAt: Long = System.currentTimeMillis()
)
