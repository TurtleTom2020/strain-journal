package com.medleaf.journal

import android.app.Application
import com.medleaf.journal.data.AppDatabase
import com.medleaf.journal.data.JournalRepository

class MedLeafApplication : Application() {
    val repository by lazy { JournalRepository(AppDatabase.create(this).journalDao()) }
}
