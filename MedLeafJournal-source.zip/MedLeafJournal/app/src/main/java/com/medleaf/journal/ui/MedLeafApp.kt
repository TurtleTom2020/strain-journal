package com.medleaf.journal.ui

import android.net.Uri
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import coil.compose.rememberAsyncImagePainter
import com.medleaf.journal.MedLeafApplication
import com.medleaf.journal.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date
import java.util.Calendar

private enum class Destination(val route: String, val label: String) {
    JOURNAL("journal", "Journal"), GENETICS("genetics", "Genetics"), COMMUNITY("community", "Community"), DIARY("diary", "Diary")
}

class JournalViewModel(private val repository: JournalRepository) : ViewModel() {
    val reviews = repository.reviews.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val sessions = repository.sessions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun review(id: Long) = repository.review(id)
    fun save(review: Review, done: () -> Unit) = viewModelScope.launch { repository.save(review); done() }
    fun save(session: MedicationSession, done: () -> Unit) = viewModelScope.launch { repository.saveSession(session); done() }
    fun toggleFavourite(review: Review) = viewModelScope.launch { repository.update(review.copy(isFavourite = !review.isFavourite)) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedLeafApp() {
    val context = LocalContext.current
    val preferences = remember { context.getSharedPreferences("appearance", android.content.Context.MODE_PRIVATE) }
    var appTheme by remember { mutableStateOf(runCatching { AppTheme.valueOf(preferences.getString("theme", AppTheme.MIDNIGHT.name)!!) }.getOrDefault(AppTheme.MIDNIGHT)) }
    MedLeafTheme(appTheme) {
        MedLeafAppContent(appTheme) {
            appTheme = it
            preferences.edit().putString("theme", it.name).apply()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MedLeafAppContent(appTheme: AppTheme, onThemeChange: (AppTheme) -> Unit) {
    val app = LocalContext.current.applicationContext as MedLeafApplication
    val vm: JournalViewModel = viewModel(factory = object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>) = JournalViewModel(app.repository) as T
    })
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val current = entry?.destination?.route.orEmpty()
    val roots = Destination.entries

    val background = when (appTheme) {
        AppTheme.MIDNIGHT -> Brush.verticalGradient(listOf(Color(0xFF050607), Color(0xFF24282B), Color(0xFF090A0B)))
        AppTheme.FOREST -> Brush.verticalGradient(listOf(Color(0xFF06140E), Color(0xFF123C2A), Color(0xFF07140F)))
        AppTheme.REGGAE -> Brush.linearGradient(listOf(Color(0xFF15120E), Color(0xFF322A14), Color(0xFF102B18)))
        AppTheme.CLINICAL -> Brush.verticalGradient(listOf(Color(0xFFF7FAF6), Color(0xFFE8F2EC)))
    }
    Box(Modifier.fillMaxSize().background(background)) {
    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent), title = {
                Column { Text("MedLeaf Journal", fontWeight = FontWeight.Bold); Text("Know what works for you", style = MaterialTheme.typography.labelSmall) }
            }, actions = { IconButton({ nav.navigate("appearance") }) { Icon(Icons.Default.Palette, "Appearance") } })
        },
        bottomBar = {
            if (roots.any { current == it.route }) NavigationBar {
                roots.forEach { item ->
                    NavigationBarItem(
                        selected = current == item.route,
                        onClick = { nav.navigate(item.route) { popUpTo(Destination.JOURNAL.route); launchSingleTop = true } },
                        icon = { Icon(when(item) { Destination.JOURNAL -> Icons.Default.LocalFlorist; Destination.GENETICS -> Icons.Default.AccountTree; Destination.COMMUNITY -> Icons.Default.Public; Destination.DIARY -> Icons.Default.Medication }, null) },
                        label = { Text(item.label) }
                    )
                }
            }
        },
        floatingActionButton = {
            if (current == Destination.JOURNAL.route) FloatingActionButton(onClick = { nav.navigate("add-review") }) { Icon(Icons.Default.Add, "Add review") }
            if (current == Destination.DIARY.route) FloatingActionButton(onClick = { nav.navigate("add-session") }) { Icon(Icons.Default.Add, "Add session") }
        }
    ) { padding ->
        NavHost(nav, startDestination = Destination.JOURNAL.route, Modifier.padding(padding)) {
            composable(Destination.JOURNAL.route) { JournalScreen(vm, onOpen = { nav.navigate("review/$it") }) }
            composable(Destination.GENETICS.route) { GeneticsScreen(vm, onOpenReview = { nav.navigate("review/$it") }) }
            composable(Destination.COMMUNITY.route) { CommunityScreen(vm, onOpen = { nav.navigate("review/$it") }) }
            composable(Destination.DIARY.route) { DiaryScreen(vm) }
            composable("add-review") { ReviewEditor(onSave = { vm.save(it) { nav.popBackStack() } }, onCancel = { nav.popBackStack() }) }
            composable("add-session") { SessionEditor(vm, onSave = { vm.save(it) { nav.popBackStack() } }, onCancel = { nav.popBackStack() }) }
            composable("review/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) {
                ReviewDetail(vm, it.arguments?.getLong("id") ?: 0, onBack = { nav.popBackStack() })
            }
            composable("appearance") { AppearanceScreen(appTheme, onThemeChange, onBack = { nav.popBackStack() }) }
        }
    }
    }
}

@Composable private fun JournalScreen(vm: JournalViewModel, onOpen: (Long) -> Unit) {
    val reviews by vm.reviews.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }
    var favouritesOnly by remember { mutableStateOf(false) }
    var sort by remember { mutableStateOf("Newest") }
    var sortOpen by remember { mutableStateOf(false) }
    val filtered = reviews.filter { (!favouritesOnly || it.isFavourite) && (query.isBlank() || listOf(it.strainName, it.brand, it.terpenes, it.effects, it.helpedSymptoms).any { text -> text.contains(query, true) }) }
    val shown = when (sort) {
        "Highest rating" -> filtered.sortedByDescending { it.overallRating }
        "Lowest rating" -> filtered.sortedBy { it.overallRating }
        "Oldest" -> filtered.sortedBy { it.reviewDate }
        "Name A–Z" -> filtered.sortedBy { it.strainName.lowercase() }
        "Highest THC" -> filtered.sortedByDescending { it.thcPercent ?: -1.0 }
        "Highest CBD" -> filtered.sortedByDescending { it.cbdPercent ?: -1.0 }
        "Dominant terpene" -> filtered.sortedBy { (it.terpenes.split(",").firstOrNull() ?: StrainReferences.exact(it.strainName)?.commonTerpenes?.firstOrNull()).orEmpty() }
        else -> filtered.sortedByDescending { it.reviewDate }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = { Text("Search strains, effects or terpenes") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(favouritesOnly, { favouritesOnly = !favouritesOnly }, label = { Text("Favourites") }, leadingIcon = { Icon(Icons.Default.Favorite, null) })
            Box { FilterChip(true, { sortOpen = true }, label = { Text(sort) }, leadingIcon = { Icon(Icons.Default.Sort, null) }); DropdownMenu(sortOpen, { sortOpen = false }) { listOf("Newest", "Oldest", "Highest rating", "Lowest rating", "Name A–Z", "Highest THC", "Highest CBD", "Dominant terpene").forEach { option -> DropdownMenuItem({ Text(option) }, { sort = option; sortOpen = false }) } } }
        }
        if (shown.isEmpty()) EmptyState(if (reviews.isEmpty()) "Your strain journal is empty" else "No reviews match that search", "Tap + to record what you tried and how well it worked.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 96.dp)) {
            items(shown, key = { it.id }) { ReviewCard(it, onOpen, { vm.toggleFavourite(it) }) }
        }
    }
}

@Composable private fun CommunityScreen(vm: JournalViewModel, onOpen: (Long) -> Unit) {
    val reviews by vm.reviews.collectAsStateWithLifecycle()
    val public = reviews.filter { it.visibility == "PUBLIC" }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Community reviews", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Public reviews are shown without medication-diary entries.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        if (public.isEmpty()) EmptyState("Nothing public yet", "Choose Public when saving a review. Cloud publishing activates after backend setup.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) { items(public, key = { it.id }) { ReviewCard(it, onOpen, { vm.toggleFavourite(it) }) } }
    }
}

@Composable private fun DiaryScreen(vm: JournalViewModel) {
    val sessions by vm.sessions.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Private medication diary", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Session entries stay on this device.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        if (sessions.isEmpty()) EmptyState("No sessions recorded", "Track dose, device, temperature, symptoms and relief.") else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(sessions, key = { it.id }) { s -> Card { Column(Modifier.padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(s.strainName, fontWeight = FontWeight.Bold); Text(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(s.takenAt)), style = MaterialTheme.typography.labelSmall) }
                Text(listOfNotNull(s.amountGrams?.let { "$it g" }, s.method, s.temperatureC?.let { "$it°C" }).joinToString(" • "))
                if (s.reliefAfter > 0) Text("Relief: ${s.reliefAfter}/10")
                if (s.notes.isNotBlank()) Text(s.notes, maxLines = 3, overflow = TextOverflow.Ellipsis)
            } } }
        }
    }
}

@Composable private fun ReviewCard(review: Review, onOpen: (Long) -> Unit, onFavourite: () -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth().clickable { onOpen(review.id) }) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        if (review.photos().isNotEmpty()) Image(rememberAsyncImagePainter(review.photos().first()), null, Modifier.size(82.dp), contentScale = ContentScale.Crop)
        else Surface(Modifier.size(82.dp), RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primaryContainer) { Icon(Icons.Default.LocalFlorist, null, Modifier.padding(24.dp), tint = MaterialTheme.colorScheme.primary) }
        Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Text(review.strainName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Text("★ ${review.overallRating}/10", color = MaterialTheme.colorScheme.secondary) }
            Text(listOf(review.brand, review.cultivarType, review.thcPercent?.let { "$it% THC" }.orEmpty()).filter { it.isNotBlank() }.joinToString(" • "), style = MaterialTheme.typography.bodySmall)
            Text(DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(review.reviewDate)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (review.helpedSymptoms.isNotBlank()) Text("Helped: ${review.helpedSymptoms}", maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onFavourite) { Icon(if (review.isFavourite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favourite", tint = MaterialTheme.colorScheme.tertiary) }
    } }
}

@Composable private fun ReviewEditor(onSave: (Review) -> Unit, onCancel: () -> Unit) {
    var name by remember { mutableStateOf("") }; var brand by remember { mutableStateOf("") }; var type by remember { mutableStateOf("Hybrid") }
    var thc by remember { mutableStateOf("") }; var cbd by remember { mutableStateOf("") }; var terpenes by remember { mutableStateOf("") }
    var aroma by remember { mutableStateOf("") }; var flavour by remember { mutableStateOf("") }; var thoughts by remember { mutableStateOf("") }
    var symptoms by remember { mutableStateOf("") }; var effects by remember { mutableStateOf("") }; var sideEffects by remember { mutableStateOf("") }
    var overall by remember { mutableIntStateOf(7) }; var effectiveness by remember { mutableIntStateOf(7) }; var flavourRating by remember { mutableIntStateOf(7) }; var appearance by remember { mutableIntStateOf(7) }; var value by remember { mutableIntStateOf(7) }
    var images by remember { mutableStateOf<List<Uri>>(emptyList()) }; var visibility by remember { mutableStateOf("PRIVATE") }
    var reviewDate by remember { mutableLongStateOf(System.currentTimeMillis()) }; var batchNumber by remember { mutableStateOf("") }
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { picked ->
        picked.take(5 - images.size).forEach { uri -> runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
        images = (images + picked).distinct().take(5)
    }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 32.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onCancel) { Icon(Icons.Default.ArrowBack, "Back") }; Text("New strain review", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) } }
        item {
            Text("Photos (${images.size}/5)", fontWeight = FontWeight.SemiBold)
            if (images.isNotEmpty()) LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(images, key = { it.toString() }) { uri -> Box {
                    Image(rememberAsyncImagePainter(uri), null, Modifier.size(145.dp), contentScale = ContentScale.Crop)
                    IconButton({ images = images - uri }, Modifier.align(Alignment.TopEnd)) { Icon(Icons.Default.Cancel, "Remove photo", tint = MaterialTheme.colorScheme.error) }
                } }
            }
            if (images.size < 5) OutlinedButton({ picker.launch(arrayOf("image/*")) }, Modifier.fillMaxWidth()) { Icon(Icons.Default.AddAPhoto, null); Spacer(Modifier.width(8.dp)); Text(if (images.isEmpty()) "Add up to 5 photos" else "Add more photos") }
        }
        item { Field(name, { name = it }, "Strain name *") }; item { Field(brand, { brand = it }, "Brand / producer") }
        item { Text("Cultivar type", fontWeight = FontWeight.SemiBold); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Indica", "Hybrid", "Sativa").forEach { FilterChip(type == it, { type = it }, { Text(it) }) } } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Box(Modifier.weight(1f)) { Field(thc, { thc = it.filter { c -> c.isDigit() || c == '.' } }, "THC %") }; Box(Modifier.weight(1f)) { Field(cbd, { cbd = it.filter { c -> c.isDigit() || c == '.' } }, "CBD %") } } }
        item {
            val calendar = Calendar.getInstance().apply { timeInMillis = reviewDate }
            OutlinedButton(onClick = {
                android.app.DatePickerDialog(context, { _, year, month, day ->
                    reviewDate = Calendar.getInstance().apply { set(year, month, day, 12, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
            }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.CalendarMonth, null); Spacer(Modifier.width(8.dp)); Text("Date: ${DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(reviewDate))}") }
        }
        item { Field(batchNumber, { batchNumber = it }, "Batch number (optional)", "e.g. BN240715") }
        item { Field(terpenes, { terpenes = it }, "Terpenes", "e.g. limonene, myrcene") }
        item { Field(aroma, { aroma = it }, "Aroma") }; item { Field(flavour, { flavour = it }, "Flavour") }
        item { Field(symptoms, { symptoms = it }, "Symptoms helped", "e.g. pain, anxiety, sleep") }; item { Field(effects, { effects = it }, "Effects", "e.g. calm, focused, sleepy") }; item { Field(sideEffects, { sideEffects = it }, "Unwanted effects") }
        item { RatingSlider("Overall", overall) { overall = it } }; item { RatingSlider("Effectiveness", effectiveness) { effectiveness = it } }; item { RatingSlider("Flavour", flavourRating) { flavourRating = it } }; item { RatingSlider("Appearance", appearance) { appearance = it } }; item { RatingSlider("Value", value) { value = it } }
        item { Field(thoughts, { thoughts = it }, "Your thoughts", "What stood out? Would you get it again?", 5) }
        item { Text("Who can see this?", fontWeight = FontWeight.SemiBold); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("PRIVATE" to "Only me", "PUBLIC" to "Public").forEach { (key, label) -> FilterChip(visibility == key, { visibility = key }, { Text(label) }, leadingIcon = { Icon(if (key == "PRIVATE") Icons.Default.Lock else Icons.Default.Public, null) }) } }; if (visibility == "PUBLIC") Text("Diary sessions are never included.", style = MaterialTheme.typography.bodySmall) }
        item { Button(onClick = { onSave(Review(strainName=name.trim(), brand=brand.trim(), cultivarType=type, thcPercent=thc.toDoubleOrNull(), cbdPercent=cbd.toDoubleOrNull(), terpenes=terpenes, aroma=aroma, flavour=flavour, thoughts=thoughts, effectiveness=effectiveness, flavourRating=flavourRating, appearanceRating=appearance, valueRating=value, overallRating=overall, helpedSymptoms=symptoms, effects=effects, sideEffects=sideEffects, imageUri=images.firstOrNull()?.toString(), imageUris=images.joinToString("\n"), reviewDate=reviewDate, batchNumber=batchNumber.trim(), visibility=visibility)) }, enabled = name.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Save review") } }
    }
}

@Composable private fun SessionEditor(vm: JournalViewModel, onSave: (MedicationSession) -> Unit, onCancel: () -> Unit) {
    val reviews by vm.reviews.collectAsStateWithLifecycle(); var strain by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }; var method by remember { mutableStateOf("Dry herb vaporiser") }; var temp by remember { mutableStateOf("") }; var before by remember { mutableIntStateOf(5) }; var relief by remember { mutableIntStateOf(5) }; var notes by remember { mutableStateOf("") }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onCancel) { Icon(Icons.Default.ArrowBack, "Back") }; Text("Record medication", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) } }
        if (reviews.isNotEmpty()) item { Text("Choose a reviewed strain"); Column { reviews.take(8).forEach { r -> AssistChip({ strain = r.strainName }, { Text(r.strainName) }, leadingIcon = if (strain == r.strainName) { { Icon(Icons.Default.Check, null) } } else null) } } }
        item { Field(strain, { strain = it }, "Strain name *") }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Box(Modifier.weight(1f)) { Field(amount, { amount = it.filter { c -> c.isDigit() || c == '.' } }, "Amount (g)") }; Box(Modifier.weight(1f)) { Field(temp, { temp = it.filter(Char::isDigit) }, "Temperature °C") } } }
        item { Field(method, { method = it }, "Method") }; item { RatingSlider("Symptoms before", before) { before = it } }; item { RatingSlider("Relief after", relief) { relief = it } }; item { Field(notes, { notes = it }, "Private notes", minLines = 4) }
        item { Button({ onSave(MedicationSession(strainName=strain.trim(), amountGrams=amount.toDoubleOrNull(), method=method, temperatureC=temp.toIntOrNull(), symptomsBefore=before, reliefAfter=relief, notes=notes)) }, enabled=strain.isNotBlank(), modifier=Modifier.fillMaxWidth()) { Text("Save private session") } }
    }
}

@Composable private fun ReviewDetail(vm: JournalViewModel, id: Long, onBack: () -> Unit) {
    val review by vm.review(id).collectAsStateWithLifecycle(initialValue = null); val r = review ?: return EmptyState("Review not found", "It may have been removed.")
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 32.dp)) {
        item { Box { if (r.photos().isNotEmpty()) LazyRow(Modifier.fillMaxWidth().height(260.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) { items(r.photos()) { photo -> Image(rememberAsyncImagePainter(photo), null, Modifier.fillParentMaxWidth().height(260.dp), contentScale=ContentScale.Crop) } } else Surface(Modifier.fillMaxWidth().height(160.dp), color=MaterialTheme.colorScheme.primaryContainer) {}; IconButton(onBack, Modifier.padding(8.dp)) { Icon(Icons.Default.ArrowBack, "Back") } } }
        item { Column(Modifier.padding(20.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) { Column { Text(r.strainName, style=MaterialTheme.typography.headlineMedium, fontWeight=FontWeight.Bold); Text(listOf(r.brand, r.cultivarType).filter(String::isNotBlank).joinToString(" • ")) }; Text("★ ${r.overallRating}/10", style=MaterialTheme.typography.titleLarge, color=MaterialTheme.colorScheme.secondary) }
            Text(listOfNotNull(r.thcPercent?.let { "$it% THC" }, r.cbdPercent?.let { "$it% CBD" }).joinToString("  •  "))
            Text("Reviewed ${DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(r.reviewDate))}", color=MaterialTheme.colorScheme.onSurfaceVariant)
            Detail("Batch number", r.batchNumber)
            Detail("Terpenes", r.terpenes); Detail("Aroma", r.aroma); Detail("Flavour", r.flavour); Detail("Effects", r.effects); Detail("Helped", r.helpedSymptoms); Detail("Unwanted effects", r.sideEffects); Detail("Thoughts", r.thoughts)
            HorizontalDivider(); Text("Effectiveness ${r.effectiveness}/10  •  Flavour ${r.flavourRating}/10\nAppearance ${r.appearanceRating}/10  •  Value ${r.valueRating}/10")
            AssistChip({}, { Text(if (r.visibility == "PUBLIC") "Public review" else "Private review") }, leadingIcon={ Icon(if(r.visibility=="PUBLIC") Icons.Default.Public else Icons.Default.Lock, null) })
        } }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable private fun GeneticsScreen(vm: JournalViewModel, onOpenReview: (Long) -> Unit) {
    val reviews by vm.reviews.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<StrainReference?>(null) }
    val matches = StrainReferences.search(query)
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { Text("Strain genetics", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("Explore parent strains and family connections", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { OutlinedTextField(query, { query = it; selected = StrainReferences.exact(it) }, Modifier.fillMaxWidth(), placeholder = { Text("Search a strain") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true) }
        if (selected == null) {
            if (query.isBlank()) item { EmptyState("Explore the family tree", "Search for a strain such as Wedding Pie, GMO or Gelato 41.") }
            else if (matches.isEmpty()) item { EmptyState("Strain not in the catalogue yet", "The online catalogue connection is being prepared. You will still be able to add unknown names to your journal.") }
            else items(matches) { reference -> ElevatedCard(onClick = { selected = reference; query = reference.name }, modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text(reference.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Text(reference.genetics); Text(reference.commonTerpenes.joinToString(" • "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
        } else {
            val reference = selected!!
            item { ElevatedCard(Modifier.fillMaxWidth(), colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Column { Text(reference.name, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text("Parent lineage", color = MaterialTheme.colorScheme.onPrimaryContainer) }; Icon(Icons.Default.AccountTree, null, Modifier.size(34.dp)) }
                Text(reference.genetics, style = MaterialTheme.typography.titleLarge)
                val parents = reference.parents
                if (parents.isNotEmpty()) { Text("Tap a parent to keep exploring", style = MaterialTheme.typography.labelLarge); LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(parents) { parent -> AssistChip(onClick = { query = parent; selected = StrainReferences.exact(parent) }, label = { Text(parent) }, leadingIcon = { Icon(Icons.Default.CallSplit, null) }) } } }
                HorizontalDivider()
                Text("Commonly reported terpenes", fontWeight = FontWeight.Bold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) { reference.commonTerpenes.forEach { terpene -> SuggestionChip({}, { Text(terpene) }) } }
                if (reference.flavours.isNotEmpty()) { Text("Flavour profile", fontWeight = FontWeight.Bold); Text(reference.flavours.joinToString(" • ")) }
                Text(reference.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
            } } }
            val journalMatches = reviews.filter { it.strainName.equals(reference.name, true) }
            if (journalMatches.isNotEmpty()) item { Text("Your ${reference.name} reviews", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            items(journalMatches, key = { it.id }) { review -> ReviewCard(review, onOpenReview, { vm.toggleFavourite(review) }) }
        }
    }
}

@Composable private fun AppearanceScreen(current: AppTheme, onThemeChange: (AppTheme) -> Unit, onBack: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back") }; Column { Text("Choose your look", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("You can change this whenever you like", color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
        items(AppTheme.entries) { option -> ElevatedCard(onClick = { onThemeChange(option) }, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.elevatedCardColors(containerColor = if (current == option) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface)) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(if (current == option) Icons.Default.CheckCircle else Icons.Default.Palette, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(14.dp)); Column { Text(option.title, fontWeight = FontWeight.Bold); Text(option.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant) } } } }
        item { Text("Custom backgrounds and artwork are planned next. Background images will include a strength control so text stays readable.", style = MaterialTheme.typography.bodyMedium) }
    }
}

@Composable private fun Field(value:String, change:(String)->Unit, label:String, hint:String="", minLines:Int=1) = OutlinedTextField(value, change, Modifier.fillMaxWidth(), label={Text(label)}, placeholder={if(hint.isNotBlank()) Text(hint)}, minLines=minLines)
@Composable private fun RatingSlider(label:String, value:Int, change:(Int)->Unit) { Column { Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) { Text(label, fontWeight=FontWeight.SemiBold); Text("$value/10") }; Slider(value.toFloat(), { change(it.toInt()) }, valueRange=0f..10f, steps=9) } }
@Composable private fun Detail(label:String, value:String) { if(value.isNotBlank()) Column { Text(label, style=MaterialTheme.typography.labelLarge, color=MaterialTheme.colorScheme.primary); Text(value) } }
@Composable private fun EmptyState(title:String, body:String) { Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment=Alignment.Center) { Column(horizontalAlignment=Alignment.CenterHorizontally) { Icon(Icons.Default.Spa, null, Modifier.size(54.dp), tint=MaterialTheme.colorScheme.primary); Spacer(Modifier.height(12.dp)); Text(title, style=MaterialTheme.typography.titleMedium, fontWeight=FontWeight.Bold); Text(body, color=MaterialTheme.colorScheme.onSurfaceVariant) } } }
