package com.medleaf.journal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.medleaf.journal.ui.MedLeafApp
import com.medleaf.journal.ui.MedLeafTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MedLeafTheme { MedLeafApp() } }
    }
}
