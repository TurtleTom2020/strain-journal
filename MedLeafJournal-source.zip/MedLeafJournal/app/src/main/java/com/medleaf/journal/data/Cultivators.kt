package com.medleaf.journal.data

object Cultivators {
    private val names = listOf(
        "Papers", "Green Karat", "Aurora", "Curaleaf", "Peace Naturals",
        "Craft Botanics", "4C Labs", "Upstate", "Lumir", "Lot420",
        "Qwest", "Carmel", "Grow", "Tilray", "Noidecs", "Canopy",
        "Hexacan", "Therismos", "Mamedica", "Montu", "Cantourage"
    )

    fun search(text: String): List<String> = if (text.isBlank()) names.take(8)
    else names.filter { it.contains(text.trim(), ignoreCase = true) }.take(8)
}
