package com.medleaf.journal.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface JournalDao {
    @Query("SELECT * FROM reviews ORDER BY createdAt DESC")
    fun reviews(): Flow<List<Review>>

    @Query("SELECT * FROM reviews WHERE id = :id")
    fun review(id: Long): Flow<Review?>

    @Query("SELECT * FROM sessions ORDER BY takenAt DESC")
    fun sessions(): Flow<List<MedicationSession>>

    @Insert suspend fun insertReview(review: Review): Long
    @Update suspend fun updateReview(review: Review)
    @Delete suspend fun deleteReview(review: Review)
    @Insert suspend fun insertSession(session: MedicationSession): Long
}
