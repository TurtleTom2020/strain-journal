package com.medleaf.journal.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Colours = lightColorScheme(
    primary = Color(0xFF2E6B4E), onPrimary = Color.White,
    primaryContainer = Color(0xFFC5EBD6), onPrimaryContainer = Color(0xFF0B3825),
    secondary = Color(0xFF825500), secondaryContainer = Color(0xFFFFDDA2),
    tertiary = Color(0xFF76517B), background = Color(0xFFF7FAF6),
    surface = Color(0xFFF7FAF6), surfaceVariant = Color(0xFFE1EAE3)
)

@Composable fun MedLeafTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colours, typography = Typography(), content = content)
}
