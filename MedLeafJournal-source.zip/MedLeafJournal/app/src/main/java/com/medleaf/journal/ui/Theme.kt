package com.medleaf.journal.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

enum class AppTheme(val title: String, val subtitle: String) {
    MIDNIGHT("Midnight Chrome", "Gloss black, graphite and silver"),
    FOREST("Forest", "Deep green with warm gold"),
    CLINICAL("Clinical", "Bright, calm and medical"),
    REGGAE("Reggae", "Dark charcoal with red, gold and green")
}

private val ClinicalColours = lightColorScheme(
    primary = Color(0xFF2E6B4E), onPrimary = Color.White,
    primaryContainer = Color(0xFFC5EBD6), onPrimaryContainer = Color(0xFF0B3825),
    secondary = Color(0xFF825500), secondaryContainer = Color(0xFFFFDDA2),
    tertiary = Color(0xFF76517B), background = Color(0xFFF7FAF6),
    surface = Color(0xFFF7FAF6), surfaceVariant = Color(0xFFE1EAE3)
)

private val MidnightColours = darkColorScheme(
    primary = Color(0xFFD7DCE0), onPrimary = Color(0xFF17191B),
    primaryContainer = Color(0xFF34383C), onPrimaryContainer = Color(0xFFF5F7F8),
    secondary = Color(0xFFC7A45B), secondaryContainer = Color(0xFF4B3B1E),
    tertiary = Color(0xFF93CDB2), background = Color(0xFF08090A),
    surface = Color(0xFF151719), surfaceVariant = Color(0xFF292D30),
    onBackground = Color(0xFFF4F5F6), onSurface = Color(0xFFF4F5F6),
    onSurfaceVariant = Color(0xFFC8CDD0),
    outline = Color(0xFF92989C), outlineVariant = Color(0xFF50565A)
)

private val ForestColours = darkColorScheme(
    primary = Color(0xFF8CDBB2), onPrimary = Color(0xFF083824),
    primaryContainer = Color(0xFF17553B), onPrimaryContainer = Color(0xFFE5F8ED),
    secondary = Color(0xFFFFC966), onSecondary = Color(0xFF3D2E00),
    tertiary = Color(0xFFA7D9C1), background = Color(0xFF07150F),
    surface = Color(0xFF10231A), surfaceVariant = Color(0xFF253A30),
    onBackground = Color(0xFFF1F7F3), onSurface = Color(0xFFF1F7F3),
    onSurfaceVariant = Color(0xFFC3D2CA), outline = Color(0xFF8EA096),
    outlineVariant = Color(0xFF455B50)
)

private val ReggaeColours = darkColorScheme(
    primary = Color(0xFF74C97F), onPrimary = Color(0xFF082F13),
    primaryContainer = Color(0xFF1C4C29), onPrimaryContainer = Color(0xFFE6F6E8),
    secondary = Color(0xFFF1C453), onSecondary = Color(0xFF382E00),
    tertiary = Color(0xFFE36A62), background = Color(0xFF11110F),
    surface = Color(0xFF201F1A), surfaceVariant = Color(0xFF38352D),
    onBackground = Color(0xFFF7F3E8), onSurface = Color(0xFFF7F3E8),
    onSurfaceVariant = Color(0xFFD4CDBB), outline = Color(0xFFA39B88),
    outlineVariant = Color(0xFF595445)
)

@Composable fun MedLeafTheme(theme: AppTheme = AppTheme.MIDNIGHT, content: @Composable () -> Unit) {
    val colours = when (theme) {
        AppTheme.MIDNIGHT -> MidnightColours
        AppTheme.FOREST -> ForestColours
        AppTheme.CLINICAL -> ClinicalColours
        AppTheme.REGGAE -> ReggaeColours
    }
    MaterialTheme(colorScheme = colours, typography = Typography(), content = content)
}
