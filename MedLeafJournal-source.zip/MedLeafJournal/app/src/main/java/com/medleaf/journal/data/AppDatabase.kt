package com.medleaf.journal.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [Review::class, MedicationSession::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun journalDao(): JournalDao
    companion object {
        fun create(context: Context): AppDatabase = Room.databaseBuilder(
            context.applicationContext, AppDatabase::class.java, "medleaf-journal.db"
        ).addMigrations(MIGRATION_1_2).build()

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE reviews ADD COLUMN imageUris TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE reviews ADD COLUMN reviewDate INTEGER NOT NULL DEFAULT 0")
                db.execSQL("UPDATE reviews SET reviewDate = createdAt WHERE reviewDate = 0")
                db.execSQL("ALTER TABLE reviews ADD COLUMN batchNumber TEXT NOT NULL DEFAULT ''")
            }
        }
    }
}
