package com.medleaf.journal.data

class JournalRepository(private val dao: JournalDao) {
    val reviews = dao.reviews()
    val sessions = dao.sessions()
    fun review(id: Long) = dao.review(id)
    suspend fun save(review: Review) = dao.insertReview(review)
    suspend fun update(review: Review) = dao.updateReview(review)
    suspend fun saveSession(session: MedicationSession) = dao.insertSession(session)
}
