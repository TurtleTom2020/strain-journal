package com.medleaf.journal.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CultivatorBrandsTest {
    @Test fun resolvesPunctuationCaseAndAccentVariations() {
        assertEquals("N!CE", CultivatorBrands.resolve("nice")?.name)
        assertEquals("Papers Craft Co.", CultivatorBrands.resolve("PAPERS")?.name)
        assertEquals("Plantations Cérès", CultivatorBrands.resolve("plantations ceres")?.name)
        assertEquals("SOMAÍ", CultivatorBrands.resolve("somai")?.name)
        assertEquals("1964 Supply Co.", CultivatorBrands.resolve("1964")?.name)
        assertEquals("Green Karat", CultivatorBrands.resolve("Green Karat Ltd")?.name)
    }

    @Test fun unknownCultivatorRemainsAvailableForTextFallback() {
        assertNull(CultivatorBrands.resolve("A future UK producer"))
    }
}
