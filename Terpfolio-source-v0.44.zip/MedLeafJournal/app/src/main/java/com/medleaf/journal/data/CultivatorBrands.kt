package com.medleaf.journal.data

import com.medleaf.journal.R
import java.text.Normalizer

data class CultivatorBrand(
    val name: String,
    val logoResource: Int,
    val aliases: Set<String> = emptySet(),
    val artworkBounds: LogoArtworkBounds,
    /** Perceived-size correction applied to visible artwork, never to transparent canvas padding. */
    val detailScale: Float = 1f
)

data class LogoArtworkBounds(val left: Int, val top: Int, val right: Int, val bottom: Int) {
    val width: Int get() = right - left
    val height: Int get() = bottom - top
}

/** Single source of truth for bundled cultivator identities and their offline logos. */
object CultivatorBrands {
    val all = listOf(
        CultivatorBrand("1964 Supply Co.", R.drawable.cultivator_1964_supply_co, setOf("1964", "1964 Supply"), LogoArtworkBounds(207, 20, 392, 200)),
        CultivatorBrand("4C Labs", R.drawable.cultivator_4c_labs, setOf("4 C Labs"), LogoArtworkBounds(40, 57, 560, 162)),
        CultivatorBrand("All Nations", R.drawable.cultivator_all_nations, artworkBounds = LogoArtworkBounds(137, 25, 462, 195)),
        CultivatorBrand("Aurora", R.drawable.cultivator_aurora, setOf("Aurora Medical"), LogoArtworkBounds(40, 65, 560, 155)),
        CultivatorBrand("Bedrocan", R.drawable.cultivator_bedrocan, artworkBounds = LogoArtworkBounds(40, 72, 560, 147)),
        CultivatorBrand("Big Narstie Medical", R.drawable.cultivator_big_narstie_medical, setOf("Big Narstie"), LogoArtworkBounds(48, 20, 552, 200)),
        CultivatorBrand("Carmel", R.drawable.cultivator_carmel, setOf("Carmel Cannabis"), LogoArtworkBounds(141, 20, 459, 200)),
        CultivatorBrand("Craft Botanics", R.drawable.cultivator_craft_botanics, artworkBounds = LogoArtworkBounds(37, 73, 563, 146)),
        CultivatorBrand("Curaleaf", R.drawable.cultivator_curaleaf, artworkBounds = LogoArtworkBounds(40, 60, 560, 160)),
        CultivatorBrand("Doja", R.drawable.cultivator_doja, artworkBounds = LogoArtworkBounds(178, 25, 422, 195)),
        CultivatorBrand("Ghost Drops", R.drawable.cultivator_ghost_drops, artworkBounds = LogoArtworkBounds(153, 25, 447, 195), detailScale = 1.15f),
        CultivatorBrand("Glass Pharms", R.drawable.cultivator_glass_pharms, setOf("Glass Pharma", "Glass Pharmacy"), LogoArtworkBounds(91, 25, 509, 195)),
        CultivatorBrand("Green Karat", R.drawable.cultivator_green_karat, artworkBounds = LogoArtworkBounds(157, 25, 443, 195), detailScale = 1.30f),
        CultivatorBrand("Greyscales", R.drawable.cultivator_greyscales, setOf("Grayscales"), LogoArtworkBounds(40, 82, 560, 138)),
        CultivatorBrand("Grow Pharma", R.drawable.cultivator_grow_pharma, setOf("Grow"), LogoArtworkBounds(42, 20, 557, 200)),
        CultivatorBrand("HighGreens", R.drawable.cultivator_highgreens, setOf("High Greens"), LogoArtworkBounds(125, 23, 475, 197)),
        CultivatorBrand("Kasa Verde", R.drawable.cultivator_kasa_verde, artworkBounds = LogoArtworkBounds(203, 25, 397, 195)),
        CultivatorBrand("Mamedica", R.drawable.cultivator_mamedica, artworkBounds = LogoArtworkBounds(40, 75, 560, 144)),
        CultivatorBrand("N!CE", R.drawable.cultivator_nice, setOf("NICE", "Nice"), LogoArtworkBounds(77, 25, 523, 195), detailScale = .75f),
        CultivatorBrand("Papers Craft Co.", R.drawable.cultivator_papers_craft_co, setOf("Papers", "Papers Craft", "Papers Craft Co"), LogoArtworkBounds(108, 22, 492, 198)),
        CultivatorBrand("Peace Naturals", R.drawable.cultivator_peace_naturals, artworkBounds = LogoArtworkBounds(94, 20, 506, 200)),
        CultivatorBrand("Plantations Cérès", R.drawable.cultivator_plantations_ceres, setOf("Plantations Ceres", "Ceres", "Cérès"), LogoArtworkBounds(203, 10, 397, 210)),
        CultivatorBrand("Pure Sunfarms", R.drawable.cultivator_pure_sunfarms, setOf("Pure Sun Farms"), LogoArtworkBounds(40, 71, 560, 149)),
        CultivatorBrand("SOMAÍ", R.drawable.cultivator_somai, setOf("SOMAI", "Somai Pharmaceuticals"), LogoArtworkBounds(213, 20, 387, 200)),
        CultivatorBrand("Tilray Medical", R.drawable.cultivator_tilray_medical, setOf("Tilray"), LogoArtworkBounds(40, 60, 560, 159)),
        CultivatorBrand("Upstate", R.drawable.cultivator_upstate, artworkBounds = LogoArtworkBounds(40, 55, 560, 164)),
        CultivatorBrand("Vasco Cannabis", R.drawable.cultivator_vasco_cannabis, setOf("Vasco"), LogoArtworkBounds(40, 35, 560, 185))
    )

    private fun normalise(value: String): String = Normalizer.normalize(value.trim(), Normalizer.Form.NFD)
        .replace("\\p{M}+".toRegex(), "")
        .lowercase()
        .replace("!", "i")
        .filter(Char::isLetterOrDigit)

    fun resolve(value: String): CultivatorBrand? {
        val key = normalise(value)
        if (key.isBlank()) return null
        return all.firstOrNull { brand ->
            (brand.aliases + brand.name).any { candidate ->
                val alias = normalise(candidate)
                key == alias || key.removeSuffix("limited") == alias || key.removeSuffix("ltd") == alias
            }
        }
    }

    fun search(value: String, limit: Int = 8): List<CultivatorBrand> {
        val key = normalise(value)
        if (key.isBlank()) return all.take(limit)
        return all.mapNotNull { brand ->
            val candidates = (brand.aliases + brand.name).map(::normalise)
            val score = when {
                candidates.any { it == key } -> 0
                candidates.any { it.startsWith(key) } -> 1
                candidates.any { it.contains(key) } -> 2
                else -> return@mapNotNull null
            }
            score to brand
        }.sortedWith(compareBy<Pair<Int, CultivatorBrand>> { it.first }.thenBy { it.second.name })
            .map { it.second }.take(limit)
    }
}
