package com.medleaf.journal.data

object Cultivators {
    private val names = listOf(
        "Papers", "Green Karat", "Aurora", "Curaleaf", "Peace Naturals",
        "Craft Botanics", "4C Labs", "Upstate", "Lumir", "Lot420",
        "Qwest", "Carmel", "Grow", "Tilray", "Noidecs", "Canopy",
        "Hexacan", "Therismos", "Mamedica", "Montu", "Cantourage", "N!CE",
        "Ghost Drops"
    )

    private fun normalise(value: String): String = value
        .lowercase()
        .replace('1', 'i')
        .replace("!", "i")
        .filter { it.isLetterOrDigit() }

    fun search(text: String): List<String> = if (text.isBlank()) names.take(8)
    else {
        val query = normalise(text.trim())
        names.filter { normalise(it).contains(query) }.take(8)
    }
}
