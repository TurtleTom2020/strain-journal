package com.medleaf.journal.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.Normalizer

@Entity(tableName = "reviews")
data class Review(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val strainName: String,
    val brand: String = "",
    val cultivator: String = "",
    val cultivarType: String = "Hybrid",
    val thcPercent: Double? = null,
    val cbdPercent: Double? = null,
    val terpenes: String = "",
    val aroma: String = "",
    val flavour: String = "",
    val thoughts: String = "",
    val effectiveness: Int = 0,
    val flavourRating: Int = 0,
    val appearanceRating: Int = 0,
    val valueRating: Int = 0,
    val overallRating: Int = 0,
    val helpedSymptoms: String = "",
    val effects: String = "",
    val sideEffects: String = "",
    val imageUri: String? = null,
    val imageUris: String = "",
    val reviewDate: Long = System.currentTimeMillis(),
    val batchNumber: String = "",
    val pricePaid: Double? = null,
    val packSizeGrams: Double? = null,
    val isFavourite: Boolean = false,
    val visibility: String = "PRIVATE",
    val createdAt: Long = System.currentTimeMillis()
)

fun Review.effectiveCultivator(): String = cultivator.ifBlank { brand }

fun Review.hasSeparateBrandAndCultivator(): Boolean =
    brand.isNotBlank() && effectiveCultivator().isNotBlank() &&
        !(CultivatorBrands.resolve(brand)?.name ?: brand.trim()).equals(
            CultivatorBrands.resolve(effectiveCultivator())?.name ?: effectiveCultivator().trim(),
            ignoreCase = true
        )

fun Review.photos(): List<String> = imageUris.split("\n")
    .filter(String::isNotBlank)
    .ifEmpty { listOfNotNull(imageUri) }

@Entity(tableName = "sessions")
data class MedicationSession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reviewId: Long? = null,
    val strainName: String,
    val amountGrams: Double? = null,
    val method: String = "Dry herb vaporiser",
    val temperatureC: Int? = null,
    val symptomsBefore: Int = 0,
    val reliefAfter: Int = 0,
    val notes: String = "",
    val takenAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "catalogue_products")
data class CatalogueProduct(
    @PrimaryKey val id: String,
    val productName: String,
    val cultivarName: String = "",
    val brand: String = "",
    val producer: String = "",
    val genetics: String = "",
    val cultivarType: String = "Hybrid",
    val commonTerpenes: String = "",
    val flavours: String = "",
    val aliases: String = "",
    val productCode: String = "",
    val sourceName: String = "Terpfolio starter catalogue",
    val sourceUrl: String = "",
    val lastVerified: String = "",
    val isCustom: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

fun CatalogueProduct.terpeneList() = commonTerpenes.split(",").map(String::trim).filter(String::isNotBlank)
fun CatalogueProduct.flavourList() = flavours.split(",").map(String::trim).filter(String::isNotBlank)

object CatalogueSearch {
    private fun normalise(value: String) = Normalizer.normalize(value.trim(), Normalizer.Form.NFD)
        .replace("\\p{M}+".toRegex(), "").lowercase().filter(Char::isLetterOrDigit)

    private fun tokens(value: String) = Normalizer.normalize(value.trim(), Normalizer.Form.NFD)
        .replace("\\p{M}+".toRegex(), "").lowercase()
        .split(Regex("[^a-z0-9]+"))
        .filter(String::isNotBlank)

    fun exact(products: List<CatalogueProduct>, text: String): CatalogueProduct? {
        val key = normalise(text)
        if (key.isBlank()) return null
        return products.mapNotNull { product ->
            val productMatch = normalise(product.productName) == key
            val cultivarMatch = normalise(product.cultivarName) == key
            val aliasMatch = product.aliases.split(",").map(::normalise).filter(String::isNotBlank).any { it == key }
            if (!productMatch && !cultivarMatch && !aliasMatch) return@mapNotNull null
            val branded = product.brand.isNotBlank() || product.producer.isNotBlank()
            val score = when {
                branded && productMatch -> 0
                branded && aliasMatch -> 1
                branded && cultivarMatch -> 2
                productMatch -> 3
                aliasMatch -> 4
                else -> 5
            }
            score to product
        }.minWithOrNull(compareBy<Pair<Int, CatalogueProduct>> { it.first }.thenBy { it.second.productName })?.second
    }

    fun search(products: List<CatalogueProduct>, text: String, limit: Int = 8): List<CatalogueProduct> {
        val key = normalise(text)
        if (key.isBlank()) return emptyList()
        val queryTokens = tokens(text)
        return products.mapNotNull { product ->
            val rawFields = listOf(product.productName, product.cultivarName, product.brand, product.producer, product.aliases, product.productCode)
            val fields = rawFields.map(::normalise).filter(String::isNotBlank)
            val fieldTokens = rawFields.flatMap(::tokens)
            val matchScore = when {
                normalise(product.productName).startsWith(key) -> 0
                normalise(product.cultivarName).startsWith(key) -> 1
                fields.any { it.startsWith(key) } -> 2
                queryTokens.isNotEmpty() && queryTokens.all { query -> fieldTokens.any { it.startsWith(query) } } -> 3
                fields.any { it.contains(key) } -> 4
                else -> return@mapNotNull null
            }
            val score = matchScore * 2 + if (product.brand.isNotBlank() || product.producer.isNotBlank()) 0 else 1
            score to product
        }.sortedWith(compareBy<Pair<Int, CatalogueProduct>> { it.first }.thenBy { it.second.productName })
            .map { it.second }.distinctBy { listOf(it.productName.lowercase(), it.brand.lowercase()) }.take(limit)
    }
}
