package com.medleaf.journal.data

import com.medleaf.journal.R
import java.text.Normalizer

data class CultivatorBrand(
    val name: String,
    val logoResource: Int,
    val aliases: Set<String> = emptySet(),
    /** Presentation-only correction for differing artwork bounds inside the approved PNG canvas. */
    val detailScale: Float = 1f
)

/** Single source of truth for bundled cultivator identities and their offline logos. */
object CultivatorBrands {
    val all = listOf(
        CultivatorBrand("1964 Supply Co.", R.drawable.cultivator_1964_supply_co, setOf("1964", "1964 Supply")),
        CultivatorBrand("4C Labs", R.drawable.cultivator_4c_labs, setOf("4 C Labs")),
        CultivatorBrand("All Nations", R.drawable.cultivator_all_nations),
        CultivatorBrand("Aurora", R.drawable.cultivator_aurora, setOf("Aurora Medical")),
        CultivatorBrand("Bedrocan", R.drawable.cultivator_bedrocan),
        CultivatorBrand("Big Narstie Medical", R.drawable.cultivator_big_narstie_medical, setOf("Big Narstie")),
        CultivatorBrand("Carmel", R.drawable.cultivator_carmel, setOf("Carmel Cannabis")),
        CultivatorBrand("Craft Botanics", R.drawable.cultivator_craft_botanics),
        CultivatorBrand("Curaleaf", R.drawable.cultivator_curaleaf),
        CultivatorBrand("Doja", R.drawable.cultivator_doja),
        CultivatorBrand("Ghost Drops", R.drawable.cultivator_ghost_drops, detailScale = 1.464f),
        CultivatorBrand("Glass Pharms", R.drawable.cultivator_glass_pharms, setOf("Glass Pharma", "Glass Pharmacy")),
        CultivatorBrand("Green Karat", R.drawable.cultivator_green_karat, detailScale = 1.625f),
        CultivatorBrand("Greyscales", R.drawable.cultivator_greyscales, setOf("Grayscales")),
        CultivatorBrand("Grow Pharma", R.drawable.cultivator_grow_pharma, setOf("Grow")),
        CultivatorBrand("HighGreens", R.drawable.cultivator_highgreens, setOf("High Greens")),
        CultivatorBrand("Kasa Verde", R.drawable.cultivator_kasa_verde),
        CultivatorBrand("Mamedica", R.drawable.cultivator_mamedica),
        CultivatorBrand("N!CE", R.drawable.cultivator_nice, setOf("NICE", "Nice"), detailScale = .83f),
        CultivatorBrand("Papers Craft Co.", R.drawable.cultivator_papers_craft_co, setOf("Papers", "Papers Craft", "Papers Craft Co")),
        CultivatorBrand("Peace Naturals", R.drawable.cultivator_peace_naturals),
        CultivatorBrand("Plantations Cérès", R.drawable.cultivator_plantations_ceres, setOf("Plantations Ceres", "Ceres", "Cérès")),
        CultivatorBrand("Pure Sunfarms", R.drawable.cultivator_pure_sunfarms, setOf("Pure Sun Farms")),
        CultivatorBrand("SOMAÍ", R.drawable.cultivator_somai, setOf("SOMAI", "Somai Pharmaceuticals")),
        CultivatorBrand("Tilray Medical", R.drawable.cultivator_tilray_medical, setOf("Tilray")),
        CultivatorBrand("Upstate", R.drawable.cultivator_upstate),
        CultivatorBrand("Vasco Cannabis", R.drawable.cultivator_vasco_cannabis, setOf("Vasco"))
    )

    private fun normalise(value: String): String = Normalizer.normalize(value.trim(), Normalizer.Form.NFD)
        .replace("\\p{M}+".toRegex(), "")
        .lowercase()
        .replace("!", "i")
        .filter(Char::isLetterOrDigit)

    fun resolve(value: String): CultivatorBrand? {
        val key = normalise(value)
        if (key.isBlank()) return null
        return all.firstOrNull { brand ->
            (brand.aliases + brand.name).any { candidate ->
                val alias = normalise(candidate)
                key == alias || key.removeSuffix("limited") == alias || key.removeSuffix("ltd") == alias
            }
        }
    }

    fun search(value: String, limit: Int = 8): List<CultivatorBrand> {
        val key = normalise(value)
        if (key.isBlank()) return all.take(limit)
        return all.mapNotNull { brand ->
            val candidates = (brand.aliases + brand.name).map(::normalise)
            val score = when {
                candidates.any { it == key } -> 0
                candidates.any { it.startsWith(key) } -> 1
                candidates.any { it.contains(key) } -> 2
                else -> return@mapNotNull null
            }
            score to brand
        }.sortedWith(compareBy<Pair<Int, CultivatorBrand>> { it.first }.thenBy { it.second.name })
            .map { it.second }.take(limit)
    }
}
